"""Tests for the evaluation loop and the statistical-inference machinery."""

from __future__ import annotations

from dataclasses import replace

import numpy as np
import pytest

from recsys.evaluation.evaluator import Evaluator, results_to_frame
from recsys.evaluation.statistics import (
    average_ranks,
    bonferroni_correction,
    compare_models,
    critical_difference,
    holm_correction,
    paired_bootstrap_ci,
    significance_matrix,
)
from recsys.models import EASERecommender, ItemKNNRecommender, PopularityRecommender


class TestEvaluator:
    @pytest.fixture
    def fitted_models(self, interactions, fit_context):
        return {
            "popularity": PopularityRecommender(use_recency=False).fit(interactions, fit_context),
            "item_knn": ItemKNNRecommender(top_k=20).fit(interactions, fit_context),
        }

    def test_produces_all_metrics(self, evaluation_config, interactions, content, split, fitted_models):
        evaluator = Evaluator(evaluation_config, interactions, item_features=content.matrix)
        result = evaluator.evaluate(fitted_models["item_knn"], split.test_ground_truth())

        for metric in ("precision", "recall", "ndcg", "map", "mrr", "hit_rate", "f1"):
            assert f"{metric}@10" in result.aggregate
        for metric in ("novelty", "diversity", "serendipity", "popularity_bias"):
            assert f"{metric}@10" in result.aggregate
        assert "coverage@10" in result.aggregate
        assert "exposure_gini" in result.aggregate

    def test_accuracy_metrics_are_bounded(self, evaluation_config, interactions, content, split, fitted_models):
        evaluator = Evaluator(evaluation_config, interactions, item_features=content.matrix)
        result = evaluator.evaluate(fitted_models["item_knn"], split.test_ground_truth())
        for metric in ("precision@10", "recall@10", "ndcg@10", "map@10", "hit_rate@10"):
            assert 0.0 <= result.aggregate[metric] <= 1.0

    def test_per_user_vectors_align(self, evaluation_config, interactions, content, split, fitted_models):
        evaluator = Evaluator(evaluation_config, interactions, item_features=content.matrix)
        result = evaluator.evaluate(fitted_models["item_knn"], split.test_ground_truth())
        lengths = {len(v) for v in result.per_user.values()}
        assert len(lengths) == 1
        assert lengths.pop() == result.n_users_evaluated

    def test_all_models_see_identical_users(
        self, evaluation_config, interactions, content, split, fitted_models
    ):
        """A precondition for the paired significance tests."""
        evaluator = Evaluator(evaluation_config, interactions, item_features=content.matrix)
        results = evaluator.evaluate_all(fitted_models, split.test_ground_truth())
        counts = {r.n_users_evaluated for r in results.values()}
        assert len(counts) == 1

    def test_results_frame(self, evaluation_config, interactions, content, split, fitted_models):
        evaluator = Evaluator(evaluation_config, interactions, item_features=content.matrix)
        results = evaluator.evaluate_all(fitted_models, split.test_ground_truth())
        frame = results_to_frame(results)
        assert set(frame.index) == set(fitted_models)
        assert "ndcg@10" in frame.columns


class TestSerendipityHead:
    def test_head_covers_what_the_baseline_can_expose(
        self, evaluation_config, interactions, content
    ):
        """Regression guard on the definition of "obvious".

        The head was previously a flat 1% of the catalogue, which was smaller
        than the set the popularity baseline actually surfaces — so the baseline
        scored non-zero serendipity against its own definition, and the metric
        grew with k instead of staying at zero.
        """
        evaluator = Evaluator(
            evaluation_config, interactions, item_features=content.matrix
        )
        head = evaluator.popular_items
        assert head.size >= max(evaluation_config.cutoffs)
        assert head.size <= interactions.n_items
        # The head must be a prefix of the popularity ordering.
        order = np.argsort(-interactions.item_popularity)
        np.testing.assert_array_equal(head, order[: head.size])

    def test_baseline_serendipity_is_near_zero(
        self, evaluation_config, interactions, content, split, fit_context
    ):
        evaluator = Evaluator(
            evaluation_config, interactions, item_features=content.matrix
        )
        baseline = PopularityRecommender(use_recency=False).fit(
            interactions, fit_context
        )
        result = evaluator.evaluate(baseline, split.test_ground_truth())
        for k in evaluation_config.cutoffs:
            assert result.aggregate[f"serendipity@{k}"] == pytest.approx(0.0, abs=1e-9)


class TestBatchedScoringEquivalence:
    def test_block_scoring_matches_per_user_ranking(
        self, evaluation_config, interactions, content, split, fit_context
    ):
        """The batched evaluation path must agree with per-user ``recommend``."""
        model = EASERecommender(l2_regularization=100.0).fit(interactions, fit_context)
        evaluator = Evaluator(
            evaluation_config, interactions, item_features=content.matrix
        )
        users = sorted(split.test_ground_truth().keys())[:25]
        block = np.asarray(model.score_batch(users), dtype=np.float64)
        for row, user in enumerate(users):
            np.testing.assert_allclose(
                block[row], model.score(user), rtol=1e-9, atol=1e-12
            )


class TestCriticalDifference:
    def test_matches_demsar_tabulated_value(self):
        """Demšar (2006) Table 5: q_alpha = 1.960 for k = 2 at alpha = 0.05."""
        n_datasets = 100
        cd = critical_difference(2, n_datasets, alpha=0.05)
        expected = 1.959964 * np.sqrt(2 * 3 / (6.0 * n_datasets))
        assert cd == pytest.approx(expected, rel=1e-3)

    def test_shrinks_with_more_observations(self):
        assert critical_difference(5, 1000) < critical_difference(5, 100)


class TestHolmCorrection:
    def test_single_p_value_unchanged(self):
        np.testing.assert_allclose(holm_correction(np.array([0.03])), [0.03])

    def test_corrected_values_never_decrease_significance(self):
        raw = np.array([0.01, 0.02, 0.03, 0.04])
        corrected = holm_correction(raw)
        assert np.all(corrected >= raw)

        # Bonferroni must be a genuinely distinct, uniformly more conservative
        # procedure — not an alias for Holm.
        bonf = bonferroni_correction(raw)
        np.testing.assert_allclose(bonf, np.minimum(1.0, raw * raw.size))
        assert np.all(bonf >= corrected - 1e-12)
        assert not np.allclose(bonf, corrected)

    def test_bounded_at_one(self):
        corrected = holm_correction(np.array([0.5, 0.6, 0.7, 0.8]))
        assert np.all(corrected <= 1.0)

    def test_monotone_in_rank(self):
        """The step-down procedure must produce a non-decreasing sequence."""
        raw = np.array([0.001, 0.01, 0.02, 0.04, 0.05])
        corrected = holm_correction(raw)
        order = np.argsort(raw)
        assert np.all(np.diff(corrected[order]) >= -1e-12)

    def test_empty_input(self):
        assert holm_correction(np.array([])).size == 0


class TestBootstrap:
    def test_interval_brackets_the_true_difference(self):
        rng = np.random.default_rng(0)
        a = rng.normal(0.0, 1.0, 500)
        b = a + 0.5
        low, high = paired_bootstrap_ci(a, b, 500, 0.05)
        assert low <= 0.5 <= high

    def test_interval_ordering(self):
        rng = np.random.default_rng(1)
        a = rng.normal(0, 1, 200)
        b = rng.normal(0, 1, 200)
        low, high = paired_bootstrap_ci(a, b, 300, 0.05)
        assert low <= high

    def test_degenerate_input(self):
        low, high = paired_bootstrap_ci(np.array([1.0]), np.array([2.0]), 100, 0.05)
        assert np.isnan(low) and np.isnan(high)


class TestModelComparison:
    @pytest.fixture
    def per_user(self):
        rng = np.random.default_rng(3)
        n = 300
        base = rng.uniform(0, 0.4, n)
        return {
            "weak": {"ndcg@10": base},
            "strong": {"ndcg@10": np.clip(base + 0.15, 0, 1)},
            "similar": {"ndcg@10": np.clip(base + rng.normal(0, 0.005, n), 0, 1)},
        }

    def test_detects_a_real_difference(self, per_user, statistics_config):
        report = compare_models(per_user, "ndcg@10", statistics_config)
        pair = next(
            c for c in report.comparisons
            if {c.model_a, c.model_b} == {"weak", "strong"}
        )
        assert pair.significant
        assert abs(pair.delta) == pytest.approx(0.15, abs=0.02)

    def test_all_pairs_are_compared(self, per_user, statistics_config):
        report = compare_models(per_user, "ndcg@10", statistics_config)
        assert len(report.comparisons) == 3          # C(3,2)

        # Regression guard: the correction named in the configuration must be
        # the one actually applied, and "none" must still decide significance.
        n_pairs = 3
        bonf = compare_models(
            per_user, "ndcg@10", replace(statistics_config, correction="bonferroni")
        )
        for c in bonf.comparisons:
            assert c.p_value_corrected == pytest.approx(
                min(1.0, c.p_value_raw * n_pairs)
            )

        none_cfg = replace(statistics_config, correction="none")
        plain = compare_models(per_user, "ndcg@10", none_cfg)
        for c in plain.comparisons:
            assert c.p_value_corrected == pytest.approx(c.p_value_raw)
            assert c.significant == (c.p_value_raw < none_cfg.alpha)

    def test_markdown_export(self, per_user, statistics_config):
        report = compare_models(per_user, "ndcg@10", statistics_config)
        markdown = report.format_markdown()
        assert "Comparison" in markdown and "p (corr.)" in markdown

    def test_summary_frame_columns(self, per_user, statistics_config):
        report = compare_models(per_user, "ndcg@10", statistics_config)
        frame = report.summary_frame()
        assert {"comparison", "delta", "p_value", "significant"} <= set(frame.columns)

    def test_significance_matrix_is_square(self, per_user):
        matrix = significance_matrix(per_user, "ndcg@10")
        assert matrix.shape == (3, 3)
        np.testing.assert_allclose(np.diag(matrix.to_numpy()), 1.0)

    def test_average_ranks_orders_models(self, per_user):
        ranks = average_ranks(per_user, "ndcg@10")
        assert ranks.index[0] == "strong"           # best model has the lowest rank
