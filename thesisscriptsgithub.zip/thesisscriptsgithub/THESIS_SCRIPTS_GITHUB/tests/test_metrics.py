"""Unit tests for the evaluation metrics.

Metrics are the instruments by which every claim in the thesis is measured; a
silent error here would invalidate the entire empirical argument. The tests
therefore verify each metric against *hand-computed* values rather than against
the implementation itself.
"""

from __future__ import annotations

import numpy as np
import pytest

from recsys.evaluation import metrics as M


class TestPrecisionRecall:
    def test_perfect_ranking(self):
        recommended = np.array([1, 2, 3, 4, 5])
        relevant = np.array([1, 2, 3, 4, 5])
        assert M.precision_at_k(recommended, relevant, 5) == pytest.approx(1.0)
        assert M.recall_at_k(recommended, relevant, 5) == pytest.approx(1.0)
        assert M.f1_at_k(recommended, relevant, 5) == pytest.approx(1.0)

    def test_no_hits(self):
        recommended = np.array([1, 2, 3])
        relevant = np.array([7, 8, 9])
        assert M.precision_at_k(recommended, relevant, 3) == 0.0
        assert M.recall_at_k(recommended, relevant, 3) == 0.0
        assert M.hit_rate_at_k(recommended, relevant, 3) == 0.0

    def test_partial_hits(self):
        recommended = np.array([1, 5, 2, 7, 3])
        relevant = np.array([1, 2, 3, 4])
        # hits at positions 1, 3, 5 → 3 of 5 recommended, 3 of 4 relevant
        assert M.precision_at_k(recommended, relevant, 5) == pytest.approx(0.6)
        assert M.recall_at_k(recommended, relevant, 5) == pytest.approx(0.75)

    def test_precision_denominator_is_k_not_list_length(self):
        """Precision@10 on a 3-item list must divide by 10, not by 3."""
        recommended = np.array([1, 2, 3])
        relevant = np.array([1, 2, 3])
        assert M.precision_at_k(recommended, relevant, 10) == pytest.approx(0.3)

    def test_empty_inputs(self):
        empty = np.array([], dtype=int)
        assert M.precision_at_k(empty, np.array([1]), 5) == 0.0
        assert M.recall_at_k(np.array([1]), empty, 5) == 0.0


class TestNDCG:
    def test_ideal_ranking_is_one(self):
        recommended = np.array([1, 2, 3])
        relevant = np.array([1, 2, 3])
        assert M.ndcg_at_k(recommended, relevant, 3) == pytest.approx(1.0)

    def test_hand_computed_value(self):
        # One relevant item at position 2 → DCG = 1/log2(3); IDCG = 1/log2(2) = 1
        recommended = np.array([9, 1, 8])
        relevant = np.array([1])
        expected = (1.0 / np.log2(3.0)) / 1.0
        assert M.ndcg_at_k(recommended, relevant, 3) == pytest.approx(expected)

    def test_position_discount_is_monotone(self):
        relevant = np.array([1])
        early = M.ndcg_at_k(np.array([1, 2, 3, 4]), relevant, 4)
        late = M.ndcg_at_k(np.array([2, 3, 4, 1]), relevant, 4)
        assert early > late

    def test_bounded_in_unit_interval(self):
        rng = np.random.default_rng(0)
        for _ in range(50):
            recommended = rng.permutation(20)[:10]
            relevant = rng.choice(20, size=5, replace=False)
            value = M.ndcg_at_k(recommended, relevant, 10)
            assert 0.0 <= value <= 1.0


class TestRankingMetrics:
    def test_mrr_first_position(self):
        assert M.reciprocal_rank_at_k(np.array([5, 1, 2]), np.array([5]), 3) == 1.0

    def test_mrr_third_position(self):
        value = M.reciprocal_rank_at_k(np.array([1, 2, 5]), np.array([5]), 3)
        assert value == pytest.approx(1.0 / 3.0)

    def test_average_precision(self):
        # Relevant at positions 1 and 3: AP = (1/1 + 2/3) / 2
        recommended = np.array([1, 9, 2, 8])
        relevant = np.array([1, 2])
        expected = (1.0 + 2.0 / 3.0) / 2.0
        assert M.average_precision_at_k(recommended, relevant, 4) == pytest.approx(expected)


class TestBeyondAccuracy:
    def test_novelty_rewards_rare_items(self):
        popularity = np.array([100.0, 50.0, 1.0])
        popular = M.novelty_at_k(np.array([0]), popularity, 100, 1)
        rare = M.novelty_at_k(np.array([2]), popularity, 100, 1)
        assert rare > popular

    def test_popularity_bias_normalised(self):
        popularity = np.array([100.0, 50.0, 10.0])
        assert M.popularity_bias_at_k(np.array([0]), popularity, 1) == pytest.approx(1.0)
        assert M.popularity_bias_at_k(np.array([2]), popularity, 1) == pytest.approx(0.1)

    def test_serendipity_excludes_obvious_items(self):
        recommended = np.array([1, 2])
        relevant = np.array([1, 2])
        popular = np.array([1])
        # Only item 2 is both relevant and non-obvious → 1/2
        assert M.serendipity_at_k(recommended, relevant, popular, 2) == pytest.approx(0.5)

    def test_coverage(self):
        lists = [np.array([0, 1]), np.array([1, 2])]
        assert M.catalogue_coverage(lists, n_items=10, k=2) == pytest.approx(0.3)

    def test_gini_bounds(self):
        equal = M.gini_index(np.ones(100))
        concentrated = M.gini_index(np.array([100.0] + [0.0] * 99))
        assert equal == pytest.approx(0.0, abs=0.02)
        assert concentrated > 0.9

    def test_entropy_maximised_by_uniform(self):
        uniform = M.shannon_entropy(np.ones(8))
        skewed = M.shannon_entropy(np.array([100.0, 1, 1, 1, 1, 1, 1, 1]))
        assert uniform == pytest.approx(3.0)      # log2(8)
        assert uniform > skewed


class TestBusinessMetrics:
    def test_expected_revenue_weights_by_price(self):
        recommended = np.array([0, 1])
        relevant = np.array([0, 1])
        prices = np.array([10.0, 100.0])
        value = M.expected_revenue_at_k(recommended, relevant, prices, 2, position_decay=1.0)
        assert value == pytest.approx(110.0)

    def test_position_decay_reduces_value(self):
        prices = np.array([10.0, 10.0])
        first = M.expected_revenue_at_k(np.array([0, 1]), np.array([0]), prices, 2, 0.5)
        second = M.expected_revenue_at_k(np.array([1, 0]), np.array([0]), prices, 2, 0.5)
        assert first > second
