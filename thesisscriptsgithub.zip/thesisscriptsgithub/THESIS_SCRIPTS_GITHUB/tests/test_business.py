"""Tests for the business-value layer: RFM, CLV and revenue simulation."""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from recsys.business.clv import BGNBDModel, CLVCalculator, GammaGammaModel
from recsys.business.cross_sell import CrossSellEngine, UpSellEngine
from recsys.business.simulation import RevenueSimulator, coverage_revenue_analysis
from recsys.config import BusinessConfig
from recsys.features.rfm import compute_rfm
from recsys.models import AssociationRulesRecommender


class TestRFM:
    def test_scores_in_range(self, clean_frame):
        result = compute_rfm(clean_frame, quantiles=5)
        for column in ("r_score", "f_score", "m_score"):
            assert result.table[column].between(1, 5).all()

    def test_recency_is_reverse_scored(self, clean_frame):
        """A more recent purchase must receive a higher R score."""
        result = compute_rfm(clean_frame, quantiles=5)
        correlation = result.table["recency_days"].corr(result.table["r_score"])
        assert correlation < 0

    def test_every_customer_segmented(self, clean_frame):
        result = compute_rfm(clean_frame)
        assert result.table["segment"].notna().all()
        assert len(result.table) == clean_frame["customer_id"].nunique()

    def test_segment_summary_shares_sum_to_100(self, clean_frame):
        result = compute_rfm(clean_frame)
        assert result.segment_summary["revenue_share_pct"].sum() == pytest.approx(100.0, abs=0.5)
        assert result.segment_summary["customer_share_pct"].sum() == pytest.approx(100.0, abs=0.5)

    def test_empty_input_rejected(self):
        with pytest.raises(ValueError):
            compute_rfm(pd.DataFrame())


class TestBGNBD:
    @pytest.fixture
    def cohort(self):
        rng = np.random.default_rng(11)
        n = 400
        T = rng.uniform(30, 700, n)
        frequency = rng.poisson(2.5, n).astype(float)
        recency = np.minimum(rng.uniform(0, 1, n) * T, T)
        return frequency, recency, T

    def test_fits_and_reports_parameters(self, cohort):
        model = BGNBDModel().fit(*cohort)
        assert model.is_fitted
        for value in (model.r, model.alpha, model.a, model.b):
            assert value > 0 and np.isfinite(value)

    def test_expected_transactions_non_negative(self, cohort):
        model = BGNBDModel().fit(*cohort)
        predicted = model.expected_transactions(365.0, *cohort)
        assert np.all(predicted >= 0)
        assert np.all(np.isfinite(predicted))

    def test_longer_horizon_predicts_more(self, cohort):
        model = BGNBDModel().fit(*cohort)
        short = model.expected_transactions(90.0, *cohort)
        long = model.expected_transactions(365.0, *cohort)
        assert long.sum() >= short.sum()

    def test_probability_alive_is_a_probability(self, cohort):
        model = BGNBDModel().fit(*cohort)
        p = model.probability_alive(*cohort)
        assert np.all((p >= 0.0) & (p <= 1.0))

    def test_prediction_before_fit_raises(self):
        with pytest.raises(RuntimeError):
            BGNBDModel().expected_transactions(
                365.0, np.array([1.0]), np.array([10.0]), np.array([100.0])
            )


class TestGammaGamma:
    def test_shrinkage_towards_population_mean(self):
        rng = np.random.default_rng(5)
        n = 300
        frequency = rng.integers(1, 12, n).astype(float)
        monetary = rng.gamma(4.0, 12.0, n)

        model = GammaGammaModel().fit(frequency, monetary)
        expected = model.conditional_expected_average_value(frequency, monetary)

        assert np.all(expected >= 0)
        assert np.all(np.isfinite(expected))
        # Shrinkage must compress the spread relative to raw observations.
        assert expected.std() <= monetary.std() * 1.1

    def test_prediction_before_fit_raises(self):
        with pytest.raises(RuntimeError):
            GammaGammaModel().conditional_expected_average_value(
                np.array([2.0]), np.array([30.0])
            )


class TestCLV:
    def test_dropout_shape_is_not_floored_at_one(self, clean_frame):
        """Regression guard: ``a`` must be free to fall below 1.

        Fader, Hardie and Lee require only ``a > 0``; their own CDNOW estimate
        is a = 0.793. Reparameterising as ``1 + exp(.)`` truncates the
        likelihood surface and drives the optimiser onto the boundary, where
        equation 10 degenerates into a 0/0 form.
        """
        result = CLVCalculator(horizon_days=365).compute(clean_frame)
        a = result.bgnbd_params["a"]
        assert a > 0.0
        # The old parameterisation could not produce a value in (0, 1]; assert
        # the constraint is genuinely absent rather than merely unexercised.
        model = BGNBDModel()
        model.r, model.alpha, model.a, model.b = 0.7, 50.0, 0.13, 2.3
        model.is_fitted = True
        expected = model.expected_transactions(
            365.0,
            np.array([0.0, 1.0, 5.0]),
            np.array([0.0, 40.0, 300.0]),
            np.array([400.0, 400.0, 400.0]),
        )
        assert np.all(np.isfinite(expected))
        assert np.all(expected >= 0.0)
        assert expected[2] > expected[0]

    def test_monetary_value_averages_repeat_orders_only(self):
        """Gamma-Gamma treats m̄ as the mean of exactly ``x`` repeat orders."""
        base = pd.Timestamp("2011-01-01")
        rows = [
            # customer 1: first order 1000, then two repeats of 100 and 200
            (1, "A1", base, 1000.0),
            (1, "A2", base + pd.Timedelta(days=10), 100.0),
            (1, "A3", base + pd.Timedelta(days=20), 200.0),
        ]
        frame = pd.DataFrame(
            rows, columns=["customer_id", "invoice", "invoice_date", "revenue"]
        )
        summary = CLVCalculator()._rfm_matrix(frame)
        row = summary.loc[1]
        assert row["frequency"] == pytest.approx(2.0)
        # (100 + 200) / 2 = 150, NOT (1000 + 100 + 200) / 3 = 433.33
        assert row["monetary_value"] == pytest.approx(150.0)

    def test_produces_non_negative_values(self, clean_frame):
        result = CLVCalculator(horizon_days=365, gross_margin=0.35).compute(clean_frame)
        assert (result.table["clv"] >= 0).all()
        assert result.table["clv"].notna().all()

    def test_expected_columns(self, clean_frame):
        result = CLVCalculator().compute(clean_frame)
        for column in (
            "frequency", "recency", "T", "monetary_value",
            "predicted_transactions", "probability_alive",
            "expected_avg_value", "clv",
        ):
            assert column in result.table.columns

    def test_decile_summary_shares_sum_to_100(self, clean_frame):
        result = CLVCalculator().compute(clean_frame)
        summary = result.decile_summary()
        assert summary["clv_share_pct"].sum() == pytest.approx(100.0, abs=1.0)

    def test_higher_margin_increases_clv(self, clean_frame):
        low = CLVCalculator(gross_margin=0.20).compute(clean_frame).total_clv()
        high = CLVCalculator(gross_margin=0.50).compute(clean_frame).total_clv()
        assert high > low


class TestMerchandising:
    @pytest.fixture
    def rules_model(self, interactions, fit_context):
        return AssociationRulesRecommender(min_support=0.002, min_confidence=0.02).fit(
            interactions, fit_context
        )

    def test_cross_sell_excludes_basket_items(self, rules_model, interactions):
        engine = CrossSellEngine(rules_model, interactions.item_mean_price)
        basket = [int(np.argmax(interactions.item_popularity))]
        suggestions = engine.suggest(basket, n=5)
        assert all(s.item_idx not in basket for s in suggestions)

    def test_cross_sell_respects_n(self, rules_model, interactions):
        engine = CrossSellEngine(rules_model, interactions.item_mean_price)
        basket = [int(np.argmax(interactions.item_popularity))]
        assert len(engine.suggest(basket, n=3)) <= 3

    def test_cross_sell_empty_basket(self, rules_model, interactions):
        engine = CrossSellEngine(rules_model, interactions.item_mean_price)
        assert engine.suggest([], n=5) == []

    def test_unfitted_rules_rejected(self, interactions):
        with pytest.raises(RuntimeError):
            CrossSellEngine(AssociationRulesRecommender(), interactions.item_mean_price)

    def test_up_sell_only_returns_pricier_items(self, content, interactions):
        engine = UpSellEngine(content.matrix, interactions.item_mean_price)
        anchor = int(np.argmax(interactions.item_popularity))
        anchor_price = interactions.item_mean_price[anchor]
        for suggestion in engine.suggest(anchor, n=5, min_price_ratio=1.15):
            assert suggestion.price >= anchor_price * 1.15

    def test_up_sell_price_ceiling(self, content, interactions):
        engine = UpSellEngine(content.matrix, interactions.item_mean_price)
        anchor = int(np.argmax(interactions.item_popularity))
        anchor_price = interactions.item_mean_price[anchor]
        for suggestion in engine.suggest(anchor, n=5, max_price_ratio=2.0):
            assert suggestion.price <= anchor_price * 2.0

    def test_up_sell_invalid_anchor(self, content, interactions):
        engine = UpSellEngine(content.matrix, interactions.item_mean_price)
        assert engine.suggest(999_999, n=5) == []


class TestRevenueSimulation:
    @pytest.fixture
    def simulator(self):
        return RevenueSimulator(
            BusinessConfig(simulation_impressions=1_000_000, baseline_ctr=0.02),
            average_order_value=20.0,
        )

    def test_better_accuracy_yields_more_revenue(self, simulator):
        result = simulator.simulate(
            {"popularity": 0.05, "ease": 0.12}, baseline_model="popularity"
        )
        by_name = {s.model_name: s for s in result.scenarios}
        assert by_name["ease"].revenue > by_name["popularity"].revenue

    def test_baseline_has_zero_uplift(self, simulator):
        result = simulator.simulate(
            {"popularity": 0.05, "ease": 0.12}, baseline_model="popularity"
        )
        baseline = next(s for s in result.scenarios if s.model_name == "popularity")
        assert baseline.revenue_uplift_vs_baseline == pytest.approx(0.0, abs=1e-6)

    def test_ctr_remains_a_probability(self, simulator):
        result = simulator.simulate({"a": 0.01, "b": 0.99}, baseline_model="a")
        assert all(0.0 <= s.ctr <= 1.0 for s in result.scenarios)

    def test_sensitivity_grid_present(self, simulator):
        result = simulator.simulate({"popularity": 0.05, "ease": 0.12})
        assert result.sensitivity is not None
        assert not result.sensitivity.empty
        assert "ease" in result.sensitivity.columns

    def test_assumptions_are_recorded(self, simulator):
        result = simulator.simulate({"popularity": 0.05, "ease": 0.12})
        for key in ("impressions", "baseline_ctr", "attach_rate", "elasticity"):
            assert key in result.assumptions

    def test_empty_input(self, simulator):
        assert simulator.simulate({}).scenarios == []


class TestLongTailAnalysis:
    def test_three_segments_and_shares(self):
        n = 300
        revenue = np.random.default_rng(0).gamma(2, 50, n)
        popularity = np.sort(np.random.default_rng(1).gamma(2, 5, n))[::-1]
        exposure = np.zeros(n)
        exposure[:50] = 10.0

        frame = coverage_revenue_analysis(revenue, popularity, exposure)
        assert len(frame) == 3
        assert frame["revenue_share_pct"].sum() == pytest.approx(100.0, abs=0.5)
        assert frame["exposure_share_pct"].sum() == pytest.approx(100.0, abs=0.5)
