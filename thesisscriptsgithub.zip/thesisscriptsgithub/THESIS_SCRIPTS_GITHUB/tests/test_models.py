"""Tests for the recommender implementations.

Every model is subjected to the same *contract* tests — correct output shape,
deterministic behaviour, refusal to score before fitting, exclusion of seen
items — plus algorithm-specific tests for the properties that define it (e.g.
the zero diagonal of the EASE weight matrix, the monotone decrease of the ALS
objective).
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest
import scipy.sparse as sp

from recsys.features.interactions import bm25_weight
from recsys.models import (
    ALSRecommender,
    AssociationRulesRecommender,
    BPRRecommender,
    ContentBasedRecommender,
    EASERecommender,
    HybridRecommender,
    ItemKNNRecommender,
    PopularityRecommender,
    available_models,
    build_model,
)
from recsys.models.base import top_n_from_scores
from recsys.models.hybrid import minmax_normalize, rank_normalize


# ---------------------------------------------------------------------------
# registry
# ---------------------------------------------------------------------------
class TestRegistry:
    def test_all_models_registered(self):
        expected = {
            "popularity", "item_knn", "ease", "als", "bpr",
            "content_based", "association_rules",
        }
        assert expected == set(available_models())

    def test_build_known_model(self):
        model = build_model("popularity", use_recency=False)
        assert isinstance(model, PopularityRecommender)

    def test_unknown_model_raises_with_hint(self):
        with pytest.raises(KeyError) as exc:
            build_model("transformer4rec")
        assert "Available models" in str(exc.value)


# ---------------------------------------------------------------------------
# shared ranking utilities
# ---------------------------------------------------------------------------
class TestTopN:
    def test_descending_order(self):
        scores = np.array([0.1, 0.9, 0.5, 0.7])
        result = top_n_from_scores(scores, 3)
        assert result.tolist() == [1, 3, 2]

    def test_respects_n(self):
        assert top_n_from_scores(np.random.rand(100), 7).size == 7

    def test_excludes_masked_entries(self):
        scores = np.array([1.0, -np.inf, 0.5, -np.inf])
        result = top_n_from_scores(scores, 4)
        assert result.tolist() == [0, 2]

    def test_n_larger_than_catalogue(self):
        assert top_n_from_scores(np.array([1.0, 2.0]), 10).size == 2

    def test_zero_n(self):
        assert top_n_from_scores(np.array([1.0, 2.0]), 0).size == 0


# ---------------------------------------------------------------------------
# model contract
# ---------------------------------------------------------------------------
MODEL_FACTORIES = [
    ("popularity", lambda: PopularityRecommender(use_recency=False)),
    ("item_knn", lambda: ItemKNNRecommender(top_k=30, shrinkage=5.0)),
    ("ease", lambda: EASERecommender(l2_regularization=100.0)),
    ("als", lambda: ALSRecommender(factors=8, iterations=2)),
    ("bpr", lambda: BPRRecommender(factors=8, epochs=2)),
    ("content_based", lambda: ContentBasedRecommender()),
    ("association_rules", lambda: AssociationRulesRecommender(min_support=0.002)),
]


@pytest.mark.parametrize("name,factory", MODEL_FACTORIES, ids=[m[0] for m in MODEL_FACTORIES])
class TestRecommenderContract:
    def test_scoring_before_fit_raises(self, name, factory, interactions, fit_context):
        with pytest.raises(RuntimeError):
            factory().score(0)

    def test_score_vector_shape(self, name, factory, interactions, fit_context):
        model = factory().fit(interactions, fit_context)
        scores = model.score(0)
        assert scores.shape == (interactions.n_items,)
        assert np.all(np.isfinite(scores))

    def test_recommend_length_and_range(self, name, factory, interactions, fit_context):
        model = factory().fit(interactions, fit_context)
        recommended = model.recommend(0, n=10)
        assert recommended.size <= 10
        assert np.all(recommended < interactions.n_items)
        assert recommended.size == np.unique(recommended).size

    def test_exclude_seen(self, name, factory, interactions, fit_context):
        model = factory().fit(interactions, fit_context)
        user = int(np.argmax(interactions.user_activity))
        seen = set(interactions.seen_items(user).tolist())
        recommended = model.recommend(user, n=10, exclude_seen=True)
        assert not (set(recommended.tolist()) & seen)

    def test_deterministic(self, name, factory, interactions, fit_context):
        model = factory().fit(interactions, fit_context)
        first = model.recommend(0, n=10)
        second = model.recommend(0, n=10)
        np.testing.assert_array_equal(first, second)

    def test_out_of_range_user(self, name, factory, interactions, fit_context):
        model = factory().fit(interactions, fit_context)
        with pytest.raises(IndexError):
            model.score(interactions.n_users + 5)

    def test_batch_matches_single(self, name, factory, interactions, fit_context):
        model = factory().fit(interactions, fit_context)
        users = [0, 1, 2]
        batch = model.score_batch(users)
        assert batch.shape == (3, interactions.n_items)
        for row, user in enumerate(users):
            np.testing.assert_allclose(batch[row], model.score(user), rtol=1e-5, atol=1e-8)

    def test_explanation_is_a_string(self, name, factory, interactions, fit_context):
        model = factory().fit(interactions, fit_context)
        user = int(np.argmax(interactions.user_activity))
        item = int(model.recommend(user, n=1)[0])
        assert isinstance(model.explain(user, item), str)


# ---------------------------------------------------------------------------
# algorithm-specific properties
# ---------------------------------------------------------------------------
class TestEASE:
    def test_zero_diagonal(self, interactions, fit_context):
        """The defining constraint of EASE: an item may not explain itself."""
        model = EASERecommender(l2_regularization=100.0).fit(interactions, fit_context)
        np.testing.assert_allclose(np.diag(model.B_), 0.0, atol=1e-12)

    def test_weight_matrix_is_square(self, interactions, fit_context):
        model = EASERecommender(l2_regularization=100.0).fit(interactions, fit_context)
        assert model.B_.shape == (interactions.n_items, interactions.n_items)

    def test_regularisation_shrinks_weights(self, interactions, fit_context):
        weak = EASERecommender(l2_regularization=10.0).fit(interactions, fit_context)
        strong = EASERecommender(l2_regularization=5000.0).fit(interactions, fit_context)
        assert np.abs(strong.B_).mean() < np.abs(weak.B_).mean()

    def test_non_positive_lambda_rejected(self):
        with pytest.raises(ValueError):
            EASERecommender(l2_regularization=0.0)


class TestItemKNN:
    def test_similarity_is_sparse_and_truncated(self, interactions, fit_context):
        k = 20
        model = ItemKNNRecommender(top_k=k, shrinkage=5.0).fit(interactions, fit_context)
        row_counts = np.diff(model.similarity_.indptr)
        assert row_counts.max() <= k

    def test_zero_self_similarity(self, interactions, fit_context):
        model = ItemKNNRecommender(top_k=20).fit(interactions, fit_context)
        np.testing.assert_allclose(model.similarity_.diagonal(), 0.0, atol=1e-12)

    def test_bm25_variant_fits_and_idf_is_item_indexed(self, interactions, fit_context):
        model = ItemKNNRecommender(top_k=20, similarity="bm25").fit(interactions, fit_context)
        assert model.similarity_.nnz > 0

        # Regression guard. BM25 document frequency must be counted per *item*
        # (matrix column), not per user: on a CSC matrix ``.indices`` holds row
        # indices, and using it silently produces a user-indexed IDF. Here item
        # 0 is held by all three users and item 2 by a single user, so the rare
        # item must receive the strictly larger weight.
        dense = np.array(
            [[1.0, 1.0, 0.0],
             [1.0, 1.0, 0.0],
             [1.0, 0.0, 1.0]]
        )
        weighted = bm25_weight(sp.csr_matrix(dense)).toarray()
        assert weighted[2, 2] > weighted[2, 0]

    def test_invalid_similarity_rejected(self):
        with pytest.raises(ValueError):
            ItemKNNRecommender(similarity="euclidean")


class TestPopularity:
    def test_decayed_popularity_counts_distinct_purchasers(self):
        """Regression guard: demand is measured in customers, not lines.

        Summing transaction lines turns the baseline into a bulk-order detector:
        a single wholesale buyer ordering one article twenty times would outrank
        an article bought once each by five separate customers.
        """
        model = PopularityRecommender(use_recency=True, recency_half_life_days=90.0)
        base = pd.Timestamp("2011-01-01")
        rows = [(0, 0, base)] * 20 + [(u, 1, base) for u in range(1, 6)]
        frame = pd.DataFrame(rows, columns=["user_idx", "item_idx", "invoice_date"])

        scores = model._decayed_popularity(frame, n_items=2)

        assert scores[0] == pytest.approx(1.0)   # one purchaser, twenty lines
        assert scores[1] == pytest.approx(5.0)   # five distinct purchasers
        assert scores[1] > scores[0]

    def test_recency_decay_halves_at_the_half_life(self):
        model = PopularityRecommender(use_recency=True, recency_half_life_days=30.0)
        now = pd.Timestamp("2011-03-01")
        frame = pd.DataFrame(
            [(0, 0, now), (1, 1, now - pd.Timedelta(days=30))],
            columns=["user_idx", "item_idx", "invoice_date"],
        )
        scores = model._decayed_popularity(frame, n_items=2)
        assert scores[0] == pytest.approx(1.0)
        assert scores[1] == pytest.approx(0.5)


class TestALS:
    def test_factor_shapes(self, interactions, fit_context):
        model = ALSRecommender(factors=12, iterations=2).fit(interactions, fit_context)
        assert model.user_factors_.shape == (interactions.n_users, 12)
        assert model.item_factors_.shape == (interactions.n_items, 12)

    def test_objective_decreases(self, interactions, fit_context):
        model = ALSRecommender(factors=8, iterations=5).fit(interactions, fit_context)
        history = model.loss_history_
        assert len(history) >= 2
        assert history[-1] <= history[0]


class TestBPR:
    def test_factor_shapes(self, interactions, fit_context):
        model = BPRRecommender(factors=10, epochs=2).fit(interactions, fit_context)
        assert model.user_factors_.shape == (interactions.n_users, 10)
        assert model.item_factors_.shape == (interactions.n_items, 10)

    def test_runs_the_full_configured_budget(self, interactions, fit_context):
        """Regression guard: the plateau test must not fire during warm-up.

        The loss starts at -log sigma(0) = log 2 with a near-zero gradient
        signal, so a tight plateau test applied from epoch 4 stopped training
        before it had begun and produced a near-random model.
        """
        epochs = 12
        model = BPRRecommender(factors=8, epochs=epochs).fit(interactions, fit_context)
        assert len(model.loss_history_) == epochs
        assert model.MIN_EPOCHS_BEFORE_STOP >= 10
        assert model.PLATEAU_TOLERANCE >= 1e-3

    def test_loss_falls_clearly_below_log2(self, interactions, fit_context):
        """The model must actually learn, not merely sit at initialisation."""
        model = BPRRecommender(factors=16, epochs=20).fit(interactions, fit_context)
        assert model.loss_history_[0] < np.log(2.0) + 0.05
        assert model.loss_history_[-1] < 0.9 * np.log(2.0)

    def test_epoch_budget_scales_with_interactions_not_users(
        self, interactions, fit_context
    ):
        """One triplet per observed interaction per epoch (Rendle's LearnBPR).

        Using the user count instead under-trains by a factor of nnz/n_users —
        roughly 75x on the full corpus. The observable consequence is that
        training must make real progress as the epoch budget grows.
        """
        assert interactions.binary.nnz > interactions.n_users

        short = BPRRecommender(factors=8, epochs=2).fit(interactions, fit_context)
        long = BPRRecommender(factors=8, epochs=12).fit(interactions, fit_context)
        assert long.loss_history_[-1] < short.loss_history_[-1]
        assert long.loss_history_[-1] < long.loss_history_[0]


class TestAssociationRules:
    def test_lift_threshold_respected(self, interactions, fit_context):
        model = AssociationRulesRecommender(
            min_support=0.002, min_confidence=0.05, min_lift=1.5
        ).fit(interactions, fit_context)
        assert all(rule.lift >= 1.5 for rule in model.rules_)

    def test_confidence_is_a_probability(self, interactions, fit_context):
        model = AssociationRulesRecommender(min_support=0.002).fit(interactions, fit_context)
        assert all(0.0 <= rule.confidence <= 1.0 for rule in model.rules_)

    def test_no_self_rules(self, interactions, fit_context):
        model = AssociationRulesRecommender(min_support=0.002).fit(interactions, fit_context)
        assert all(rule.antecedent != rule.consequent for rule in model.rules_)

    def test_rules_frame_export(self, interactions, fit_context):
        model = AssociationRulesRecommender(min_support=0.002).fit(interactions, fit_context)
        frame = model.rules_frame(10)
        if not frame.empty:
            assert {"antecedent", "consequent", "lift"} <= set(frame.columns)


# ---------------------------------------------------------------------------
# hybrid
# ---------------------------------------------------------------------------
class TestNormalisation:
    def test_rank_normalize_range(self):
        scores = np.array([5.0, 1.0, 3.0])
        out = rank_normalize(scores)
        assert out.max() == pytest.approx(1.0)
        assert out.min() == pytest.approx(0.0)
        assert out[0] > out[2] > out[1]

    def test_rank_normalize_is_scale_invariant(self):
        a = rank_normalize(np.array([1.0, 2.0, 3.0]))
        b = rank_normalize(np.array([1000.0, 2000.0, 3000.0]))
        np.testing.assert_allclose(a, b)

    def test_minmax_constant_input(self):
        out = minmax_normalize(np.array([2.0, 2.0, 2.0]))
        np.testing.assert_allclose(out, 0.0)


class TestHybrid:
    @pytest.fixture
    def base_models(self, interactions, fit_context):
        return {
            "popularity": PopularityRecommender(use_recency=False).fit(interactions, fit_context),
            "item_knn": ItemKNNRecommender(top_k=20).fit(interactions, fit_context),
            "ease": EASERecommender(l2_regularization=100.0).fit(interactions, fit_context),
        }

    @pytest.mark.parametrize("strategy", ["weighted", "rrf", "switching", "cascade"])
    def test_every_strategy_produces_valid_output(
        self, strategy, base_models, interactions, fit_context
    ):
        hybrid = HybridRecommender(
            base_models=base_models,
            strategy=strategy,
            weights={"ease": 0.5, "item_knn": 0.3, "popularity": 0.2},
            cascade_retrieval_model="item_knn",
        ).fit(interactions, fit_context)

        recommended = hybrid.recommend(0, n=10)
        assert recommended.size <= 10
        assert np.all(recommended < interactions.n_items)

    def test_weights_are_normalised(self, base_models, interactions, fit_context):
        hybrid = HybridRecommender(
            base_models=base_models, weights={"ease": 2.0, "item_knn": 2.0}
        ).fit(interactions, fit_context)
        assert sum(hybrid.weights.values()) == pytest.approx(1.0)

    def test_unfitted_base_rejected(self, interactions, fit_context):
        hybrid = HybridRecommender(base_models={"pop": PopularityRecommender()})
        with pytest.raises(RuntimeError):
            hybrid.fit(interactions, fit_context)

    def test_invalid_strategy_rejected(self, base_models):
        with pytest.raises(ValueError):
            HybridRecommender(base_models=base_models, strategy="stacking")

    def test_empty_base_models_rejected(self):
        with pytest.raises(ValueError):
            HybridRecommender(base_models={})

    def test_contribution_breakdown(self, base_models, interactions, fit_context):
        hybrid = HybridRecommender(base_models=base_models).fit(interactions, fit_context)
        item = int(hybrid.recommend(0, n=1)[0])
        breakdown = hybrid.contribution_breakdown(0, item)
        assert set(breakdown) <= set(base_models)
