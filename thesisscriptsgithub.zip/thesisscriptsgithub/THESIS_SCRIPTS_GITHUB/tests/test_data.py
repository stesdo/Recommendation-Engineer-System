"""Tests for the data acquisition, cleaning and partitioning layer.

The partitioning tests are the most consequential in the suite: they assert the
*absence of temporal leakage*, which is the property on which the validity of
every reported metric depends.
"""

from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from recsys.config import PreprocessingConfig, SplittingConfig
from recsys.data.loader import CANONICAL_COLUMNS, DataLoader
from recsys.data.preprocessing import (
    TransactionCleaner,
    compute_dataset_statistics,
    gini_coefficient,
)
from recsys.data.splitting import TemporalSplitter


class TestSyntheticGeneration:
    def test_schema(self, raw_frame: pd.DataFrame):
        for column in CANONICAL_COLUMNS:
            assert column in raw_frame.columns

    def test_non_trivial_size(self, raw_frame: pd.DataFrame):
        assert len(raw_frame) > 1000
        assert raw_frame["customer_id"].nunique() > 50
        assert raw_frame["stock_code"].nunique() > 50

    def test_reproducible(self):
        a = DataLoader._synthesise(2000, seed=123)
        b = DataLoader._synthesise(2000, seed=123)
        pd.testing.assert_frame_equal(a, b)

    def test_power_law_popularity(self, raw_frame: pd.DataFrame):
        """The surrogate must reproduce the concentration of real retail data."""
        popularity = raw_frame.groupby("stock_code")["customer_id"].nunique()
        assert gini_coefficient(popularity.to_numpy(dtype=float)) > 0.3


class TestCleaning:
    def test_removes_cancellations(self):
        frame = pd.DataFrame(
            {
                "invoice": ["536365", "C536366"],
                "stock_code": ["85123A", "85123A"],
                "description": ["X", "X"],
                "quantity": [2, 2],
                "invoice_date": pd.to_datetime(["2010-01-01", "2010-01-02"]),
                "unit_price": [2.5, 2.5],
                "customer_id": [17850.0, 17850.0],
                "country": ["UK", "UK"],
            }
        )
        cfg = PreprocessingConfig(min_item_interactions=1, min_user_interactions=1)
        clean = TransactionCleaner(cfg).clean(frame)
        assert not clean["invoice"].str.startswith("C").any()

    def test_removes_negative_quantity(self):
        frame = pd.DataFrame(
            {
                "invoice": ["1", "2"],
                "stock_code": ["85123A", "85123A"],
                "description": ["X", "X"],
                "quantity": [5, -3],
                "invoice_date": pd.to_datetime(["2010-01-01", "2010-01-02"]),
                "unit_price": [2.5, 2.5],
                "customer_id": [17850.0, 17850.0],
                "country": ["UK", "UK"],
            }
        )
        cfg = PreprocessingConfig(min_item_interactions=1, min_user_interactions=1)
        clean = TransactionCleaner(cfg).clean(frame)
        assert (clean["quantity"] > 0).all()

    def test_removes_missing_customer(self, raw_frame: pd.DataFrame):
        frame = raw_frame.copy()
        frame.loc[frame.index[:100], "customer_id"] = np.nan
        cfg = PreprocessingConfig(min_item_interactions=1, min_user_interactions=1)
        clean = TransactionCleaner(cfg).clean(frame)
        assert clean["customer_id"].notna().all()

    def test_k_core_guarantee(self, raw_frame: pd.DataFrame):
        cfg = PreprocessingConfig(min_item_interactions=5, min_user_interactions=5)
        clean = TransactionCleaner(cfg).clean(raw_frame)
        user_degree = clean.groupby("customer_id")["stock_code"].nunique()
        item_degree = clean.groupby("stock_code")["customer_id"].nunique()
        assert user_degree.min() >= 5
        assert item_degree.min() >= 5

    def test_report_is_monotone(self, raw_frame: pd.DataFrame):
        cfg = PreprocessingConfig()
        cleaner = TransactionCleaner(cfg)
        cleaner.clean(raw_frame)
        report = cleaner.report.to_frame()
        assert (report["rows_after"] <= report["rows_before"]).all()

    def test_revenue_column_added(self, clean_frame: pd.DataFrame):
        assert "revenue" in clean_frame.columns
        expected = clean_frame["quantity"] * clean_frame["unit_price"]
        np.testing.assert_allclose(clean_frame["revenue"], expected)


class TestStatistics:
    def test_expected_keys(self, clean_frame: pd.DataFrame):
        stats = compute_dataset_statistics(clean_frame)
        for key in (
            "n_users", "n_items", "density_pct", "gini_item_popularity",
            "mean_basket_size", "total_revenue",
        ):
            assert key in stats

    def test_density_is_a_proportion(self, clean_frame: pd.DataFrame):
        stats = compute_dataset_statistics(clean_frame)
        assert 0.0 <= stats["density_pct"] <= 100.0
        assert stats["density_pct"] + stats["sparsity_pct"] == pytest.approx(100.0)

    def test_gini_uniform_is_zero(self):
        assert gini_coefficient(np.ones(50)) == pytest.approx(0.0, abs=0.02)


class TestTemporalSplitting:
    def test_no_temporal_leakage(self, split):
        """Every training event must strictly precede every test event."""
        if split.train.empty or split.test.empty:
            pytest.skip("degenerate split")
        assert split.train["invoice_date"].max() < split.test["invoice_date"].min()

    def test_ground_truth_excludes_already_purchased_items(self, split):
        """Regression guard: targets must be reachable by the ranker.

        ``recommend(exclude_seen=True)`` masks train-purchased items out of the
        candidate set, so retaining them in the ground truth would leave targets
        no model can ever return and cap recall/NDCG below 1 by a
        user-dependent amount.
        """
        seen = split.train_seen_items()
        truth = split.test_ground_truth(exclude_seen=True)
        assert truth
        for user, items in truth.items():
            already = seen.get(user)
            if already is not None and already.size:
                assert not np.intersect1d(items, already).size
            assert items.size > 0

        unfiltered = split.test_ground_truth(exclude_seen=False)
        total_filtered = sum(int(v.size) for v in truth.values())
        total_unfiltered = sum(int(v.size) for v in unfiltered.values())
        assert total_filtered <= total_unfiltered

    def test_validation_between_train_and_test(self, split):
        if split.validation.empty:
            pytest.skip("no validation partition")
        assert split.train["invoice_date"].max() <= split.validation["invoice_date"].min()
        assert split.validation["invoice_date"].max() <= split.test["invoice_date"].min()

    def test_vocabulary_from_training_only(self, split):
        """Test items must never introduce indices outside the training space."""
        assert split.test["item_idx"].max() < split.n_items
        assert split.test["user_idx"].max() < split.n_users

    def test_index_maps_are_bijective(self, split):
        assert len(split.user_map) == split.n_users
        assert len(split.item_map) == split.n_items
        for raw_id, idx in list(split.user_map.items())[:20]:
            assert split.user_ids[idx] == raw_id

    def test_ground_truth_structure(self, split):
        truth = split.test_ground_truth()
        assert truth
        for user, items in list(truth.items())[:20]:
            assert isinstance(user, int)
            assert items.size > 0
            assert items.max() < split.n_items

    def test_leave_last_out(self, clean_frame):
        cfg = SplittingConfig(strategy="leave_last_out", min_train_interactions_for_eval=1)
        result = TemporalSplitter(cfg).split(clean_frame)
        # At most one held-out event per user.
        counts = result.test.groupby("user_idx")["invoice_date"].nunique()
        assert (counts <= 1).all()

    def test_empty_input_rejected(self):
        cfg = SplittingConfig()
        with pytest.raises(ValueError):
            TemporalSplitter(cfg).split(pd.DataFrame())
