"""Shared pytest fixtures.

The fixtures build a small but structurally realistic corpus so that the tests
exercise the same code paths as a full run while completing in seconds.
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

# Make ``src`` importable without requiring an editable install.
SRC = Path(__file__).resolve().parents[1] / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from recsys.config import (  # noqa: E402
    EvaluationConfig,
    FeatureConfig,
    PreprocessingConfig,
    SplittingConfig,
    StatisticsConfig,
)
from recsys.data.loader import DataLoader  # noqa: E402
from recsys.data.preprocessing import TransactionCleaner  # noqa: E402
from recsys.data.splitting import TemporalSplitter  # noqa: E402
from recsys.features.content import ContentFeatureBuilder  # noqa: E402
from recsys.features.interactions import InteractionBuilder  # noqa: E402


@pytest.fixture(scope="session")
def raw_frame() -> pd.DataFrame:
    """A small synthetic transaction log in the canonical schema."""
    return DataLoader._synthesise(n_transactions=9_000, seed=7)


@pytest.fixture(scope="session")
def clean_frame(raw_frame: pd.DataFrame) -> pd.DataFrame:
    cfg = PreprocessingConfig(min_item_interactions=3, min_user_interactions=3)
    return TransactionCleaner(cfg).clean(raw_frame)


@pytest.fixture(scope="session")
def split(clean_frame: pd.DataFrame):
    cfg = SplittingConfig(
        strategy="temporal_global",
        test_ratio=0.2,
        validation_ratio=0.1,
        min_train_interactions_for_eval=2,
    )
    return TemporalSplitter(cfg).split(clean_frame)


@pytest.fixture(scope="session")
def interactions(split):
    cfg = FeatureConfig(weighting="log_count", apply_recency_decay=False)
    return InteractionBuilder(cfg).build(
        split.train, n_users=split.n_users, n_items=split.n_items
    )


@pytest.fixture(scope="session")
def content(split):
    cfg = FeatureConfig(tfidf_min_df=1, tfidf_max_features=500)
    return ContentFeatureBuilder(cfg).build(split.train, n_items=split.n_items)


@pytest.fixture(scope="session")
def fit_context(split, content):
    from recsys.models.base import FitContext

    return FitContext(
        train_frame=split.train,
        content_features=content,
        item_ids=split.item_ids,
        user_ids=split.user_ids,
        random_seed=7,
    )


@pytest.fixture
def evaluation_config() -> EvaluationConfig:
    return EvaluationConfig(
        cutoffs=[5, 10],
        primary_cutoff=10,
        primary_metric="ndcg@10",
        max_eval_users=120,
    )


@pytest.fixture
def statistics_config() -> StatisticsConfig:
    return StatisticsConfig(bootstrap_iterations=100)
