# Thesis Recommendation Engine — Final Scripts

This is the clean, GitHub-ready source package for thesis. It contains
the final recommendation-engine implementation, the experiment configuration,
the reproducible analysis notebook, thesis figure sources, tests, and the
the scripts used to prepare and validate the analysis deliverables.

## Included

- `src/recsys/` — complete Python recommendation-engine package.
- `scripts/` — notebook finalisation, figure embedding, and deliverable checks.
- `verify_thesis_match.py` — full evidence audit when the reference run and
  final thesis files are available.
- `config/config.yaml` — canonical experiment configuration.
- `notebooks/01_analysis_and_results.ipynb` — source analysis notebook.
- `notebooks/figures/` — the 13 final thesis figures used by the Markdown
  thesis and analysis notebook.
- `thesis/thesis.md` — thesis source and reference for the reported analysis.
- `tests/` — unit and integration tests.
- `pyproject.toml` and `requirements.txt` — package and environment metadata.

## Deliberately excluded from this GitHub package

The following are not source scripts and are intentionally omitted to keep the
repository portable and safe to publish:

- raw and processed customer data (`data/`),
- generated experiment outputs (`artifacts/` and `reference_run_*`),
- executed notebook output,
- generated DOCX/PDF thesis binaries,
- Python caches, virtual environments, and local IDE files.

The configured pipeline downloads the public UCI Online Retail II dataset when
needed. Do not commit downloaded data or generated outputs; the included
`.gitignore` prevents accidental commits.

## Quick start (PowerShell)

From this folder:

```powershell
py -3 -m venv .venv
.venv\Scripts\python -m pip install --upgrade pip
.venv\Scripts\python -m pip install -r requirements.txt
.venv\Scripts\python -m pip install -e .
```

Run the tests:

```powershell
.venv\Scripts\python -m pytest tests -q
```

Run the recommendation pipeline. It downloads the public dataset if it is not
already available locally and writes generated results under `artifacts/`:

```powershell
.venv\Scripts\python -m recsys.cli download
.venv\Scripts\python -m recsys.cli run --config config/config.yaml
```

The command-line entry points also support:

```powershell
.venv\Scripts\python -m recsys.cli recommend --top-n 10 --explain
.venv\Scripts\python -m recsys.cli serve
```

## Notebook and analysis scripts

Normalise the source notebook before a canonical run:

```powershell
.venv\Scripts\python scripts/finalize_notebook.py
```

Execute the notebook with Jupyter, if desired:

```powershell
.venv\Scripts\python -m pip install jupyter
.venv\Scripts\jupyter nbconvert --to notebook --execute `
  --output notebooks/01_analysis_and_results.executed.ipynb `
  notebooks/01_analysis_and_results.ipynb
```

The figure-embedding helper expects the executed notebook and the generated
figure files to exist:

```powershell
.venv\Scripts\python scripts/embed_notebook_figures.py
```

## Validation

Validate the source package without the omitted experiment data:

```powershell
.venv\Scripts\python scripts/verify_source_package.py
```

`verify_deliverables.py` and `verify_thesis_match.py` are full submission
audits. They require the generated reference run, executed notebook, and final
thesis files, so they are expected to report missing inputs in this slim source
package until those files are supplied locally. This package does not contain
code that writes thesis chapters or generates DOCX/PDF thesis documents.

## Reproducibility note

The default configuration uses a fixed random seed and stores generated run
metadata under `artifacts/`. The public dataset URL and all experimental
parameters are declared in `config/config.yaml`; no credentials or private
data are required.