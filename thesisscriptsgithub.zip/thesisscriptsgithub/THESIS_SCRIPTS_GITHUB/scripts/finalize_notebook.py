"""Prepare the thesis notebook for a canonical, reproducible final run.

The script is intentionally small and deterministic.  It removes the historical
"quick notebook" overrides, inserts a complete parameter ledger derived from
``config/config.yaml``, assigns stable cell ids, clears stale outputs, and writes
the normalized notebook in place.

Run from the project root::

    python scripts/finalize_notebook.py
"""

from __future__ import annotations

import hashlib
from pathlib import Path

import nbformat


PROJECT_ROOT = Path(__file__).resolve().parents[1]
NOTEBOOK = PROJECT_ROOT / "notebooks" / "01_analysis_and_results.ipynb"


PARAMETER_CELL_MARKER = "ΠΑΡΑΜΕΤΡΟΠΟΙΗΣΗ ΠΕΙΡΑΜΑΤΟΣ"


CANONICAL_CONFIG_CELL = r'''import logging
from dataclasses import asdict
from recsys.config import load_config
from recsys.logging_utils import configure_logging

configure_logging(level=logging.WARNING, force=True)   # ήσυχη έξοδος στο notebook

# Η τελική εκτέλεση χρησιμοποιεί αυτούσιο το config/config.yaml. Δεν υπάρχουν
# κρυφές notebook-only μειώσεις σε χρήστες αξιολόγησης, epochs ή bootstrap.
cfg = load_config(PROJECT_ROOT / "config" / "config.yaml")

print("ΠΑΡΑΜΕΤΡΟΠΟΙΗΣΗ ΠΕΙΡΑΜΑΤΟΣ — ΚΑΝΟΝΙΚΗ ΠΛΗΡΗΣ ΕΚΤΕΛΕΣΗ")
print("-" * 86)
print(f"  random_seed              : {cfg.experiment.random_seed}")
print(f"  στρατηγική διαχωρισμού   : {cfg.splitting.strategy}")
print(f"  test / validation ratio  : {cfg.splitting.test_ratio} / {cfg.splitting.validation_ratio}")
print(f"  στάθμιση αλληλεπιδράσεων : {cfg.features.weighting}")
print(f"  χρόνος ημιζωής (recency) : {cfg.features.recency_half_life_days} ημέρες")
print(f"  k-core (χρήστες/είδη)    : ≥{cfg.preprocessing.min_user_interactions} / ≥{cfg.preprocessing.min_item_interactions}")
print(f"  σημεία αποκοπής (cutoffs): {cfg.evaluation.cutoffs}")
print(f"  κύρια μετρική            : {cfg.evaluation.primary_metric}")
print(f"  μέγιστοι χρήστες eval    : {cfg.evaluation.max_eval_users}")
print(f"  bootstrap επαναλήψεις    : {cfg.statistics.bootstrap_iterations}")
print(f"  ενεργά μοντέλα           : {cfg.models.enabled_models()}")
print("-" * 86)

# Πλήρες μητρώο υπερπαραμέτρων όλων των μοντέλων. Η τιμή προέρχεται από το
# effective Config που καταναλώνει το Pipeline, όχι από χειρόγραφη τεκμηρίωση.
parameter_rows = []
for model_name in cfg.models.enabled_models():
    for parameter, value in cfg.models.params(model_name).items():
        if isinstance(value, dict):
            value = ", ".join(f"{k}={v}" for k, v in value.items())
        parameter_rows.append({
            "Μοντέλο": model_name,
            "Παράμετρος": parameter,
            "Τιμή": value,
        })

model_parameter_table = pd.DataFrame(parameter_rows)
display(model_parameter_table.style.hide(axis="index").set_caption(
    "Πλήρες μητρώο παραμέτρων μοντέλων της τελικής εκτέλεσης"
))

# Το πλήρες effective configuration παραμένει διαθέσιμο για έλεγχο και
# αποθηκεύεται επίσης αυτούσιο ως config.snapshot.yaml στον κατάλογο του run.
effective_configuration = cfg.to_dict()
'''


def stable_cell_id(index: int, source: str) -> str:
    digest = hashlib.sha1(source.encode("utf-8")).hexdigest()[:8]
    return f"cell-{index:02d}-{digest}"


def main() -> None:
    notebook = nbformat.read(NOTEBOOK, as_version=4)

    target = None
    for cell in notebook.cells:
        if cell.cell_type == "code" and PARAMETER_CELL_MARKER in cell.source:
            target = cell
            break
    if target is None:
        raise RuntimeError("Could not locate the notebook configuration cell.")

    target.source = CANONICAL_CONFIG_CELL

    for index, cell in enumerate(notebook.cells):
        cell["id"] = stable_cell_id(index, cell.source)
        if cell.cell_type == "code":
            cell["execution_count"] = None
            cell["outputs"] = []

    notebook.metadata.setdefault("language_info", {})["name"] = "python"
    notebook.metadata.setdefault("kernelspec", {}).update(
        {"display_name": "Python 3", "language": "python", "name": "python3"}
    )

    nbformat.validate(notebook)
    nbformat.write(notebook, NOTEBOOK)
    print(f"Normalized canonical notebook: {NOTEBOOK}")
    print(f"Cells: {len(notebook.cells)}; code: {sum(c.cell_type == 'code' for c in notebook.cells)}")


if __name__ == "__main__":
    main()
