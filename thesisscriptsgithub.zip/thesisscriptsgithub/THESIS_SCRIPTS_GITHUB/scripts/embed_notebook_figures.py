"""Embed the exact saved figure PNGs into the executed thesis notebook.

The pipeline already generated these files during the successful canonical run.
Some Windows headless kernels do not emit Matplotlib MIME bundles despite
``plt.show()``; this deterministic post-processing step attaches the generated
PNGs to their producing cells without changing code, execution counts or data.
"""

from __future__ import annotations

import base64
from pathlib import Path

import nbformat


ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "notebooks" / "01_analysis_and_results.ipynb"
EXECUTED = ROOT / "notebooks" / "01_analysis_and_results.executed.ipynb"
FIGURES = ROOT / "notebooks" / "figures"

FIGURE_CELLS = {
    9: "fig_5_1_dataset_structure.png",
    10: "fig_5_2_temporal_dynamics.png",
    12: "fig_5_3_cleaning_attrition.png",
    13: "fig_5_4_temporal_split.png",
    16: "fig_6_1_accuracy_comparison.png",
    19: "fig_6_2_beyond_accuracy.png",
    22: "fig_6_3_statistical_validation.png",
    24: "fig_6_4_computational_cost.png",
    27: "fig_7_1_rfm_clv.png",
    30: "fig_7_2_crosssell_longtail.png",
    34: "fig_7_3_revenue_simulation.png",
    38: "fig_8_1_per_user_comparison.png",
    43: "fig_9_1_summary_dashboard.png",
}


def enable_inline_backend() -> None:
    notebook = nbformat.read(SOURCE, as_version=4)
    setup = notebook.cells[3]
    command = "get_ipython().run_line_magic('matplotlib', 'inline')"
    if command not in setup.source:
        setup.source = command + "\n\n" + setup.source
    nbformat.validate(notebook)
    nbformat.write(notebook, SOURCE)


def embed() -> None:
    notebook = nbformat.read(EXECUTED, as_version=4)
    for cell_index, filename in FIGURE_CELLS.items():
        path = FIGURES / filename
        if not path.is_file():
            raise FileNotFoundError(path)
        cell = notebook.cells[cell_index]
        cell.outputs = [
            output
            for output in cell.outputs
            if "image/png" not in output.get("data", {})
        ]
        encoded = base64.b64encode(path.read_bytes()).decode("ascii")
        cell.outputs.append(
            nbformat.v4.new_output(
                output_type="display_data",
                data={"image/png": encoded, "text/plain": f"<{filename}>"},
                metadata={"embedded_from": f"notebooks/figures/{filename}"},
            )
        )
    nbformat.validate(notebook)
    nbformat.write(notebook, EXECUTED)
    print(f"Embedded {len(FIGURE_CELLS)} figures into {EXECUTED}")


def main() -> None:
    enable_inline_backend()
    embed()


if __name__ == "__main__":
    main()
