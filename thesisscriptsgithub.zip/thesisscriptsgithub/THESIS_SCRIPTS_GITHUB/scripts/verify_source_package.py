"""Validate the publishable source package without requiring experiment data."""

from __future__ import annotations

import ast
from pathlib import Path

import nbformat


ROOT = Path(__file__).resolve().parents[1]
REQUIRED_FILES = (
    Path("pyproject.toml"),
    Path("requirements.txt"),
    Path("config/config.yaml"),
    Path("notebooks/01_analysis_and_results.ipynb"),
    Path("thesis/thesis.md"),
)


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    print(f"PASS  {message}")


def main() -> None:
    for relative_path in REQUIRED_FILES:
        require((ROOT / relative_path).is_file(), f"required file exists: {relative_path}")

    python_files = sorted(ROOT.glob("src/**/*.py")) + sorted(ROOT.glob("scripts/*.py"))
    require(bool(python_files), "Python source files exist")
    for path in python_files:
        ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    print(f"PASS  Python syntax is valid ({len(python_files)} files)")

    notebook = nbformat.read(ROOT / "notebooks/01_analysis_and_results.ipynb", as_version=4)
    nbformat.validate(notebook)
    code_cells = [cell for cell in notebook.cells if cell.cell_type == "code"]
    require(bool(code_cells), "analysis notebook contains executable code")
    require(
        all(cell.execution_count is None for cell in code_cells),
        "source notebook has no stale execution counts",
    )

    figures = sorted((ROOT / "notebooks/figures").glob("*.png"))
    require(len(figures) == 13, "all 13 thesis figures are included")
    require(not (ROOT / "data").exists(), "raw/processed data is not bundled")
    require(not (ROOT / "artifacts").exists(), "generated artifacts are not bundled")
    print("\nSource package validation passed.")


if __name__ == "__main__":
    main()