"""Fail-fast verification for the final thesis submission artefacts."""

from __future__ import annotations

import json
import zipfile
from pathlib import Path

import nbformat
from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
NOTEBOOK = ROOT / "notebooks" / "01_analysis_and_results.executed.ipynb"
FIGURES = ROOT / "notebooks" / "figures"
THESIS_MD = ROOT / "thesis" / "thesis.md"
THESIS_DOCX = ROOT / "thesis" / "thesis_final.docx"
THESIS_PDF = ROOT / "thesis" / "thesis_final.pdf"

EXPECTED_FIGURES = {
    "fig_5_1_dataset_structure.png",
    "fig_5_2_temporal_dynamics.png",
    "fig_5_3_cleaning_attrition.png",
    "fig_5_4_temporal_split.png",
    "fig_6_1_accuracy_comparison.png",
    "fig_6_2_beyond_accuracy.png",
    "fig_6_3_statistical_validation.png",
    "fig_6_4_computational_cost.png",
    "fig_7_1_rfm_clv.png",
    "fig_7_2_crosssell_longtail.png",
    "fig_7_3_revenue_simulation.png",
    "fig_8_1_per_user_comparison.png",
    "fig_9_1_summary_dashboard.png",
}


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)
    print(f"PASS  {message}")


def main() -> None:
    require(NOTEBOOK.is_file(), "executed notebook exists")
    nb = nbformat.read(NOTEBOOK, as_version=4)
    code = [cell for cell in nb.cells if cell.cell_type == "code"]
    require(all(cell.execution_count is not None for cell in code), "every code cell executed")
    errors = [
        output
        for cell in code
        for output in cell.get("outputs", [])
        if output.get("output_type") == "error"
    ]
    require(not errors, "executed notebook contains no error outputs")
    require(len({cell.id for cell in nb.cells}) == len(nb.cells), "notebook cell ids are unique")

    available = {path.name for path in FIGURES.glob("*.png")}
    require(EXPECTED_FIGURES <= available, "all 13 required empirical figures exist")
    for name in sorted(EXPECTED_FIGURES):
        path = FIGURES / name
        with Image.open(path) as image:
            require(image.width >= 1200 and image.height >= 700, f"{name} has print-ready dimensions")

    text = THESIS_MD.read_text(encoding="utf-8")
    words = len(text.split())
    require(words >= 12_000, f"thesis exceeds 12,000 words ({words:,})")
    require("Complete model hyperparameters" in text, "thesis contains the complete model-parameter table")
    require(text.count("../notebooks/figures/") == 13, "thesis references all 13 empirical figures")

    require(THESIS_DOCX.is_file() and THESIS_DOCX.stat().st_size > 1_000_000, "final DOCX exists")
    with zipfile.ZipFile(THESIS_DOCX) as archive:
        require(archive.testzip() is None, "final DOCX package is structurally valid")
    require(THESIS_PDF.is_file() and THESIS_PDF.stat().st_size > 1_000_000, "final PDF exists")

    print("\nAll final submission checks passed.")


if __name__ == "__main__":
    main()
