"""Typed configuration layer.

The whole experimental apparatus is driven by a single YAML document. This
module maps that document onto frozen dataclasses so that (a) every consumer
receives static typing and IDE completion, (b) invalid configurations fail
loudly at load time rather than deep inside a training loop, and (c) the exact
configuration of any run can be serialised back to disk for reproducibility.

Design notes
------------
* ``from_dict`` constructors are explicit rather than reflective. Explicitness
  costs a few lines but yields precise error messages and prevents silent
  acceptance of misspelled keys.
* Validation is performed in ``__post_init__`` so that a malformed value can
  never propagate into the numerical core.
"""

from __future__ import annotations

import copy
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

__all__ = [
    "ExperimentConfig",
    "DataConfig",
    "PreprocessingConfig",
    "SplittingConfig",
    "FeatureConfig",
    "ModelsConfig",
    "EvaluationConfig",
    "StatisticsConfig",
    "BusinessConfig",
    "ServiceConfig",
    "Config",
    "load_config",
]


# ---------------------------------------------------------------------------
# helpers
# ---------------------------------------------------------------------------
def _require(mapping: Dict[str, Any], key: str, section: str) -> Any:
    if key not in mapping:
        raise KeyError(f"Missing required configuration key '{section}.{key}'.")
    return mapping[key]


def _positive(value: float, name: str) -> float:
    if value <= 0:
        raise ValueError(f"'{name}' must be strictly positive, got {value!r}.")
    return value


def _non_negative(value: float, name: str) -> float:
    if value < 0:
        raise ValueError(f"'{name}' must be non-negative, got {value!r}.")
    return value


def _in_unit_interval(value: float, name: str) -> float:
    if not 0.0 <= value <= 1.0:
        raise ValueError(f"'{name}' must lie in [0, 1], got {value!r}.")
    return value


# ---------------------------------------------------------------------------
# sections
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ExperimentConfig:
    name: str = "experiment"
    random_seed: int = 42
    artifacts_dir: str = "artifacts"
    save_figures: bool = True

    def __post_init__(self) -> None:
        if not self.name.strip():
            raise ValueError("experiment.name must not be empty.")
        if self.random_seed < 0:
            raise ValueError("experiment.random_seed must be non-negative.")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ExperimentConfig":
        d = d or {}
        return cls(
            name=str(d.get("name", "experiment")),
            random_seed=int(d.get("random_seed", 42)),
            artifacts_dir=str(d.get("artifacts_dir", "artifacts")),
            save_figures=bool(d.get("save_figures", True)),
        )


@dataclass(frozen=True)
class DataConfig:
    raw_dir: str = "data/raw"
    processed_dir: str = "data/processed"
    url: str = ""
    filename: str = "online_retail_II.xlsx"
    allow_synthetic_fallback: bool = True
    synthetic_n_transactions: int = 120_000
    use_cache: bool = True

    def __post_init__(self) -> None:
        _positive(self.synthetic_n_transactions, "data.synthetic_n_transactions")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "DataConfig":
        d = d or {}
        return cls(
            raw_dir=str(d.get("raw_dir", "data/raw")),
            processed_dir=str(d.get("processed_dir", "data/processed")),
            url=str(d.get("url", "")),
            filename=str(d.get("filename", "online_retail_II.xlsx")),
            allow_synthetic_fallback=bool(d.get("allow_synthetic_fallback", True)),
            synthetic_n_transactions=int(d.get("synthetic_n_transactions", 120_000)),
            use_cache=bool(d.get("use_cache", True)),
        )


@dataclass(frozen=True)
class PreprocessingConfig:
    drop_missing_customer: bool = True
    drop_cancellations: bool = True
    drop_non_product_codes: bool = True
    min_quantity: int = 1
    min_unit_price: float = 0.01
    max_unit_price: float = 10_000.0
    remove_price_outliers: bool = True
    outlier_quantile: float = 0.999
    min_item_interactions: int = 5
    min_user_interactions: int = 5
    k_core_max_iterations: int = 20

    def __post_init__(self) -> None:
        _in_unit_interval(self.outlier_quantile, "preprocessing.outlier_quantile")
        if self.min_unit_price >= self.max_unit_price:
            raise ValueError("preprocessing.min_unit_price must be < max_unit_price.")
        _positive(self.k_core_max_iterations, "preprocessing.k_core_max_iterations")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "PreprocessingConfig":
        d = d or {}
        return cls(
            drop_missing_customer=bool(d.get("drop_missing_customer", True)),
            drop_cancellations=bool(d.get("drop_cancellations", True)),
            drop_non_product_codes=bool(d.get("drop_non_product_codes", True)),
            min_quantity=int(d.get("min_quantity", 1)),
            min_unit_price=float(d.get("min_unit_price", 0.01)),
            max_unit_price=float(d.get("max_unit_price", 10_000.0)),
            remove_price_outliers=bool(d.get("remove_price_outliers", True)),
            outlier_quantile=float(d.get("outlier_quantile", 0.999)),
            min_item_interactions=int(d.get("min_item_interactions", 5)),
            min_user_interactions=int(d.get("min_user_interactions", 5)),
            k_core_max_iterations=int(d.get("k_core_max_iterations", 20)),
        )


@dataclass(frozen=True)
class SplittingConfig:
    strategy: str = "temporal_global"
    test_ratio: float = 0.20
    validation_ratio: float = 0.10
    min_train_interactions_for_eval: int = 3

    _ALLOWED = ("temporal_global", "leave_last_out")

    def __post_init__(self) -> None:
        if self.strategy not in self._ALLOWED:
            raise ValueError(
                f"splitting.strategy must be one of {self._ALLOWED}, got {self.strategy!r}."
            )
        _in_unit_interval(self.test_ratio, "splitting.test_ratio")
        _in_unit_interval(self.validation_ratio, "splitting.validation_ratio")
        if self.test_ratio + self.validation_ratio >= 1.0:
            raise ValueError("splitting: test_ratio + validation_ratio must be < 1.")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "SplittingConfig":
        d = d or {}
        return cls(
            strategy=str(d.get("strategy", "temporal_global")),
            test_ratio=float(d.get("test_ratio", 0.20)),
            validation_ratio=float(d.get("validation_ratio", 0.10)),
            min_train_interactions_for_eval=int(
                d.get("min_train_interactions_for_eval", 3)
            ),
        )


@dataclass(frozen=True)
class FeatureConfig:
    weighting: str = "log_count"
    log_alpha: float = 1.0
    recency_half_life_days: float = 180.0
    apply_recency_decay: bool = True
    tfidf_max_features: int = 5000
    tfidf_ngram_max: int = 2
    tfidf_min_df: int = 2

    _ALLOWED = ("binary", "count", "log_count", "monetary")

    def __post_init__(self) -> None:
        if self.weighting not in self._ALLOWED:
            raise ValueError(
                f"features.weighting must be one of {self._ALLOWED}, got {self.weighting!r}."
            )
        _positive(self.recency_half_life_days, "features.recency_half_life_days")
        _non_negative(self.log_alpha, "features.log_alpha")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "FeatureConfig":
        d = d or {}
        return cls(
            weighting=str(d.get("weighting", "log_count")),
            log_alpha=float(d.get("log_alpha", 1.0)),
            recency_half_life_days=float(d.get("recency_half_life_days", 180.0)),
            apply_recency_decay=bool(d.get("apply_recency_decay", True)),
            tfidf_max_features=int(d.get("tfidf_max_features", 5000)),
            tfidf_ngram_max=int(d.get("tfidf_ngram_max", 2)),
            tfidf_min_df=int(d.get("tfidf_min_df", 2)),
        )


@dataclass(frozen=True)
class ModelsConfig:
    """Model hyper-parameters kept as a nested mapping.

    Models are plugin-like: the registry consumes the sub-mapping matching the
    model key. Keeping this section as a dict preserves extensibility (a new
    model requires no change to the configuration schema).
    """

    raw: Dict[str, Dict[str, Any]] = field(default_factory=dict)

    def enabled_models(self) -> List[str]:
        return [
            name
            for name, cfg in self.raw.items()
            if isinstance(cfg, dict) and cfg.get("enabled", False)
        ]

    def params(self, name: str) -> Dict[str, Any]:
        cfg = dict(self.raw.get(name, {}))
        cfg.pop("enabled", None)
        return cfg

    def is_enabled(self, name: str) -> bool:
        cfg = self.raw.get(name)
        return bool(cfg and cfg.get("enabled", False))

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ModelsConfig":
        return cls(raw=copy.deepcopy(d or {}))


@dataclass(frozen=True)
class EvaluationConfig:
    cutoffs: List[int] = field(default_factory=lambda: [5, 10, 20])
    primary_cutoff: int = 10
    primary_metric: str = "ndcg@10"
    exclude_seen: bool = True
    max_eval_users: Optional[int] = 4000

    def __post_init__(self) -> None:
        if not self.cutoffs:
            raise ValueError("evaluation.cutoffs must not be empty.")
        if any(k <= 0 for k in self.cutoffs):
            raise ValueError("evaluation.cutoffs must contain positive integers.")
        if self.primary_cutoff not in self.cutoffs:
            raise ValueError(
                "evaluation.primary_cutoff must be present in evaluation.cutoffs."
            )
        if self.max_eval_users is not None and self.max_eval_users <= 0:
            raise ValueError("evaluation.max_eval_users must be positive or null.")
        if not self.primary_metric.strip():
            raise ValueError("evaluation.primary_metric must not be empty.")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "EvaluationConfig":
        d = d or {}
        max_users = d.get("max_eval_users", 4000)
        return cls(
            cutoffs=[int(k) for k in d.get("cutoffs", [5, 10, 20])],
            primary_cutoff=int(d.get("primary_cutoff", 10)),
            primary_metric=str(d.get("primary_metric", "ndcg@10")),
            exclude_seen=bool(d.get("exclude_seen", True)),
            max_eval_users=None if max_users in (None, "null") else int(max_users),
        )


@dataclass(frozen=True)
class StatisticsConfig:
    enabled: bool = True
    alpha: float = 0.05
    bootstrap_iterations: int = 2000
    correction: str = "holm"
    paired_test: str = "wilcoxon"

    def __post_init__(self) -> None:
        _in_unit_interval(self.alpha, "statistics.alpha")
        if self.correction not in ("holm", "bonferroni", "none"):
            raise ValueError("statistics.correction must be holm|bonferroni|none.")
        if self.paired_test not in ("wilcoxon", "ttest"):
            raise ValueError("statistics.paired_test must be wilcoxon|ttest.")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "StatisticsConfig":
        d = d or {}
        return cls(
            enabled=bool(d.get("enabled", True)),
            alpha=float(d.get("alpha", 0.05)),
            bootstrap_iterations=int(d.get("bootstrap_iterations", 2000)),
            correction=str(d.get("correction", "holm")),
            paired_test=str(d.get("paired_test", "wilcoxon")),
        )


@dataclass(frozen=True)
class BusinessConfig:
    rfm_quantiles: int = 5
    clv_prediction_horizon_days: int = 365
    clv_discount_rate: float = 0.10
    gross_margin: float = 0.35
    simulate_uplift: bool = True
    baseline_ctr: float = 0.02
    ctr_lift_per_ndcg_point: float = 1.8
    attach_rate: float = 0.12
    simulation_impressions: int = 1_000_000

    def __post_init__(self) -> None:
        _in_unit_interval(self.gross_margin, "business.gross_margin")
        _in_unit_interval(self.baseline_ctr, "business.baseline_ctr")
        _in_unit_interval(self.attach_rate, "business.attach_rate")
        _positive(self.rfm_quantiles, "business.rfm_quantiles")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "BusinessConfig":
        d = d or {}
        return cls(
            rfm_quantiles=int(d.get("rfm_quantiles", 5)),
            clv_prediction_horizon_days=int(d.get("clv_prediction_horizon_days", 365)),
            clv_discount_rate=float(d.get("clv_discount_rate", 0.10)),
            gross_margin=float(d.get("gross_margin", 0.35)),
            simulate_uplift=bool(d.get("simulate_uplift", True)),
            baseline_ctr=float(d.get("baseline_ctr", 0.02)),
            ctr_lift_per_ndcg_point=float(d.get("ctr_lift_per_ndcg_point", 1.8)),
            attach_rate=float(d.get("attach_rate", 0.12)),
            simulation_impressions=int(d.get("simulation_impressions", 1_000_000)),
        )


@dataclass(frozen=True)
class ServiceConfig:
    host: str = "127.0.0.1"
    port: int = 8000
    default_top_n: int = 10
    max_top_n: int = 100
    model_for_serving: str = "hybrid"

    def __post_init__(self) -> None:
        if self.default_top_n > self.max_top_n:
            raise ValueError("service.default_top_n must be <= service.max_top_n.")

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "ServiceConfig":
        d = d or {}
        return cls(
            host=str(d.get("host", "127.0.0.1")),
            port=int(d.get("port", 8000)),
            default_top_n=int(d.get("default_top_n", 10)),
            max_top_n=int(d.get("max_top_n", 100)),
            model_for_serving=str(d.get("model_for_serving", "hybrid")),
        )


# ---------------------------------------------------------------------------
# root
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class Config:
    experiment: ExperimentConfig
    data: DataConfig
    preprocessing: PreprocessingConfig
    splitting: SplittingConfig
    features: FeatureConfig
    models: ModelsConfig
    evaluation: EvaluationConfig
    statistics: StatisticsConfig
    business: BusinessConfig
    service: ServiceConfig
    source_path: Optional[str] = None

    # -- construction -------------------------------------------------------
    @classmethod
    def from_dict(cls, d: Dict[str, Any], source_path: Optional[str] = None) -> "Config":
        return cls(
            experiment=ExperimentConfig.from_dict(d.get("experiment", {})),
            data=DataConfig.from_dict(d.get("data", {})),
            preprocessing=PreprocessingConfig.from_dict(d.get("preprocessing", {})),
            splitting=SplittingConfig.from_dict(d.get("splitting", {})),
            features=FeatureConfig.from_dict(d.get("features", {})),
            models=ModelsConfig.from_dict(d.get("models", {})),
            evaluation=EvaluationConfig.from_dict(d.get("evaluation", {})),
            statistics=StatisticsConfig.from_dict(d.get("statistics", {})),
            business=BusinessConfig.from_dict(d.get("business", {})),
            service=ServiceConfig.from_dict(d.get("service", {})),
            source_path=source_path,
        )

    # -- serialisation ------------------------------------------------------
    def to_dict(self) -> Dict[str, Any]:
        out = asdict(self)
        # ModelsConfig stores its payload under 'raw'; flatten for readability.
        out["models"] = copy.deepcopy(self.models.raw)
        return out

    def snapshot(self, path: Path) -> Path:
        """Persist the effective configuration next to the run artifacts."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("w", encoding="utf-8") as fh:
            yaml.safe_dump(self.to_dict(), fh, allow_unicode=True, sort_keys=False)
        return path


def load_config(path: str | Path) -> Config:
    """Load and validate a YAML configuration document."""
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(f"Configuration file not found: {path}")
    with path.open("r", encoding="utf-8") as fh:
        payload = yaml.safe_load(fh) or {}
    if not isinstance(payload, dict):
        raise TypeError("Top-level configuration document must be a mapping.")
    return Config.from_dict(payload, source_path=str(path))
