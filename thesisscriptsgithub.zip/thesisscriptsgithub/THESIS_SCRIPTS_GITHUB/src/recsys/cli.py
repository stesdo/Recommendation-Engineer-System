"""Command-line interface.

Five verbs cover the entire lifecycle of the artefact:

``download``
    Fetch the Online Retail II archive into ``data/raw``.
``run``
    Execute the full experimental pipeline (Chapters 5–7).
``evaluate``
    Re-run only the evaluation stage on a subset of models.
``recommend``
    Produce recommendations for a single customer, with explanations.
``serve``
    Start the FastAPI application.

Every verb accepts ``--config`` so that alternative experimental designs can be
run without touching code, and ``--log-level`` for diagnostic verbosity.
"""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path
from typing import List, Optional

from recsys.config import Config, load_config
from recsys.logging_utils import configure_logging, get_logger

logger = get_logger("recsys.cli")

DEFAULT_CONFIG = "config/config.yaml"


# ---------------------------------------------------------------------------
def _project_root() -> Path:
    """Locate the project root (the directory containing ``config/``).

    Walking upwards makes the CLI insensitive to the working directory from
    which it is invoked, which matters because reviewers habitually run
    ``python src/recsys/cli.py`` from arbitrary locations.
    """
    here = Path(__file__).resolve()
    for parent in [Path.cwd(), *here.parents]:
        if (parent / "config" / "config.yaml").is_file():
            return parent
    return Path.cwd()


def _resolve_config(path: Optional[str]) -> Path:
    root = _project_root()
    candidate = Path(path) if path else (root / DEFAULT_CONFIG)
    if not candidate.is_absolute():
        candidate = root / candidate
    return candidate


def _load(args: argparse.Namespace) -> tuple[Config, Path]:
    root = _project_root()
    config_path = _resolve_config(getattr(args, "config", None))
    cfg = load_config(config_path)
    logger.info("Configuration loaded from %s", config_path)
    return cfg, root


# ---------------------------------------------------------------------------
# commands
# ---------------------------------------------------------------------------
def cmd_download(args: argparse.Namespace) -> int:
    from recsys.data.loader import DataLoader

    cfg, root = _load(args)
    loader = DataLoader(cfg.data, project_root=root)
    try:
        path = loader.download(force=args.force)
        logger.info("Archive available at %s", path)
    except Exception as exc:
        logger.error("Download failed: %s", exc)
        if cfg.data.allow_synthetic_fallback:
            logger.info(
                "The pipeline will fall back to the synthetic surrogate corpus, "
                "so `run` remains executable."
            )
            return 0
        return 1

    # Materialise the parsed cache so the first `run` is fast.
    raw = loader.load(force_refresh=True)
    logger.info("Parsed and cached — %s", raw.describe())
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    from recsys.pipeline import Pipeline

    cfg, root = _load(args)
    pipeline = Pipeline(cfg, project_root=root)
    try:
        artifacts = pipeline.run()
    except Exception as exc:
        logger.error("Pipeline failed: %s", exc, exc_info=True)
        return 1

    print()
    print("=" * 78)
    print(f"Artefacts: {artifacts.output_dir}")
    if artifacts.results_frame is not None:
        metric = cfg.evaluation.primary_metric
        if metric in artifacts.results_frame.columns:
            print()
            print(f"Ranking by {metric}:")
            ranking = artifacts.results_frame[metric].sort_values(ascending=False)
            for rank, (name, score) in enumerate(ranking.items(), start=1):
                print(f"  {rank}. {name:<22} {score:.4f}")
    print("=" * 78)
    return 0


def cmd_evaluate(args: argparse.Namespace) -> int:
    """Re-run the pipeline restricted to the requested models."""
    from recsys.pipeline import Pipeline

    cfg, root = _load(args)
    if args.models:
        requested = set(args.models)
        raw = dict(cfg.models.raw)
        for name in raw:
            if isinstance(raw[name], dict):
                raw[name] = {**raw[name], "enabled": name in requested}
        cfg = Config.from_dict({**cfg.to_dict(), "models": raw}, cfg.source_path)
        logger.info("Restricted evaluation to: %s", sorted(requested))

    pipeline = Pipeline(cfg, project_root=root)
    try:
        pipeline.run()
    except Exception as exc:
        logger.error("Evaluation failed: %s", exc, exc_info=True)
        return 1
    return 0


def cmd_recommend(args: argparse.Namespace) -> int:
    """Produce an explained top-N list for one customer."""
    from recsys.pipeline import Pipeline

    cfg, root = _load(args)
    pipeline = Pipeline(cfg, project_root=root)
    try:
        artifacts = pipeline.run()
    except Exception as exc:
        logger.error("Pipeline failed: %s", exc, exc_info=True)
        return 1

    split = artifacts.split
    if split is None:
        logger.error("No split available.")
        return 1

    customer_id = args.customer
    if customer_id is None:
        # Pick the most active customer as a demonstration subject.
        user_idx = int(artifacts.interactions.user_activity.argmax())
        customer_id = int(split.user_ids[user_idx])
        logger.info("No --customer supplied; using the most active (%d).", customer_id)
    elif customer_id not in split.user_map:
        logger.error(
            "Customer %s is not in the training vocabulary (%d known customers).",
            customer_id,
            len(split.user_map),
        )
        return 1
    else:
        user_idx = split.user_map[customer_id]

    model_name = args.model or cfg.service.model_for_serving
    model = artifacts.models.get(model_name)
    if model is None:
        model_name = artifacts.best_model_name(cfg.evaluation.primary_metric)
        model = artifacts.models.get(model_name)
    if model is None:
        logger.error("No fitted model available for serving.")
        return 1

    recommendations = model.recommend(user_idx, n=args.top_n, exclude_seen=True)
    descriptions = artifacts.content.descriptions if artifacts.content else None
    prices = artifacts.interactions.item_mean_price

    print()
    print("=" * 78)
    print(f"Recommendations for customer {customer_id}  (model: {model_name})")
    print("=" * 78)
    for rank, item_idx in enumerate(recommendations, start=1):
        item_id = split.item_ids[item_idx]
        desc = descriptions[item_idx] if descriptions is not None else ""
        price = prices[item_idx]
        print(f"{rank:2d}. [{item_id}] {desc[:46]:<46} £{price:>7.2f}")
        if args.explain:
            print(f"     ↳ {model.explain(user_idx, int(item_idx))}")
    print("=" * 78)
    return 0


def cmd_serve(args: argparse.Namespace) -> int:
    cfg, root = _load(args)
    try:
        import uvicorn

        from recsys.service.api import create_app
    except ImportError as exc:
        logger.error(
            "The service layer requires FastAPI and uvicorn: "
            "pip install fastapi 'uvicorn[standard]' (%s).",
            exc,
        )
        return 1

    app = create_app(cfg, project_root=root)
    host = args.host or cfg.service.host
    port = args.port or cfg.service.port
    logger.info("Starting the recommendation service on http://%s:%d", host, port)
    logger.info("Interactive documentation: http://%s:%d/docs", host, port)
    uvicorn.run(app, host=host, port=port, log_level="info")
    return 0


# ---------------------------------------------------------------------------
def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="recsys",
        description=(
            "Hyper-personalization recommendation engine — diploma thesis 281549."
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python -m recsys.cli download\n"
            "  python -m recsys.cli run\n"
            "  python -m recsys.cli evaluate --models ease als popularity\n"
            "  python -m recsys.cli recommend --customer 12347 --top-n 10 --explain\n"
            "  python -m recsys.cli serve --port 8000\n"
        ),
    )
    parser.add_argument("--config", help=f"Path to the YAML configuration "
                                         f"(default: {DEFAULT_CONFIG}).")
    parser.add_argument(
        "--log-level",
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
        help="Console verbosity (default: INFO).",
    )
    parser.add_argument("--log-file", help="Optional path for a DEBUG-level log file.")

    sub = parser.add_subparsers(dest="command", required=True)

    p_download = sub.add_parser("download", help="Fetch the Online Retail II archive.")
    p_download.add_argument("--force", action="store_true", help="Re-download.")
    p_download.set_defaults(func=cmd_download)

    p_run = sub.add_parser("run", help="Execute the full experimental pipeline.")
    p_run.set_defaults(func=cmd_run)

    p_eval = sub.add_parser("evaluate", help="Evaluate a subset of models.")
    p_eval.add_argument("--models", nargs="+", help="Model keys to enable.")
    p_eval.set_defaults(func=cmd_evaluate)

    p_rec = sub.add_parser("recommend", help="Recommend for a single customer.")
    p_rec.add_argument("--customer", type=int, help="Customer identifier.")
    p_rec.add_argument("--model", help="Model to use (default: service config).")
    p_rec.add_argument("--top-n", type=int, default=10, help="List length.")
    p_rec.add_argument("--explain", action="store_true", help="Show justifications.")
    p_rec.set_defaults(func=cmd_recommend)

    p_serve = sub.add_parser("serve", help="Start the HTTP service.")
    p_serve.add_argument("--host", help="Bind address.")
    p_serve.add_argument("--port", type=int, help="Bind port.")
    p_serve.set_defaults(func=cmd_serve)

    return parser


def main(argv: Optional[List[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)

    configure_logging(
        level=getattr(logging, args.log_level),
        log_file=Path(args.log_file) if args.log_file else None,
        force=True,
    )
    try:
        return int(args.func(args))
    except KeyboardInterrupt:  # pragma: no cover
        logger.warning("Interrupted by user.")
        return 130


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
