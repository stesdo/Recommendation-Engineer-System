"""Structured logging and lightweight instrumentation.

Experimental software has a specific logging requirement that ordinary
application logging does not: every timing figure and every intermediate
statistic reported in the written thesis must be traceable to a concrete log
line. This module therefore provides:

* ``configure_logging`` — one-shot configuration with console + file sinks.
* ``timed`` — a context manager recording wall-clock duration of a stage.
* ``ProgressReporter`` — throttled progress logging for long loops, which keeps
  the log readable without suppressing evidence of progress.
"""

from __future__ import annotations

import logging
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import Dict, Iterator, Optional

__all__ = ["configure_logging", "get_logger", "timed", "ProgressReporter", "TIMINGS"]

_LOG_FORMAT = "%(asctime)s | %(levelname)-7s | %(name)-28s | %(message)s"
_DATE_FORMAT = "%H:%M:%S"

#: Global registry of stage durations (seconds), consumed by the pipeline when
#: writing the runtime table reported in the thesis.
TIMINGS: Dict[str, float] = {}

_CONFIGURED = False


def configure_logging(
    level: int | str = logging.INFO,
    log_file: Optional[Path] = None,
    force: bool = False,
) -> None:
    """Configure the root logger exactly once.

    Parameters
    ----------
    level:
        Threshold for the console sink.
    log_file:
        Optional path; when given, a DEBUG-level file sink is attached so the
        full trace survives even when the console is set to INFO.
    force:
        Re-configure even if already configured (used by tests).
    """
    global _CONFIGURED
    if _CONFIGURED and not force:
        return

    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    for handler in list(root.handlers):
        root.removeHandler(handler)

    console = logging.StreamHandler(stream=sys.stdout)
    console.setLevel(level)
    console.setFormatter(logging.Formatter(_LOG_FORMAT, datefmt=_DATE_FORMAT))
    root.addHandler(console)

    if log_file is not None:
        log_file = Path(log_file)
        log_file.parent.mkdir(parents=True, exist_ok=True)
        file_handler = logging.FileHandler(log_file, encoding="utf-8")
        file_handler.setLevel(logging.DEBUG)
        file_handler.setFormatter(
            logging.Formatter(
                "%(asctime)s | %(levelname)-7s | %(name)-28s | %(message)s"
            )
        )
        root.addHandler(file_handler)

    # Third-party noise suppression.
    for noisy in ("matplotlib", "urllib3", "PIL", "fontTools"):
        logging.getLogger(noisy).setLevel(logging.WARNING)

    _CONFIGURED = True


def get_logger(name: str) -> logging.Logger:
    """Return a module-scoped logger."""
    return logging.getLogger(name)


@contextmanager
def timed(stage: str, logger: Optional[logging.Logger] = None) -> Iterator[None]:
    """Measure and log the wall-clock duration of a pipeline stage.

    The duration is also recorded in :data:`TIMINGS` so the pipeline can emit a
    consolidated runtime table.
    """
    log = logger or logging.getLogger("recsys.timing")
    log.info("▶ %s — started", stage)
    start = time.perf_counter()
    try:
        yield
    finally:
        elapsed = time.perf_counter() - start
        TIMINGS[stage] = TIMINGS.get(stage, 0.0) + elapsed
        log.info("■ %s — finished in %.2f s", stage, elapsed)


class ProgressReporter:
    """Throttled progress logger for long-running loops.

    Emits at most one line every ``every_seconds`` seconds, so a 4 000-user
    evaluation loop produces a handful of informative lines rather than
    thousands.
    """

    def __init__(
        self,
        total: int,
        label: str,
        logger: Optional[logging.Logger] = None,
        every_seconds: float = 5.0,
    ) -> None:
        self.total = max(int(total), 1)
        self.label = label
        self.logger = logger or logging.getLogger("recsys.progress")
        self.every_seconds = float(every_seconds)
        self._start = time.perf_counter()
        self._last_emit = self._start
        self._count = 0

    def update(self, n: int = 1) -> None:
        self._count += n
        now = time.perf_counter()
        if now - self._last_emit < self.every_seconds:
            return
        self._last_emit = now
        pct = 100.0 * self._count / self.total
        elapsed = now - self._start
        rate = self._count / elapsed if elapsed > 0 else 0.0
        eta = (self.total - self._count) / rate if rate > 0 else float("nan")
        self.logger.info(
            "  %s: %d/%d (%.1f%%) — %.0f it/s — ETA %.0f s",
            self.label,
            self._count,
            self.total,
            pct,
            rate,
            eta,
        )

    def close(self) -> None:
        elapsed = time.perf_counter() - self._start
        self.logger.info(
            "  %s: completed %d items in %.2f s", self.label, self._count, elapsed
        )
