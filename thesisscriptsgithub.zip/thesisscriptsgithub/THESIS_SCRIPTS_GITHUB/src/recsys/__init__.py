"""Hyper-personalization recommendation engine.

A research-grade, self-contained implementation of a hybrid recommender system
for e-retail transactional data, developed as the software artefact of the
diploma thesis *"Design and Implementation of a Digital Decision-Making System
for Personalized Product Exposure in E-Retail Environments"* (reg. no. 281549).

The package is organised into six horizontal layers:

``recsys.data``
    Acquisition, cleaning and temporally-consistent splitting.
``recsys.features``
    Sparse interaction matrices, RFM behavioural features, textual content.
``recsys.models``
    Seven recommender families plus a hybrid meta-recommender.
``recsys.evaluation``
    Accuracy, beyond-accuracy and statistical-significance machinery.
``recsys.business``
    CLV modelling, cross/up-sell logic and revenue simulation.
``recsys.service``
    A FastAPI application exposing the trained engine over HTTP.
"""

from __future__ import annotations

__version__ = "1.0.0"
__author__ = "Student 281549"

from recsys.config import Config, load_config  # noqa: E402
from recsys.logging_utils import configure_logging, get_logger  # noqa: E402

__all__ = [
    "__version__",
    "Config",
    "load_config",
    "configure_logging",
    "get_logger",
]
