"""Market-basket association rules for cross-selling.

Association-rule mining (Agrawal, Imieliński & Swami, 1993) is the algorithmic
formalisation of the cross-selling intuition "customers who bought X also bought
Y". Unlike the latent-factor models, its output is a *symbolic* artefact — a
list of implications with interpretable support, confidence and lift — which
managers can inspect, override and merchandise around. This makes it the natural
engine for the cross-sell module of Chapter 7.

Definitions
-----------
For an antecedent :math:`X` and consequent :math:`Y` over baskets
:math:`\\mathcal{T}`:

.. math::

    \\mathrm{supp}(X) &= \\frac{|\\{t : X \\subseteq t\\}|}{|\\mathcal{T}|} \\\\
    \\mathrm{conf}(X \\Rightarrow Y) &= \\frac{\\mathrm{supp}(X \\cup Y)}{\\mathrm{supp}(X)} \\\\
    \\mathrm{lift}(X \\Rightarrow Y) &= \\frac{\\mathrm{conf}(X \\Rightarrow Y)}{\\mathrm{supp}(Y)}

Confidence alone is a misleading ranking criterion because it is inflated by
popular consequents: a rule predicting a universally purchased article attains
high confidence while carrying no information. *Lift* corrects this by
normalising against the marginal probability of the consequent; a lift above one
indicates genuine positive association. Ranking is therefore by lift, with
confidence used only as an admissibility filter.

Scope
-----
Only *pairwise* rules (|X| = |Y| = 1) are mined. This is a deliberate
restriction: the number of candidate itemsets grows exponentially with the
antecedent size, while empirically the marginal predictive gain of triples over
pairs in retail baskets is small. Pairwise mining reduces to one sparse
matrix product, which is both exact and fast.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, List, Optional

import numpy as np
import pandas as pd
import scipy.sparse as sp

from recsys.features.interactions import InteractionData
from recsys.logging_utils import get_logger, timed
from recsys.models.base import FitContext, Recommender

logger = get_logger(__name__)

__all__ = ["AssociationRule", "AssociationRulesRecommender"]


@dataclass
class AssociationRule:
    """A single pairwise implication with its interestingness measures."""

    antecedent: int
    consequent: int
    support: float
    confidence: float
    lift: float
    conviction: float
    count: int

    def __str__(self) -> str:  # pragma: no cover - cosmetic
        return (
            f"#{self.antecedent} ⇒ #{self.consequent} "
            f"(supp={self.support:.4f}, conf={self.confidence:.3f}, "
            f"lift={self.lift:.2f}, n={self.count})"
        )


class AssociationRulesRecommender(Recommender):
    """Score items by aggregated lift over the user's purchased articles."""

    name = "association_rules"

    def __init__(
        self,
        min_support: float = 0.001,
        min_confidence: float = 0.05,
        min_lift: float = 1.0,
        max_basket_size: int = 60,
        max_rules: int = 200_000,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            min_support=min_support,
            min_confidence=min_confidence,
            min_lift=min_lift,
            max_basket_size=max_basket_size,
            max_rules=max_rules,
            **kwargs,
        )
        self.min_support = float(min_support)
        self.min_confidence = float(min_confidence)
        self.min_lift = float(min_lift)
        self.max_basket_size = int(max_basket_size)
        self.max_rules = int(max_rules)
        self.rule_matrix_: Optional[sp.csr_matrix] = None   # antecedent × consequent (lift)
        self.rules_: List[AssociationRule] = []
        self._user_binary: Optional[sp.csr_matrix] = None

    # ------------------------------------------------------------------- fit
    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        frame = context.train_frame
        if frame is None or frame.empty:
            raise ValueError(
                "AssociationRulesRecommender requires the training transaction "
                "frame (FitContext.train_frame) to reconstruct baskets."
            )
        self._user_binary = sp.csr_matrix(interactions.binary, dtype=np.float32)
        n_items = interactions.n_items

        with timed("models.association_rules.mine", logger):
            baskets = self._basket_matrix(frame, n_items)
            self._mine(baskets, n_items)

    def _basket_matrix(self, frame: pd.DataFrame, n_items: int) -> sp.csr_matrix:
        """Build the binary basket × item incidence matrix."""
        basket_ids, basket_codes = np.unique(
            frame["invoice"].to_numpy(), return_inverse=True
        )
        items = frame["item_idx"].to_numpy(dtype=np.int64)

        matrix = sp.csr_matrix(
            (np.ones(items.size, dtype=np.float32), (basket_codes, items)),
            shape=(basket_ids.size, n_items),
        )
        matrix.data[:] = 1.0                       # collapse duplicate lines
        matrix.sum_duplicates()
        matrix.data[:] = 1.0

        # Very large baskets are usually wholesale replenishment orders whose
        # co-occurrences are organisational rather than preferential; they also
        # dominate the O(Σ |t|²) cost of pair counting.
        sizes = np.diff(matrix.indptr)
        keep = sizes <= self.max_basket_size
        removed = int((~keep).sum())
        if removed:
            logger.info(
                "  excluded %d baskets larger than %d items (%.2f%%).",
                removed,
                self.max_basket_size,
                100.0 * removed / max(sizes.size, 1),
            )
            matrix = matrix[keep]
        logger.info(
            "  basket matrix: %d baskets × %d items (mean size %.1f).",
            matrix.shape[0],
            matrix.shape[1],
            matrix.nnz / max(matrix.shape[0], 1),
        )
        return matrix

    def _mine(self, baskets: sp.csr_matrix, n_items: int) -> None:
        """Count co-occurrences and derive the interestingness measures."""
        n_baskets = baskets.shape[0]
        if n_baskets == 0:  # pragma: no cover - degenerate
            self.rule_matrix_ = sp.csr_matrix((n_items, n_items), dtype=np.float32)
            return

        item_counts = np.asarray(baskets.sum(axis=0)).ravel()
        item_support = item_counts / n_baskets

        # Pair co-occurrence counts: one sparse product.
        cooc = (baskets.T @ baskets).tocoo()

        min_count = max(self.min_support * n_baskets, 1.0)
        mask = (cooc.row != cooc.col) & (cooc.data >= min_count)
        rows, cols, counts = cooc.row[mask], cooc.col[mask], cooc.data[mask]
        logger.info(
            "  candidate pairs above min_support=%.4f (≥%.0f baskets): %d.",
            self.min_support,
            min_count,
            rows.size,
        )

        with np.errstate(divide="ignore", invalid="ignore"):
            support = counts / n_baskets
            confidence = np.where(
                item_counts[rows] > 0, counts / item_counts[rows], 0.0
            )
            lift = np.where(
                item_support[cols] > 0, confidence / item_support[cols], 0.0
            )
            # Conviction: P(X)P(¬Y) / P(X ∧ ¬Y); ∞ for a perfect rule.
            conviction = np.where(
                confidence < 1.0,
                (1.0 - item_support[cols]) / np.maximum(1.0 - confidence, 1e-12),
                np.inf,
            )

        keep = (confidence >= self.min_confidence) & (lift >= self.min_lift)
        rows, cols = rows[keep], cols[keep]
        support, confidence = support[keep], confidence[keep]
        lift, conviction, counts = lift[keep], conviction[keep], counts[keep]

        # Cap the rule base by lift so memory stays bounded on dense catalogues.
        if rows.size > self.max_rules:
            order = np.argpartition(-lift, self.max_rules - 1)[: self.max_rules]
            rows, cols = rows[order], cols[order]
            support, confidence = support[order], confidence[order]
            lift, conviction, counts = lift[order], conviction[order], counts[order]
            logger.info("  rule base truncated to the %d highest-lift rules.", self.max_rules)

        self.rule_matrix_ = sp.csr_matrix(
            (lift.astype(np.float32), (rows, cols)), shape=(n_items, n_items)
        )
        self.rules_ = [
            AssociationRule(
                antecedent=int(a),
                consequent=int(c),
                support=float(s),
                confidence=float(cf),
                lift=float(lf),
                conviction=float(cv),
                count=int(n),
            )
            for a, c, s, cf, lf, cv, n in zip(
                rows, cols, support, confidence, lift, conviction, counts
            )
        ]
        self.rules_.sort(key=lambda r: -r.lift)

        if self.rules_:
            logger.info(
                "  mined %d rules — lift range [%.2f, %.2f], median confidence %.3f.",
                len(self.rules_),
                float(lift.min()),
                float(lift.max()),
                float(np.median(confidence)),
            )
        else:
            logger.warning(
                "  no rules survived the thresholds "
                "(min_support=%.4f, min_confidence=%.3f, min_lift=%.2f).",
                self.min_support,
                self.min_confidence,
                self.min_lift,
            )

    # ----------------------------------------------------------------- score
    def _score(self, user_idx: int) -> np.ndarray:
        assert self.rule_matrix_ is not None and self._user_binary is not None
        user_row = self._user_binary[user_idx]
        if user_row.nnz == 0 or self.rule_matrix_.nnz == 0:
            return np.zeros(self.n_items, dtype=np.float64)
        scores = np.asarray((user_row @ self.rule_matrix_).todense()).ravel()
        peak = scores.max()
        return scores / peak if peak > 0 else scores

    def score_batch(self, user_indices) -> np.ndarray:
        self._check_fitted()
        assert self.rule_matrix_ is not None and self._user_binary is not None
        block = self._user_binary[np.asarray(user_indices, dtype=np.int64)]
        scores = np.asarray((block @ self.rule_matrix_).todense(), dtype=np.float64)
        peaks = scores.max(axis=1, keepdims=True)
        peaks[peaks == 0] = 1.0
        return scores / peaks

    # ------------------------------------------------------------- reporting
    def rules_frame(self, top_n: int = 100) -> pd.DataFrame:
        """The strongest rules as a tabular artefact for the thesis appendix."""
        return pd.DataFrame(
            [
                {
                    "antecedent": r.antecedent,
                    "consequent": r.consequent,
                    "support": r.support,
                    "confidence": r.confidence,
                    "lift": r.lift,
                    "conviction": r.conviction,
                    "count": r.count,
                }
                for r in self.rules_[:top_n]
            ]
        )

    def explain(self, user_idx: int, item_idx: int) -> str:
        assert self.rule_matrix_ is not None and self._user_binary is not None
        user_row = self._user_binary[user_idx]
        if user_row.nnz == 0:
            return "No purchase history available."
        column = self.rule_matrix_[:, item_idx]
        best_item, best_lift = None, 0.0
        for purchased in user_row.indices:
            lift = float(column[purchased, 0])
            if lift > best_lift:
                best_item, best_lift = int(purchased), lift
        if best_item is None:
            return f"Recommended by {self.name}."
        return (
            f"Customers who bought item #{best_item} are {best_lift:.1f}× more "
            f"likely to buy this article."
        )
