"""Content-based recommendation over TF–IDF product descriptions.

Content-based filtering (Pazzani & Billsus, 2007; Lops et al., 2011) builds a
*user profile* in the same feature space as the items, then ranks items by
similarity to that profile. Its distinctive value is structural rather than
statistical: it is the only family in this thesis that can recommend an article
which has never been purchased by anyone, and the only one whose predictions
remain defined when the collaborative signal is absent. It is therefore the
designated cold-start component of the hybrid.

Profile construction supports two aggregations:

``mean``
    the centroid of the user's purchased item vectors;
``weighted_mean``
    the confidence-weighted centroid, so that repeatedly purchased and recently
    purchased articles dominate the profile.

Both are L2-normalised, which makes the subsequent dot product with the
(already normalised) item matrix a cosine similarity in [0, 1].
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np
import scipy.sparse as sp

from recsys.features.interactions import InteractionData
from recsys.logging_utils import get_logger
from recsys.models.base import FitContext, Recommender

logger = get_logger(__name__)

__all__ = ["ContentBasedRecommender"]


class ContentBasedRecommender(Recommender):
    """Rank items by cosine similarity to a TF–IDF user profile."""

    name = "content_based"
    supports_cold_start = True

    def __init__(
        self,
        profile_aggregation: str = "weighted_mean",
        **kwargs: Any,
    ) -> None:
        super().__init__(profile_aggregation=profile_aggregation, **kwargs)
        if profile_aggregation not in ("mean", "weighted_mean"):
            raise ValueError(
                "profile_aggregation must be 'mean' or 'weighted_mean'; "
                f"got {profile_aggregation!r}."
            )
        self.aggregation = profile_aggregation
        self.item_features_: Optional[sp.csr_matrix] = None
        self.user_profiles_: Optional[sp.csr_matrix] = None
        self._content = None

    # ------------------------------------------------------------------- fit
    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        content = context.content_features
        if content is None:
            raise ValueError(
                "ContentBasedRecommender requires content features; ensure the "
                "pipeline passes FitContext(content_features=...)."
            )
        self._content = content
        self.item_features_ = sp.csr_matrix(content.matrix, dtype=np.float32)

        # Profile = (weighted) mean of purchased item vectors, per user.
        weights = (
            sp.csr_matrix(interactions.matrix, dtype=np.float32)
            if self.aggregation == "weighted_mean"
            else sp.csr_matrix(interactions.binary, dtype=np.float32)
        )

        profiles = weights @ self.item_features_       # users × terms
        profiles = self._l2_normalise(sp.csr_matrix(profiles))
        self.user_profiles_ = profiles

        n_empty = int((np.diff(profiles.indptr) == 0).sum())
        logger.info(
            "  content profiles: %d users × %d terms (nnz=%d, %d empty profiles).",
            profiles.shape[0],
            profiles.shape[1],
            profiles.nnz,
            n_empty,
        )

    @staticmethod
    def _l2_normalise(matrix: sp.csr_matrix) -> sp.csr_matrix:
        norms = np.sqrt(np.asarray(matrix.multiply(matrix).sum(axis=1))).ravel()
        norms[norms == 0] = 1.0
        return sp.csr_matrix(sp.diags(1.0 / norms) @ matrix)

    # ----------------------------------------------------------------- score
    def _score(self, user_idx: int) -> np.ndarray:
        assert self.user_profiles_ is not None and self.item_features_ is not None
        profile = self.user_profiles_[user_idx]
        if profile.nnz == 0:
            return np.zeros(self.n_items, dtype=np.float64)
        return np.asarray(
            (profile @ self.item_features_.T).todense(), dtype=np.float64
        ).ravel()

    def score_batch(self, user_indices) -> np.ndarray:
        self._check_fitted()
        assert self.user_profiles_ is not None and self.item_features_ is not None
        block = self.user_profiles_[np.asarray(user_indices, dtype=np.int64)]
        return np.asarray(
            (block @ self.item_features_.T).todense(), dtype=np.float64
        )

    # ----------------------------------------------------------- explanation
    def explain(self, user_idx: int, item_idx: int) -> str:
        """Name the terms shared between the user's profile and the item."""
        assert self.user_profiles_ is not None and self.item_features_ is not None
        if self._content is None:
            return f"Recommended by {self.name}."

        profile = self.user_profiles_[user_idx]
        item = self.item_features_[item_idx]
        if profile.nnz == 0 or item.nnz == 0:
            return "Insufficient descriptive information."

        shared = np.intersect1d(profile.indices, item.indices)
        if shared.size == 0:
            return f"Recommended by {self.name}."

        profile_map = dict(zip(profile.indices, profile.data))
        item_map = dict(zip(item.indices, item.data))
        contributions = sorted(
            ((t, profile_map[t] * item_map[t]) for t in shared),
            key=lambda kv: -kv[1],
        )[:3]
        terms = ", ".join(
            f"'{self._content.vocabulary[t]}'" for t, _ in contributions
        )
        return f"Matches your interest in {terms}."
