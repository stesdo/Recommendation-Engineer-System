"""EASE^R — Embarrassingly Shallow Autoencoder for sparse data.

Steck (2019) observed that a *linear* item-item autoencoder with a zero-diagonal
constraint admits a closed-form solution, and that this solution outperforms
most deep architectures on sparse implicit-feedback data. The model is the
strongest single algorithm in this thesis and its inclusion is essential: the
reproducibility crisis documented by Ferrari Dacrema, Cremonesi and Jannach
(2019) showed that many neural recommenders fail to beat exactly this kind of
well-tuned linear baseline.

Formulation
-----------
Minimise the regularised reconstruction error of the interaction matrix
:math:`X \\in \\mathbb{R}^{m \\times n}` over weight matrices :math:`B` whose
diagonal vanishes:

.. math::

    \\min_B \\; \\|X - XB\\|_F^2 + \\lambda\\|B\\|_F^2
    \\quad\\text{s.t.}\\quad \\mathrm{diag}(B) = 0 .

The diagonal constraint is what makes the problem non-trivial: without it the
identity matrix is a perfect and useless solution. Introducing Lagrange
multipliers :math:`\\gamma` for the constraint and setting the gradient to zero
gives :math:`\\hat B = (G + \\lambda I)^{-1}(G - \\mathrm{diagMat}(\\gamma))`
with :math:`G = X^\\top X`. Writing :math:`P = (G + \\lambda I)^{-1}` and solving
for :math:`\\gamma` yields the remarkably compact result

.. math::

    \\hat B_{ij} = \\begin{cases}
        0 & i = j\\\\
        -\\dfrac{P_{ij}}{P_{jj}} & i \\neq j .
    \\end{cases}

Complexity
----------
One dense inversion of an :math:`n \\times n` matrix: :math:`O(n^3)` time,
:math:`O(n^2)` memory. For the ~3–4 × 10³ items retained after k-core filtering
this is a few seconds and a few hundred megabytes — entirely tractable. The
implementation guards against catalogues large enough to exhaust memory and
prefers a Cholesky solve over an explicit inverse for numerical stability.
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np
import scipy.linalg as sla
import scipy.sparse as sp

from recsys.features.interactions import InteractionData
from recsys.logging_utils import get_logger
from recsys.models.base import FitContext, Recommender

logger = get_logger(__name__)

__all__ = ["EASERecommender"]

#: Above this catalogue size the dense n×n Gram matrix becomes impractical
#: (16 000² float64 ≈ 2 GB); the model refuses to fit rather than thrash.
MAX_ITEMS_DENSE = 16_000


class EASERecommender(Recommender):
    """Closed-form linear item-item autoencoder."""

    name = "ease"

    def __init__(self, l2_regularization: float = 250.0, **kwargs: Any) -> None:
        super().__init__(l2_regularization=l2_regularization, **kwargs)
        if l2_regularization <= 0:
            raise ValueError("EASE requires a strictly positive λ for invertibility.")
        self.l2 = float(l2_regularization)
        self.B_: Optional[np.ndarray] = None
        self._user_matrix: Optional[sp.csr_matrix] = None

    # ------------------------------------------------------------------- fit
    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        n_items = interactions.n_items
        if n_items > MAX_ITEMS_DENSE:
            raise MemoryError(
                f"EASE requires a dense {n_items}×{n_items} matrix "
                f"(~{8 * n_items ** 2 / 1e9:.1f} GB). Increase k-core filtering "
                f"or disable this model."
            )

        X = sp.csr_matrix(interactions.matrix, dtype=np.float64)
        self._user_matrix = X

        # Gram matrix G = XᵀX (item co-occurrence in confidence space).
        G = np.asarray((X.T @ X).todense(), dtype=np.float64)

        # Ridge term on the diagonal. Adding λ also guarantees positive
        # definiteness, which the Cholesky factorisation below requires.
        diag_indices = np.diag_indices(n_items)
        G[diag_indices] += self.l2

        logger.info(
            "  solving the EASE system (n=%d, λ=%.1f) via Cholesky …", n_items, self.l2
        )
        try:
            # P = G⁻¹ obtained by solving G·P = I; cho_factor is ~2× faster and
            # numerically better conditioned than a general inverse.
            c, lower = sla.cho_factor(G, lower=True, check_finite=False)
            P = sla.cho_solve((c, lower), np.eye(n_items), check_finite=False)
        except np.linalg.LinAlgError:  # pragma: no cover - ill-conditioned
            logger.warning("  Cholesky failed; falling back to the pseudo-inverse.")
            P = np.linalg.pinv(G)

        # B = -P / diag(P), with a zero diagonal.
        diag_P = np.diag(P).copy()
        diag_P[np.abs(diag_P) < 1e-12] = 1e-12
        B = P / (-diag_P[np.newaxis, :])
        B[diag_indices] = 0.0

        self.B_ = B
        logger.info(
            "  EASE weights: ‖B‖_F=%.3f, off-diagonal mean=%.6f, "
            "negative share=%.1f%%.",
            float(np.linalg.norm(B)),
            float(B.mean()),
            100.0 * float((B < 0).mean()),
        )

    # ----------------------------------------------------------------- score
    def _score(self, user_idx: int) -> np.ndarray:
        assert self.B_ is not None and self._user_matrix is not None
        user_row = self._user_matrix[user_idx]
        if user_row.nnz == 0:
            return np.zeros(self.n_items, dtype=np.float64)
        return np.asarray(user_row @ self.B_, dtype=np.float64).ravel()

    def score_batch(self, user_indices) -> np.ndarray:
        self._check_fitted()
        assert self.B_ is not None and self._user_matrix is not None
        block = self._user_matrix[np.asarray(user_indices, dtype=np.int64)]
        return np.asarray(block @ self.B_, dtype=np.float64)

    # ----------------------------------------------------------- explanation
    def explain(self, user_idx: int, item_idx: int) -> str:
        assert self.B_ is not None and self._user_matrix is not None
        user_row = self._user_matrix[user_idx]
        if user_row.nnz == 0:
            return "No purchase history available."
        contributions = user_row.data * self.B_[user_row.indices, item_idx]
        if contributions.size == 0:
            return f"Recommended by {self.name}."
        best = int(np.argmax(contributions))
        return (
            f"Strongest linear association with purchased item "
            f"#{int(user_row.indices[best])} (weight {contributions[best]:.4f})."
        )
