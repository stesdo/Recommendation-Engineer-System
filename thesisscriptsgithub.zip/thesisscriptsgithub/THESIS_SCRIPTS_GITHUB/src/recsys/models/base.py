"""Abstract recommender interface and shared ranking machinery.

Every model in :mod:`recsys.models` implements the same two-method contract:

``fit(interactions, **context)``
    Estimate parameters from the training interaction matrix.
``score(user_idx)``
    Return a dense vector of length ``n_items`` giving the affinity of the user
    towards every catalogue item.

Top-N ranking, exclusion of already-purchased items and candidate filtering are
implemented *once*, in :meth:`Recommender.recommend`, rather than being
re-derived by each model. This eliminates a notorious source of inconsistency in
comparative studies, where different algorithms are inadvertently evaluated
under subtly different ranking rules.

Selection of the top N entries uses ``numpy.argpartition`` (expected O(n)) rather
than a full sort (O(n log n)); for a 4 000-item catalogue and 4 000 evaluated
users this reduces ranking cost by roughly an order of magnitude.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence

import numpy as np
import scipy.sparse as sp

from recsys.features.interactions import InteractionData
from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = ["Recommender", "Recommendation", "FitContext", "top_n_from_scores"]


@dataclass
class FitContext:
    """Auxiliary artefacts a model may consult during fitting.

    Passing a single context object (rather than a long parameter list) keeps
    the ``fit`` signature stable as new feature families are added.
    """

    train_frame: Optional[Any] = None          # pd.DataFrame of transactions
    content_features: Optional[Any] = None     # ContentFeatures
    item_ids: Optional[np.ndarray] = None
    user_ids: Optional[np.ndarray] = None
    random_seed: int = 42
    extras: Dict[str, Any] = field(default_factory=dict)


@dataclass
class Recommendation:
    """A single scored item, enriched for presentation."""

    item_idx: int
    score: float
    rank: int
    item_id: Optional[str] = None
    description: Optional[str] = None
    price: Optional[float] = None
    reason: Optional[str] = None


class Recommender(abc.ABC):
    """Base class for all recommendation models."""

    #: Human-readable identifier used in result tables and logs.
    name: str = "base"

    #: Whether the model can score a user with no training interactions.
    supports_cold_start: bool = False

    def __init__(self, **params: Any) -> None:
        self.params: Dict[str, Any] = dict(params)
        self.is_fitted: bool = False
        self.n_users: int = 0
        self.n_items: int = 0
        self._interactions: Optional[InteractionData] = None

    # ------------------------------------------------------------------ core
    @abc.abstractmethod
    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        """Model-specific parameter estimation."""

    @abc.abstractmethod
    def _score(self, user_idx: int) -> np.ndarray:
        """Return the raw affinity vector for one user (length ``n_items``)."""

    def fit(
        self, interactions: InteractionData, context: Optional[FitContext] = None
    ) -> "Recommender":
        """Estimate the model, recording shape metadata."""
        context = context or FitContext()
        self._interactions = interactions
        self.n_users = interactions.n_users
        self.n_items = interactions.n_items
        self._fit(interactions, context)
        self.is_fitted = True
        logger.info("Model '%s' fitted (%s).", self.name, self.describe())
        return self

    def score(self, user_idx: int) -> np.ndarray:
        """Public scoring entry point with validation."""
        self._check_fitted()
        if not 0 <= user_idx < self.n_users:
            raise IndexError(
                f"user_idx {user_idx} outside [0, {self.n_users}) for model '{self.name}'."
            )
        scores = np.asarray(self._score(user_idx), dtype=np.float64).ravel()
        if scores.size != self.n_items:
            raise ValueError(
                f"Model '{self.name}' produced {scores.size} scores; "
                f"expected {self.n_items}."
            )
        return scores

    def score_batch(self, user_indices: Sequence[int]) -> np.ndarray:
        """Score several users at once.

        The default implementation loops; models with a natural matrix form
        (matrix factorisation, EASE) override this for a substantial speed-up.
        """
        self._check_fitted()
        return np.vstack([self.score(int(u)) for u in user_indices])

    # -------------------------------------------------------------- ranking
    def recommend(
        self,
        user_idx: int,
        n: int = 10,
        exclude_seen: bool = True,
        candidates: Optional[np.ndarray] = None,
    ) -> np.ndarray:
        """Return the indices of the top-``n`` items, best first."""
        scores = self.score(user_idx)

        if exclude_seen and self._interactions is not None:
            seen = self._interactions.seen_items(user_idx)
            if seen.size:
                scores = scores.copy()
                scores[seen] = -np.inf

        if candidates is not None:
            mask = np.full(scores.size, -np.inf)
            mask[candidates] = scores[candidates]
            scores = mask

        return top_n_from_scores(scores, n)

    def recommend_batch(
        self,
        user_indices: Sequence[int],
        n: int = 10,
        exclude_seen: bool = True,
    ) -> Dict[int, np.ndarray]:
        return {
            int(u): self.recommend(int(u), n=n, exclude_seen=exclude_seen)
            for u in user_indices
        }

    def explain(self, user_idx: int, item_idx: int) -> str:
        """Human-readable justification; overridden by interpretable models."""
        return f"Recommended by {self.name}."

    # -------------------------------------------------------------- helpers
    def describe(self) -> str:
        if not self.params:
            return "no hyper-parameters"
        return ", ".join(f"{k}={v}" for k, v in sorted(self.params.items()))

    def _check_fitted(self) -> None:
        if not self.is_fitted:
            raise RuntimeError(
                f"Model '{self.name}' must be fitted before it can score users."
            )

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        state = "fitted" if self.is_fitted else "unfitted"
        return f"<{self.__class__.__name__} name={self.name!r} {state}>"


def top_n_from_scores(scores: np.ndarray, n: int) -> np.ndarray:
    """Indices of the ``n`` largest entries, in descending score order.

    ``argpartition`` performs the selection in expected linear time; the
    subsequent sort touches only the ``n`` selected entries. Non-finite scores
    (used to mask ineligible items) are excluded from the result.
    """
    n = int(n)
    if n <= 0 or scores.size == 0:
        return np.array([], dtype=np.int32)

    finite = np.isfinite(scores)
    n_finite = int(finite.sum())
    if n_finite == 0:
        return np.array([], dtype=np.int32)

    k = min(n, n_finite)
    if k >= scores.size:
        order = np.argsort(-scores, kind="stable")
    else:
        part = np.argpartition(-scores, k - 1)[:k]
        order = part[np.argsort(-scores[part], kind="stable")]

    order = order[np.isfinite(scores[order])]
    return order[:k].astype(np.int32)
