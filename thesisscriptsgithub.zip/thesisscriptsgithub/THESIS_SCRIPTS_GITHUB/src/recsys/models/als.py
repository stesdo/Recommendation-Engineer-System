"""Implicit-feedback Alternating Least Squares (iALS).

Hu, Koren and Volinsky (2008) adapted matrix factorisation to implicit feedback
by (i) treating *all* unobserved entries as negative rather than missing, and
(ii) weighting each entry by a confidence :math:`c_{ui} = 1 + \\alpha r_{ui}`.
The objective is

.. math::

    \\min_{U, V} \\sum_{u,i} c_{ui}\\,(p_{ui} - u_u^\\top v_i)^2
                 + \\lambda\\left(\\sum_u \\|u_u\\|^2 + \\sum_i \\|v_i\\|^2\\right),

with :math:`p_{ui} = \\mathbb{1}[r_{ui} > 0]`.

The essential computational insight is that although the sum runs over all
:math:`m \\times n` cells, the per-user normal equations can be reorganised as

.. math::

    (V^\\top V + V^\\top (C_u - I) V + \\lambda I)\\, u_u
      = V^\\top C_u p_u ,

where :math:`V^\\top V` is shared across users and computed once per iteration,
and :math:`C_u - I` is non-zero only on the user's observed items. Cost per
iteration therefore falls from :math:`O(mnf^2)` to
:math:`O((\\mathrm{nnz})f^2 + (m+n)f^3)`.

Solver
------
Each row system is solved **exactly**, by a Cholesky factorisation of the
:math:`f \\times f` normal-equation matrix (``scipy.linalg.solve`` with
``assume_a="pos"``), falling back to a least-squares solve only if that matrix
is numerically indefinite. At :math:`f = 128` the cubic term is negligible
beside the :math:`O(\\mathrm{nnz} \\cdot f^2)` accumulation, so the exact solve
is preferred here for determinism and reproducibility.

Takács, Pilászy and Tikk (2011) show that a handful of *conjugate-gradient*
steps can replace the exact solve and remove the cubic term, which becomes
worthwhile at substantially larger factor counts. That approximation is
deliberately **not** used in this implementation: every figure reported in the
thesis comes from the exact solve above.
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np
import scipy.linalg as sla
import scipy.sparse as sp

from recsys.features.interactions import InteractionData
from recsys.logging_utils import ProgressReporter, get_logger
from recsys.models.base import FitContext, Recommender

logger = get_logger(__name__)

__all__ = ["ALSRecommender"]


class ALSRecommender(Recommender):
    """Weighted matrix factorisation for implicit feedback."""

    name = "als"

    def __init__(
        self,
        factors: int = 128,
        regularization: float = 0.05,
        alpha: float = 40.0,
        iterations: int = 20,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            factors=factors,
            regularization=regularization,
            alpha=alpha,
            iterations=iterations,
            **kwargs,
        )
        self.factors = int(factors)
        self.reg = float(regularization)
        self.alpha = float(alpha)
        self.iterations = int(iterations)
        self.user_factors_: Optional[np.ndarray] = None
        self.item_factors_: Optional[np.ndarray] = None
        self.loss_history_: list[float] = []

    # ------------------------------------------------------------------- fit
    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        rng = np.random.default_rng(context.random_seed)
        m, n, f = interactions.n_users, interactions.n_items, self.factors

        # Confidence matrix: C = 1 + α·r, stored as the sparse part (α·r).
        Cu = sp.csr_matrix(interactions.matrix, dtype=np.float64) * self.alpha
        Ci = sp.csc_matrix(Cu).T.tocsr()

        # Small random initialisation keeps the first solve well-conditioned.
        scale = 1.0 / np.sqrt(f)
        U = rng.normal(0.0, scale, size=(m, f))
        V = rng.normal(0.0, scale, size=(n, f))

        reporter = ProgressReporter(self.iterations, f"ALS ({f} factors)", logger, 5.0)
        for iteration in range(1, self.iterations + 1):
            U = self._solve_side(Cu, V, self.reg)
            V = self._solve_side(Ci, U, self.reg)

            loss = self._objective(Cu, U, V)
            self.loss_history_.append(loss)
            logger.debug("  ALS iteration %2d — objective %.4f", iteration, loss)
            reporter.update(1)

            # Early stop on a plateau: further iterations only cost time.
            if len(self.loss_history_) >= 2:
                prev = self.loss_history_[-2]
                if prev > 0 and abs(prev - loss) / prev < 1e-5:
                    logger.info("  ALS converged at iteration %d.", iteration)
                    break
        reporter.close()

        self.user_factors_ = U
        self.item_factors_ = V
        logger.info(
            "  ALS factors: U%s V%s, final objective %.4f.",
            U.shape,
            V.shape,
            self.loss_history_[-1] if self.loss_history_ else float("nan"),
        )

    def _solve_side(
        self, C: sp.csr_matrix, fixed: np.ndarray, reg: float
    ) -> np.ndarray:
        """Solve the normal equations for one side of the factorisation.

        Each row is solved exactly via Cholesky (``assume_a="pos"``), which is
        valid because ``A`` is symmetric positive definite for ``reg > 0``.
        """
        n_rows = C.shape[0]
        f = fixed.shape[1]
        YtY = fixed.T @ fixed                      # shared across all rows
        base = YtY + reg * np.eye(f)

        out = np.zeros((n_rows, f), dtype=np.float64)
        indptr, indices, data = C.indptr, C.indices, C.data

        for row in range(n_rows):
            start, end = indptr[row], indptr[row + 1]
            if start == end:
                continue                            # no observations → zero vector
            cols = indices[start:end]
            conf = data[start:end]                  # this is α·r (i.e. c − 1)
            Y = fixed[cols]                         # k × f

            # A = YᵀY + Yᵀ(C−I)Y + λI ; b = Yᵀ C p = Yᵀ (1 + α r) · 1
            A = base + (Y.T * conf) @ Y
            b = Y.T @ (conf + 1.0)

            try:
                out[row] = sla.solve(A, b, assume_a="pos", check_finite=False)
            except (np.linalg.LinAlgError, ValueError):  # pragma: no cover
                out[row] = np.linalg.lstsq(A, b, rcond=None)[0]
        return out

    def _objective(self, C: sp.csr_matrix, U: np.ndarray, V: np.ndarray) -> float:
        """Weighted squared error restricted to observed cells, plus the ridge.

        The full objective includes the (m·n − nnz) unobserved cells with unit
        weight; that term is a constant offset plus ``‖UVᵀ‖_F²`` which can be
        computed in O((m+n)f²) via the Gram trick. Both parts are included so the
        reported figure is the true objective, not a proxy.
        """
        coo = C.tocoo()
        pred = np.einsum("ij,ij->i", U[coo.row], V[coo.col])
        observed = np.sum((coo.data + 1.0) * (1.0 - pred) ** 2)
        gram = float(np.sum((U.T @ U) * (V.T @ V)))     # ‖UVᵀ‖_F² for all cells
        unobserved = gram - float(np.sum(pred ** 2))
        ridge = self.reg * (float(np.sum(U ** 2)) + float(np.sum(V ** 2)))
        return float(observed + unobserved + ridge)

    # ----------------------------------------------------------------- score
    def _score(self, user_idx: int) -> np.ndarray:
        assert self.user_factors_ is not None and self.item_factors_ is not None
        return self.item_factors_ @ self.user_factors_[user_idx]

    def score_batch(self, user_indices) -> np.ndarray:
        self._check_fitted()
        assert self.user_factors_ is not None and self.item_factors_ is not None
        idx = np.asarray(user_indices, dtype=np.int64)
        return self.user_factors_[idx] @ self.item_factors_.T

    # ----------------------------------------------------------- explanation
    def explain(self, user_idx: int, item_idx: int) -> str:
        assert self.user_factors_ is not None and self.item_factors_ is not None
        u = self.user_factors_[user_idx]
        v = self.item_factors_[item_idx]
        contributions = u * v
        top = int(np.argmax(np.abs(contributions)))
        return (
            f"Latent-taste match on factor #{top} "
            f"(affinity {float(contributions[top]):.3f} of {float(contributions.sum()):.3f})."
        )
