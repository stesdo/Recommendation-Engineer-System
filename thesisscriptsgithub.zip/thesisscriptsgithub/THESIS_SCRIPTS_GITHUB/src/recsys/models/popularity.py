"""Non-personalized popularity baseline.

Recommending the globally best-selling articles is the strategy that
personalization must beat in order to justify its cost. It is also a
surprisingly strong competitor: because purchase distributions are extremely
concentrated (Gini ≈ 0.56 in this corpus), a small set of articles accounts for a
disproportionate share of demand, and any evaluation protocol that does not
report a popularity baseline is uninterpretable (Cremonesi et al., 2010;
Ferrari Dacrema et al., 2019).

Two variants are provided, and *both* count distinct purchasers rather than
transaction lines. The plain variant is the raw purchaser count. The
*recency-aware* variant discounts each customer's most recent purchase of an
article by its age, so that an article which sold well eighteen months ago but
has since been discontinued does not dominate the ranking. The decayed statistic
is the closer analogue of the "trending now" module found in production
storefronts.
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np
import pandas as pd

from recsys.features.interactions import InteractionData
from recsys.logging_utils import get_logger
from recsys.models.base import FitContext, Recommender

logger = get_logger(__name__)

__all__ = ["PopularityRecommender"]


class PopularityRecommender(Recommender):
    """Rank items by (optionally time-decayed) purchase incidence."""

    name = "popularity"
    supports_cold_start = True

    def __init__(
        self,
        use_recency: bool = True,
        recency_half_life_days: float = 90.0,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            use_recency=use_recency,
            recency_half_life_days=recency_half_life_days,
            **kwargs,
        )
        self.use_recency = bool(use_recency)
        self.half_life = float(recency_half_life_days)
        self.popularity_: Optional[np.ndarray] = None

    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        frame = context.train_frame

        if self.use_recency and frame is not None and not frame.empty:
            self.popularity_ = self._decayed_popularity(frame, interactions.n_items)
        else:
            self.popularity_ = interactions.item_popularity.astype(np.float64)

        # Normalise to [0, 1] so that scores are comparable with other models
        # when the hybrid combiner mixes raw (rather than rank-based) scores.
        peak = self.popularity_.max()
        if peak > 0:
            self.popularity_ = self.popularity_ / peak

        top = np.argsort(-self.popularity_)[:5]
        logger.debug("  most popular item indices: %s", top.tolist())

    def _decayed_popularity(self, frame: pd.DataFrame, n_items: int) -> np.ndarray:
        """Recency-discounted count of *distinct purchasers* per item.

        The unit of demand must be the customer, not the transaction line. A
        single wholesale buyer ordering the same article on eighty lines is one
        purchaser, and letting the lines accumulate would turn the baseline into
        a bulk-order detector rather than a popularity ranker. Each
        ``(user, item)`` pair therefore contributes exactly once, weighted by
        the age of that customer's *most recent* purchase of the article.
        """
        reference = frame["invoice_date"].max()
        last_per_pair = (
            frame.groupby(["user_idx", "item_idx"], sort=False)["invoice_date"]
            .max()
            .reset_index()
        )
        age_days = (
            reference - last_per_pair["invoice_date"]
        ).dt.total_seconds() / 86_400.0
        weights = np.power(2.0, -np.maximum(age_days.to_numpy(), 0.0) / self.half_life)

        scores = np.zeros(n_items, dtype=np.float64)
        np.add.at(
            scores, last_per_pair["item_idx"].to_numpy(dtype=np.int64), weights
        )
        logger.info(
            "  recency-decayed popularity (half-life %.0f d): "
            "effective support %.1f over %d distinct (customer, item) pairs "
            "drawn from %d transaction lines.",
            self.half_life,
            float(weights.sum()),
            len(last_per_pair),
            len(frame),
        )
        return scores

    def _score(self, user_idx: int) -> np.ndarray:
        assert self.popularity_ is not None
        return self.popularity_

    def score_batch(self, user_indices) -> np.ndarray:
        self._check_fitted()
        assert self.popularity_ is not None
        return np.tile(self.popularity_, (len(user_indices), 1))

    def explain(self, user_idx: int, item_idx: int) -> str:
        assert self.popularity_ is not None
        pct = 100.0 * float(self.popularity_[item_idx])
        return f"Best-seller: {pct:.0f}% of the demand of the top-selling article."
