"""Recommendation model family and its registry.

The registry decouples the pipeline from concrete classes: adding a new
algorithm requires implementing :class:`~recsys.models.base.Recommender` and
registering it here, with no change to the orchestration or evaluation code.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Type

from recsys.models.als import ALSRecommender
from recsys.models.association_rules import (
    AssociationRule,
    AssociationRulesRecommender,
)
from recsys.models.base import FitContext, Recommendation, Recommender, top_n_from_scores
from recsys.models.bpr import BPRRecommender
from recsys.models.content_based import ContentBasedRecommender
from recsys.models.ease import EASERecommender
from recsys.models.hybrid import HybridRecommender, rank_normalize
from recsys.models.item_knn import ItemKNNRecommender
from recsys.models.popularity import PopularityRecommender

__all__ = [
    "Recommender",
    "Recommendation",
    "FitContext",
    "top_n_from_scores",
    "PopularityRecommender",
    "ItemKNNRecommender",
    "EASERecommender",
    "ALSRecommender",
    "BPRRecommender",
    "ContentBasedRecommender",
    "AssociationRulesRecommender",
    "AssociationRule",
    "HybridRecommender",
    "rank_normalize",
    "MODEL_REGISTRY",
    "build_model",
    "available_models",
]


#: Mapping from configuration key → recommender class. The hybrid is absent by
#: design: it is a *meta*-model requiring already-fitted components and is
#: therefore instantiated explicitly by the pipeline.
MODEL_REGISTRY: Dict[str, Type[Recommender]] = {
    "popularity": PopularityRecommender,
    "item_knn": ItemKNNRecommender,
    "ease": EASERecommender,
    "als": ALSRecommender,
    "bpr": BPRRecommender,
    "content_based": ContentBasedRecommender,
    "association_rules": AssociationRulesRecommender,
}


def available_models() -> list[str]:
    """Names of all directly instantiable models."""
    return sorted(MODEL_REGISTRY)


def build_model(name: str, **params: Any) -> Recommender:
    """Instantiate a registered model with the supplied hyper-parameters.

    Raises
    ------
    KeyError
        If ``name`` is not registered, with the list of valid keys attached so
        that configuration typos are immediately diagnosable.
    """
    try:
        cls = MODEL_REGISTRY[name]
    except KeyError as exc:
        raise KeyError(
            f"Unknown model {name!r}. Available models: {available_models()}."
        ) from exc
    return cls(**params)
