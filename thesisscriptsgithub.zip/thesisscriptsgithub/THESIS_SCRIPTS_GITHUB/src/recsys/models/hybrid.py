"""Hybrid meta-recommender combining heterogeneous base models.

Burke's (2002) taxonomy of hybridisation identifies seven mechanisms; four of
the most defensible for implicit-feedback retail data are implemented here.

``weighted``
    A convex combination of *rank-normalised* base scores. Normalisation is
    essential: EASE emits unbounded real numbers, cosine similarity lives in
    [0, 1] and lift is a ratio on [1, ∞). Mixing raw scores would let whichever
    model happens to have the largest scale dominate the blend irrespective of
    its accuracy.

``rrf``
    Reciprocal Rank Fusion (Cormack, Clarke & Büttcher, 2009):
    :math:`\\mathrm{RRF}(i) = \\sum_m 1 / (k + \\mathrm{rank}_m(i))`. It uses only
    ordinal information and is therefore completely immune to scale mismatch,
    while empirically matching or beating far more elaborate learned fusions.

``switching``
    Route each user to a different model according to the density of their
    history. Users below ``cold_start_threshold`` interactions are served by a
    content-based model whose predictions do not require collaborative evidence;
    everyone else is served by the strongest warm model. This directly addresses
    the cold-start pathology discussed in Chapter 3.

``cascade``
    A two-stage architecture: a cheap high-recall model retrieves a candidate
    set, an expensive high-precision model re-ranks it. This mirrors the
    retrieval/ranking split of industrial systems (Covington et al., 2016) and
    is the configuration recommended for production deployment in Chapter 8.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Sequence

import numpy as np

from recsys.features.interactions import InteractionData
from recsys.logging_utils import get_logger
from recsys.models.base import FitContext, Recommender, top_n_from_scores

logger = get_logger(__name__)

__all__ = ["HybridRecommender", "rank_normalize", "minmax_normalize", "zscore_normalize"]


# ---------------------------------------------------------------------------
# score normalisation
# ---------------------------------------------------------------------------
def rank_normalize(scores: np.ndarray) -> np.ndarray:
    """Map scores onto [0, 1] by their descending rank.

    Rank normalisation discards magnitude but preserves order, which makes it
    robust to heavy-tailed score distributions and to models whose outputs are
    not on a probability scale.
    """
    n = scores.size
    if n == 0:
        return scores
    order = np.argsort(-scores, kind="stable")
    ranks = np.empty(n, dtype=np.float64)
    ranks[order] = np.arange(n, dtype=np.float64)
    return 1.0 - ranks / max(n - 1, 1)


def minmax_normalize(scores: np.ndarray) -> np.ndarray:
    """Affine rescaling to [0, 1]; sensitive to outliers but magnitude-aware."""
    finite = scores[np.isfinite(scores)]
    if finite.size == 0:
        return np.zeros_like(scores)
    lo, hi = float(finite.min()), float(finite.max())
    if hi - lo < 1e-12:
        return np.zeros_like(scores)
    return np.clip((scores - lo) / (hi - lo), 0.0, 1.0)


def zscore_normalize(scores: np.ndarray) -> np.ndarray:
    """Standardisation to zero mean and unit variance."""
    mu, sigma = float(np.mean(scores)), float(np.std(scores))
    return (scores - mu) / sigma if sigma > 1e-12 else np.zeros_like(scores)


# ---------------------------------------------------------------------------
class HybridRecommender(Recommender):
    """Combine several fitted base models under a configurable strategy."""

    name = "hybrid"

    def __init__(
        self,
        base_models: Dict[str, Recommender],
        strategy: str = "weighted",
        weights: Optional[Dict[str, float]] = None,
        rrf_k: int = 60,
        cold_start_threshold: int = 3,
        cold_start_model: str = "content_based",
        warm_model: str = "ease",
        cascade_retrieval_model: str = "item_knn",
        cascade_candidates: int = 200,
        normalization: str = "rank",
        **kwargs: Any,
    ) -> None:
        super().__init__(
            strategy=strategy,
            rrf_k=rrf_k,
            cold_start_threshold=cold_start_threshold,
            normalization=normalization,
            **kwargs,
        )
        if strategy not in ("weighted", "rrf", "switching", "cascade"):
            raise ValueError(
                "strategy must be weighted|rrf|switching|cascade; got "
                f"{strategy!r}."
            )
        if not base_models:
            raise ValueError("HybridRecommender requires at least one base model.")

        self.base_models = dict(base_models)
        self.strategy = strategy
        self.rrf_k = int(rrf_k)
        self.cold_start_threshold = int(cold_start_threshold)
        self.cold_start_model = cold_start_model
        self.warm_model = warm_model
        self.cascade_retrieval_model = cascade_retrieval_model
        self.cascade_candidates = int(cascade_candidates)
        self.normalization = normalization

        self.weights = self._resolve_weights(weights)
        self._user_activity: Optional[np.ndarray] = None

    def _resolve_weights(self, weights: Optional[Dict[str, float]]) -> Dict[str, float]:
        """Restrict weights to available models and renormalise to sum to one."""
        if not weights:
            uniform = 1.0 / len(self.base_models)
            return {name: uniform for name in self.base_models}

        applicable = {
            name: float(w)
            for name, w in weights.items()
            if name in self.base_models and w > 0
        }
        if not applicable:
            logger.warning(
                "None of the configured hybrid weights match an available model; "
                "falling back to uniform weighting."
            )
            uniform = 1.0 / len(self.base_models)
            return {name: uniform for name in self.base_models}

        total = sum(applicable.values())
        normalised = {name: w / total for name, w in applicable.items()}
        missing = set(self.base_models) - set(normalised)
        if missing:
            logger.info("  hybrid ignores un-weighted models: %s", sorted(missing))
        return normalised

    # ------------------------------------------------------------------- fit
    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        """Base models are fitted upstream; the hybrid only validates them."""
        unfitted = [n for n, m in self.base_models.items() if not m.is_fitted]
        if unfitted:
            raise RuntimeError(
                f"Hybrid requires pre-fitted base models; unfitted: {unfitted}."
            )
        self._user_activity = interactions.user_activity

        for name, model in self.base_models.items():
            if model.n_items != interactions.n_items:
                raise ValueError(
                    f"Base model '{name}' scores {model.n_items} items but the "
                    f"hybrid expects {interactions.n_items}."
                )
        logger.info(
            "  hybrid strategy=%s over %d base models; weights=%s.",
            self.strategy,
            len(self.base_models),
            {k: round(v, 3) for k, v in sorted(self.weights.items())},
        )

    # ----------------------------------------------------------------- score
    def _score(self, user_idx: int) -> np.ndarray:
        if self.strategy == "weighted":
            return self._score_weighted(user_idx)
        if self.strategy == "rrf":
            return self._score_rrf(user_idx)
        if self.strategy == "switching":
            return self._score_switching(user_idx)
        return self._score_cascade(user_idx)

    def _normalise(self, scores: np.ndarray) -> np.ndarray:
        if self.normalization == "minmax":
            return minmax_normalize(scores)
        if self.normalization == "zscore":
            return zscore_normalize(scores)
        return rank_normalize(scores)

    def _score_weighted(self, user_idx: int) -> np.ndarray:
        combined = np.zeros(self.n_items, dtype=np.float64)
        for name, weight in self.weights.items():
            model = self.base_models.get(name)
            if model is None:
                continue
            combined += weight * self._normalise(model.score(user_idx))
        return combined

    def _score_rrf(self, user_idx: int) -> np.ndarray:
        combined = np.zeros(self.n_items, dtype=np.float64)
        for name, model in self.base_models.items():
            scores = model.score(user_idx)
            order = np.argsort(-scores, kind="stable")
            ranks = np.empty(self.n_items, dtype=np.float64)
            ranks[order] = np.arange(1, self.n_items + 1, dtype=np.float64)
            weight = self.weights.get(name, 1.0 / len(self.base_models))
            combined += weight / (self.rrf_k + ranks)
        return combined

    def _score_switching(self, user_idx: int) -> np.ndarray:
        activity = (
            float(self._user_activity[user_idx])
            if self._user_activity is not None
            else 0.0
        )
        preferred = (
            self.cold_start_model
            if activity < self.cold_start_threshold
            else self.warm_model
        )
        model = self.base_models.get(preferred)
        if model is None:
            # Graceful degradation: fall back to weighted fusion.
            return self._score_weighted(user_idx)
        return self._normalise(model.score(user_idx))

    def _score_cascade(self, user_idx: int) -> np.ndarray:
        """Retrieve with a cheap model, re-rank the shortlist with the weighted blend."""
        retriever = self.base_models.get(self.cascade_retrieval_model)
        if retriever is None:
            return self._score_weighted(user_idx)

        candidates = top_n_from_scores(
            retriever.score(user_idx), self.cascade_candidates
        )
        if candidates.size == 0:
            return self._score_weighted(user_idx)

        # Re-ranking scores are confined to the candidate set; everything else
        # is pushed below by an offset that preserves the retrieval ordering.
        reranked = self._score_weighted(user_idx)
        out = np.full(self.n_items, -np.inf, dtype=np.float64)
        out[candidates] = reranked[candidates]
        return out

    # ----------------------------------------------------------- explanation
    def explain(self, user_idx: int, item_idx: int) -> str:
        """Attribute the recommendation to the base model that contributed most."""
        contributions: List[tuple[str, float]] = []
        for name, weight in self.weights.items():
            model = self.base_models.get(name)
            if model is None:
                continue
            normalised = self._normalise(model.score(user_idx))
            contributions.append((name, weight * float(normalised[item_idx])))
        if not contributions:
            return f"Recommended by {self.name}."
        best_name, best_value = max(contributions, key=lambda kv: kv[1])
        detail = self.base_models[best_name].explain(user_idx, item_idx)
        return f"[{best_name}, contribution {best_value:.3f}] {detail}"

    def contribution_breakdown(self, user_idx: int, item_idx: int) -> Dict[str, float]:
        """Per-model contribution to a single recommendation (for the API)."""
        out: Dict[str, float] = {}
        for name, weight in self.weights.items():
            model = self.base_models.get(name)
            if model is None:
                continue
            out[name] = weight * float(self._normalise(model.score(user_idx))[item_idx])
        return out
