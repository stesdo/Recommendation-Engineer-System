"""Bayesian Personalised Ranking for implicit feedback (BPR-MF).

Rendle et al. (2009) formulated implicit feedback as a pairwise ranking problem:
for each observed interaction (u, i), sample an unobserved item j and optimise
the model so that :math:`\\hat r_{ui} > \\hat r_{uj}`. The loss is the negative
log-likelihood of a logistic model of the ranking margin,

.. math::

    \\mathcal{L} = -\\sum_{(u,i,j) \\in \\mathcal{D_S}}
                    \\log \\sigma(\\hat r_{ui} - \\hat r_{uj})
                  + \\lambda \\|\\Theta\\|^2 ,

where :math:`\\mathcal{D_S}` is the set of (user, positive, negative) triplets
sampled during training and :math:`\\sigma(x) = 1 / (1 + e^{-x})`.

Training follows Rendle's LearnBPR: each epoch draws :math:`|\\mathcal{D_S}|`
triplets **uniformly over the observed ``(u, i)`` pairs** — not uniformly over
users and then over each user's items, which would systematically under-weight
active customers — and applies one SGD step per triplet with a decaying learning
rate. Convergence is judged on the average per-triplet loss, but only after a
warm-up: an untrained factorisation sits at :math:`-\\log \\sigma(0) = \\log 2`
with a near-zero gradient signal, so a tight plateau test applied from the first
epochs cannot distinguish "converged" from "has not started moving yet".
"""

from __future__ import annotations

from typing import Any, Optional

import numpy as np

from recsys.features.interactions import InteractionData
from recsys.logging_utils import ProgressReporter, get_logger
from recsys.models.base import FitContext, Recommender

logger = get_logger(__name__)

__all__ = ["BPRRecommender"]


class BPRRecommender(Recommender):
    """Matrix factorisation trained with Bayesian Personalised Ranking."""

    name = "bpr"

    #: Epochs completed before the plateau test is allowed to fire. The loss
    #: begins at log 2 by construction, so an early tight test would stop
    #: training before it has begun.
    MIN_EPOCHS_BEFORE_STOP = 10

    #: Relative tolerance for the plateau test. Deliberately loose: the
    #: per-triplet loss is a stochastic estimate, and 1e-4 is well inside its
    #: sampling noise at this batch size.
    PLATEAU_TOLERANCE = 1e-3

    #: Triplets per vectorised update. Mini-batching is what makes a full
    #: LearnBPR schedule (nnz triplets per epoch) tractable in NumPy; the
    #: gradient is evaluated at the parameters held at the start of each batch.
    BATCH = 4096

    def __init__(
        self,
        factors: int = 96,
        learning_rate: float = 0.05,
        regularization: float = 0.01,
        epochs: int = 60,
        negative_samples: int = 1,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            factors=factors,
            learning_rate=learning_rate,
            regularization=regularization,
            epochs=epochs,
            negative_samples=negative_samples,
            **kwargs,
        )
        self.factors = int(factors)
        self.lr = float(learning_rate)
        self.reg = float(regularization)
        self.epochs = int(epochs)
        self.neg_samples = int(negative_samples)
        self.user_factors_: Optional[np.ndarray] = None
        self.item_factors_: Optional[np.ndarray] = None
        self.loss_history_: list[float] = []

    # ------------------------------------------------------------------- fit
    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        rng = np.random.default_rng(context.random_seed)
        m, n, f = interactions.n_users, interactions.n_items, self.factors

        # Random initialisation with Gaussian noise.
        scale = 0.01
        U = rng.normal(0.0, scale, size=(m, f))
        V = rng.normal(0.0, scale, size=(n, f))

        # Positive items per user (as a list of arrays for efficient sampling).
        positives = [interactions.seen_items(u) for u in range(m)]
        users_with_data = [u for u in range(m) if positives[u].size > 0]

        if not users_with_data:
            logger.warning("No training interactions; BPR cannot be fitted.")
            self.user_factors_, self.item_factors_ = U, V
            return

        # LearnBPR draws one triplet per observed interaction per epoch. Using
        # the number of *users* here (the earlier behaviour) under-trains the
        # model by a factor of nnz / n_users — roughly 75× on this corpus.
        coo = interactions.binary.tocoo()
        pair_users = coo.row.astype(np.int64, copy=False)
        pair_items = coo.col.astype(np.int64, copy=False)
        n_pairs = int(pair_users.size)
        n_steps = n_pairs * self.neg_samples

        # Sorted codes of observed (u, i) cells, for O(log nnz) vectorised
        # membership testing when rejecting sampled negatives.
        observed_codes = np.sort(pair_users * np.int64(n) + pair_items)

        logger.info(
            "  BPR: %d observed pairs × %d negative(s) = %d updates per epoch, "
            "up to %d epochs, mini-batch %d.",
            n_pairs,
            self.neg_samples,
            n_steps,
            self.epochs,
            self.BATCH,
        )
        reporter = ProgressReporter(self.epochs, f"BPR ({f} factors)", logger, 5.0)

        for epoch in range(1, self.epochs + 1):
            epoch_loss = 0.0
            counted = 0
            lr_t = self.lr / (1.0 + 0.01 * epoch)

            # Uniform draw over observed (u, i) pairs — Rendle's bootstrap.
            picks = rng.integers(0, n_pairs, size=n_steps)

            for start in range(0, n_steps, self.BATCH):
                sel = picks[start : start + self.BATCH]
                u = pair_users[sel]
                i = pair_items[sel]
                j = rng.integers(0, n, size=sel.size)

                # Reject negatives that are actually observed: one resample
                # round, then discard the few stragglers. At ~98% sparsity the
                # discard rate is well under 1%.
                for _ in range(2):
                    codes = u * np.int64(n) + j
                    pos = np.searchsorted(observed_codes, codes)
                    pos = np.minimum(pos, observed_codes.size - 1)
                    clash = observed_codes[pos] == codes
                    if not clash.any():
                        break
                    j[clash] = rng.integers(0, n, size=int(clash.sum()))
                codes = u * np.int64(n) + j
                pos = np.minimum(
                    np.searchsorted(observed_codes, codes), observed_codes.size - 1
                )
                keep = observed_codes[pos] != codes
                if not keep.all():
                    u, i, j = u[keep], i[keep], j[keep]
                if u.size == 0:
                    continue

                # Forward pass on the batch.
                u_vec, i_vec, j_vec = U[u], V[i], V[j]
                diff = i_vec - j_vec
                x_uij = np.einsum("ij,ij->i", u_vec, diff)
                sigmoid = 1.0 / (1.0 + np.exp(-np.clip(x_uij, -30.0, 30.0)))
                epoch_loss += float(-np.log(sigmoid + 1e-10).sum())
                counted += int(u.size)

                # Gradients (identical algebra to the per-triplet form).
                d = (sigmoid - 1.0)[:, None]
                grad_u = d * diff + self.reg * u_vec
                grad_i = d * u_vec + self.reg * i_vec
                grad_j = -d * u_vec + self.reg * j_vec

                # ``np.add.at`` accumulates correctly when an index repeats
                # inside the batch; plain fancy-index assignment would not.
                np.add.at(U, u, -lr_t * grad_u)
                np.add.at(V, i, -lr_t * grad_i)
                np.add.at(V, j, -lr_t * grad_j)

            avg_loss = epoch_loss / counted if counted else float("nan")
            self.loss_history_.append(avg_loss)
            logger.debug("  BPR epoch %2d — loss %.4f, lr %.5f", epoch, avg_loss, lr_t)
            reporter.update(1)

            # Early stop only after a warm-up, and only on a genuine plateau.
            if epoch >= self.MIN_EPOCHS_BEFORE_STOP and len(self.loss_history_) >= 4:
                recent = self.loss_history_[-3:]
                if all(
                    abs(recent[0] - l) / (recent[0] + 1e-8) < self.PLATEAU_TOLERANCE
                    for l in recent[1:]
                ):
                    logger.info("  BPR converged at epoch %d.", epoch)
                    break
        reporter.close()

        self.user_factors_ = U
        self.item_factors_ = V
        logger.info(
            "  BPR factors: U%s V%s, final loss %.4f.",
            U.shape,
            V.shape,
            self.loss_history_[-1] if self.loss_history_ else float("nan"),
        )

    # ----------------------------------------------------------------- score
    def _score(self, user_idx: int) -> np.ndarray:
        assert self.user_factors_ is not None and self.item_factors_ is not None
        return self.item_factors_ @ self.user_factors_[user_idx]

    def score_batch(self, user_indices) -> np.ndarray:
        self._check_fitted()
        assert self.user_factors_ is not None and self.item_factors_ is not None
        idx = np.asarray(user_indices, dtype=np.int64)
        return self.user_factors_[idx] @ self.item_factors_.T
