"""Item-based collaborative filtering (item-kNN).

Item-based neighbourhood models (Sarwar et al., 2001; Deshpande & Karypis, 2004)
remain the workhorse of industrial recommendation because they combine three
properties that are difficult to obtain simultaneously: competitive accuracy,
constant-time incremental updates, and *explainability* — the recommendation
"because you bought X" is directly readable from the model.

Scoring is the sparse product

.. math::

    \\hat r_{u} = c_u^{\\top} S,

where :math:`c_u` is the user's confidence row and :math:`S` the sparsified
item-item similarity matrix.

Three similarity measures are supported.

*Cosine with shrinkage.* Raw cosine over-rewards pairs supported by very few
co-purchases. Following Bell & Koren (2007) the estimate is shrunk towards zero
in proportion to the support:

.. math::

    s_{ij} = \\frac{\\langle v_i, v_j\\rangle}
                   {\\|v_i\\|\\,\\|v_j\\| + \\lambda},

with :math:`\\lambda` the shrinkage constant. This is a maximum-a-posteriori
estimate under a zero-mean prior and is the single most effective regularisation
available to a neighbourhood model.

*BM25* and *TF–IDF* apply the corresponding re-weighting to the interaction
matrix before computing cosine, which suppresses the influence of blockbuster
items and of users with pathologically long histories.

Sparsification retains only the ``top_k`` strongest neighbours of each item.
Beyond the obvious memory benefit, truncation acts as a denoising operator:
weak similarities are dominated by sampling noise and their removal reliably
*improves* accuracy.
"""

from __future__ import annotations

from typing import Any, List, Optional, Tuple

import numpy as np
import scipy.sparse as sp

from recsys.features.interactions import (
    InteractionData,
    bm25_weight,
    normalize_rows_l2,
    tfidf_weight,
)
from recsys.logging_utils import get_logger
from recsys.models.base import FitContext, Recommender

logger = get_logger(__name__)

__all__ = ["ItemKNNRecommender"]


class ItemKNNRecommender(Recommender):
    """Sparse item-item neighbourhood model with shrinkage and truncation."""

    name = "item_knn"

    def __init__(
        self,
        top_k: int = 200,
        similarity: str = "cosine",
        shrinkage: float = 20.0,
        bm25_k1: float = 1.2,
        bm25_b: float = 0.75,
        normalize_scores: bool = True,
        **kwargs: Any,
    ) -> None:
        super().__init__(
            top_k=top_k,
            similarity=similarity,
            shrinkage=shrinkage,
            bm25_k1=bm25_k1,
            bm25_b=bm25_b,
            normalize_scores=normalize_scores,
            **kwargs,
        )
        if similarity not in ("cosine", "bm25", "tfidf_cosine"):
            raise ValueError(
                "similarity must be one of 'cosine', 'bm25', 'tfidf_cosine'; "
                f"got {similarity!r}."
            )
        self.top_k = int(top_k)
        self.similarity = similarity
        self.shrinkage = float(shrinkage)
        self.bm25_k1 = float(bm25_k1)
        self.bm25_b = float(bm25_b)
        self.normalize_scores = bool(normalize_scores)
        self.similarity_: Optional[sp.csr_matrix] = None
        self._user_matrix: Optional[sp.csr_matrix] = None

    # ------------------------------------------------------------------- fit
    def _fit(self, interactions: InteractionData, context: FitContext) -> None:
        matrix = interactions.matrix.astype(np.float32)

        if self.similarity == "bm25":
            weighted = bm25_weight(matrix, k1=self.bm25_k1, b=self.bm25_b)
        elif self.similarity == "tfidf_cosine":
            weighted = tfidf_weight(matrix)
        else:
            weighted = matrix

        self._user_matrix = sp.csr_matrix(weighted)
        similarity = self._cosine_with_shrinkage(weighted)
        self.similarity_ = self._truncate(similarity, self.top_k)

        density = self.similarity_.nnz / max(interactions.n_items ** 2, 1)
        logger.info(
            "  item-item similarity: nnz=%d (density %.4f%%), k=%d, λ=%.1f, metric=%s.",
            self.similarity_.nnz,
            100.0 * density,
            self.top_k,
            self.shrinkage,
            self.similarity,
        )

    def _cosine_with_shrinkage(self, matrix: sp.csr_matrix) -> sp.csr_matrix:
        """Compute the shrunk cosine similarity between item columns."""
        item_matrix = sp.csc_matrix(matrix).T.tocsr()          # items × users
        gram = (item_matrix @ item_matrix.T).tocsr()           # co-occurrence
        gram.setdiag(0.0)
        gram.eliminate_zeros()

        norms = np.sqrt(np.asarray(item_matrix.multiply(item_matrix).sum(axis=1))).ravel()
        norms = norms.astype(np.float64)

        gram = gram.tocoo()
        denom = norms[gram.row] * norms[gram.col] + self.shrinkage
        denom[denom == 0] = 1e-12
        values = gram.data / denom

        out = sp.csr_matrix(
            (values.astype(np.float32), (gram.row, gram.col)), shape=gram.shape
        )
        out.eliminate_zeros()
        return out

    @staticmethod
    def _truncate(similarity: sp.csr_matrix, k: int) -> sp.csr_matrix:
        """Retain only the ``k`` largest similarities per row."""
        sim = similarity.tocsr()
        if k <= 0:
            return sim

        rows, cols, vals = [], [], []
        indptr, indices, data = sim.indptr, sim.indices, sim.data
        for i in range(sim.shape[0]):
            start, end = indptr[i], indptr[i + 1]
            row_data = data[start:end]
            if row_data.size == 0:
                continue
            if row_data.size > k:
                sel = np.argpartition(-row_data, k - 1)[:k]
            else:
                sel = np.arange(row_data.size)
            rows.append(np.full(sel.size, i, dtype=np.int32))
            cols.append(indices[start:end][sel])
            vals.append(row_data[sel])

        if not rows:  # pragma: no cover - degenerate
            return sp.csr_matrix(sim.shape, dtype=np.float32)

        out = sp.csr_matrix(
            (
                np.concatenate(vals).astype(np.float32),
                (np.concatenate(rows), np.concatenate(cols)),
            ),
            shape=sim.shape,
        )
        out.eliminate_zeros()
        return out

    # ----------------------------------------------------------------- score
    def _score(self, user_idx: int) -> np.ndarray:
        assert self.similarity_ is not None and self._user_matrix is not None
        user_row = self._user_matrix[user_idx]
        if user_row.nnz == 0:
            return np.zeros(self.n_items, dtype=np.float64)

        scores = np.asarray((user_row @ self.similarity_).todense()).ravel()
        if self.normalize_scores:
            peak = np.abs(scores).max()
            if peak > 0:
                scores = scores / peak
        return scores

    def score_batch(self, user_indices) -> np.ndarray:
        self._check_fitted()
        assert self.similarity_ is not None and self._user_matrix is not None
        block = self._user_matrix[np.asarray(user_indices, dtype=np.int64)]
        scores = np.asarray((block @ self.similarity_).todense(), dtype=np.float64)
        if self.normalize_scores:
            peaks = np.abs(scores).max(axis=1, keepdims=True)
            peaks[peaks == 0] = 1.0
            scores = scores / peaks
        return scores

    # ----------------------------------------------------------- explanation
    def neighbours(self, item_idx: int, n: int = 5) -> List[Tuple[int, float]]:
        """The ``n`` items most similar to ``item_idx``."""
        assert self.similarity_ is not None
        row = self.similarity_[item_idx]
        if row.nnz == 0:
            return []
        order = np.argsort(-row.data)[:n]
        return [(int(row.indices[j]), float(row.data[j])) for j in order]

    def explain(self, user_idx: int, item_idx: int) -> str:
        """Identify which purchased article contributed most to the score."""
        assert self.similarity_ is not None and self._user_matrix is not None
        user_row = self._user_matrix[user_idx]
        if user_row.nnz == 0:
            return "No purchase history available."

        column = self.similarity_[:, item_idx]
        contributions = []
        for pos, purchased in enumerate(user_row.indices):
            weight = float(user_row.data[pos])
            sim = float(column[purchased, 0]) if column[purchased, 0] != 0 else 0.0
            if sim > 0:
                contributions.append((purchased, weight * sim))
        if not contributions:
            return f"Recommended by {self.name}."
        best = max(contributions, key=lambda t: t[1])
        return f"Because you bought item #{best[0]} (contribution {best[1]:.3f})."
