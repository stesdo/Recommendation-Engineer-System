"""HTTP serving layer.

Imports are deferred to :func:`recsys.service.api.create_app` so that the core
package remains importable in environments where FastAPI is not installed.
"""

from __future__ import annotations

__all__ = ["create_app", "RecommendationService"]


def __getattr__(name: str):  # pragma: no cover - thin lazy-import shim
    if name in __all__:
        from recsys.service import api

        return getattr(api, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
