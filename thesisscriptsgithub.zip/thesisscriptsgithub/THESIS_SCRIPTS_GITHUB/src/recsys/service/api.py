"""FastAPI application exposing the trained engine.

The service demonstrates that the research artefact is deployable, which is a
substantive claim of the thesis rather than a decorative extra: a recommendation
model that cannot answer a request in tens of milliseconds is not a
recommendation *system*.

Endpoints
---------
``GET  /health``                     — liveness and loaded-model inventory
``GET  /recommend/{customer_id}``    — personalized top-N with explanations
``POST /cross-sell``                 — basket-conditioned complements
``GET  /up-sell/{item_id}``          — higher-priced substitutes
``GET  /customer/{customer_id}``     — RFM/CLV profile
``GET  /models``                     — model inventory with evaluation scores

The models are fitted once at start-up and held in memory. This mirrors the
standard production topology, where training is an offline batch job and serving
is a read-only path over precomputed parameters.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from recsys.config import Config
from recsys.logging_utils import get_logger
from recsys.service.schemas import (
    BasketRequest,
    CrossSellResponse,
    CustomerProfileResponse,
    HealthResponse,
    ItemOut,
    ModelInfo,
    ModelsResponse,
    RecommendationResponse,
    UpSellResponse,
)

logger = get_logger(__name__)

__all__ = ["create_app", "RecommendationService"]


class RecommendationService:
    """In-memory serving layer over the artefacts of a pipeline run."""

    def __init__(self, cfg: Config, project_root: Optional[Path] = None) -> None:
        from recsys.pipeline import Pipeline

        self.cfg = cfg
        logger.info("Warming up the service — running the training pipeline …")
        self.artifacts = Pipeline(cfg, project_root=project_root).run()

        split = self.artifacts.split
        if split is None:
            raise RuntimeError("Pipeline produced no split; cannot serve.")
        self.split = split
        self.interactions = self.artifacts.interactions
        self.content = self.artifacts.content

        # Choose the serving model: configured preference, else the winner.
        preferred = cfg.service.model_for_serving
        self.serving_name = (
            preferred
            if preferred in self.artifacts.models
            else (
                self.artifacts.best_model_name(cfg.evaluation.primary_metric)
                or next(iter(self.artifacts.models))
            )
        )
        self.model = self.artifacts.models[self.serving_name]
        logger.info("Serving model: '%s'.", self.serving_name)

        self._build_merchandising_engines()
        self._precompute_customer_facts()

    # -------------------------------------------------------------- warm-up
    def _build_merchandising_engines(self) -> None:
        from recsys.business.cross_sell import CrossSellEngine, UpSellEngine

        self.cross_sell = None
        rules = self.artifacts.models.get("association_rules")
        if rules is not None:
            try:
                self.cross_sell = CrossSellEngine(
                    rules,
                    self.interactions.item_mean_price,
                    gross_margin=self.cfg.business.gross_margin,
                    item_ids=self.split.item_ids,
                    descriptions=self.content.descriptions,
                )
            except Exception as exc:  # pragma: no cover
                logger.warning("Cross-sell engine unavailable: %s", exc)

        self.up_sell = UpSellEngine(
            self.content.matrix,
            self.interactions.item_mean_price,
            item_ids=self.split.item_ids,
            descriptions=self.content.descriptions,
        )

    def _precompute_customer_facts(self) -> None:
        """Index the per-customer aggregates the profile endpoint needs."""
        frame = self.artifacts.clean_frame
        self.customer_facts: Dict[int, Dict[str, float]] = {}
        if frame is None or frame.empty:
            return
        agg = frame.groupby("customer_id").agg(
            n_orders=("invoice", "nunique"),
            n_items=("stock_code", "nunique"),
            total_spend=("revenue", "sum"),
        )
        self.customer_facts = {
            int(cid): {
                "n_orders": float(row.n_orders),
                "n_items": float(row.n_items),
                "total_spend": float(row.total_spend),
            }
            for cid, row in agg.iterrows()
        }

    # --------------------------------------------------------------- lookup
    def item_index(self, item_id: str) -> Optional[int]:
        return self.split.item_map.get(str(item_id).strip().upper())

    def user_index(self, customer_id: int) -> Optional[int]:
        return self.split.user_map.get(int(customer_id))

    def _to_item_out(
        self, item_idx: int, rank: int, score: float, reason: Optional[str] = None
    ) -> ItemOut:
        return ItemOut(
            rank=rank,
            item_id=str(self.split.item_ids[item_idx]),
            description=str(self.content.descriptions[item_idx]) if self.content else "",
            price=float(self.interactions.item_mean_price[item_idx]),
            score=float(score),
            reason=reason,
        )

    # ------------------------------------------------------------ endpoints
    def recommend(
        self, customer_id: int, n: int, explain: bool, model_name: Optional[str] = None
    ) -> RecommendationResponse:
        start = time.perf_counter()

        user_idx = self.user_index(customer_id)
        if user_idx is None:
            raise KeyError(f"Customer {customer_id} is unknown to the engine.")

        model = self.artifacts.models.get(model_name or self.serving_name, self.model)
        scores = model.score(user_idx)
        top = model.recommend(user_idx, n=n, exclude_seen=True)

        items = [
            self._to_item_out(
                int(idx),
                rank,
                float(scores[idx]),
                model.explain(user_idx, int(idx)) if explain else None,
            )
            for rank, idx in enumerate(top, start=1)
        ]

        segment, clv = self._customer_value(customer_id)
        return RecommendationResponse(
            customer_id=customer_id,
            model=model.name,
            n_returned=len(items),
            items=items,
            segment=segment,
            predicted_clv=clv,
            latency_ms=1000.0 * (time.perf_counter() - start),
        )

    def cross_sell_for(self, request: BasketRequest) -> CrossSellResponse:
        start = time.perf_counter()
        if self.cross_sell is None:
            raise RuntimeError("The association-rule model is not available.")

        basket = [self.item_index(i) for i in request.item_ids]
        known = [i for i in basket if i is not None]
        if not known:
            raise KeyError("None of the supplied item identifiers is in the catalogue.")

        suggestions = self.cross_sell.suggest(
            known, n=request.n, margin_weight=request.margin_weight
        )
        items = [
            self._to_item_out(s.item_idx, rank, s.score, s.reason)
            for rank, s in enumerate(suggestions, start=1)
        ]
        return CrossSellResponse(
            basket=request.item_ids,
            n_returned=len(items),
            suggestions=items,
            total_expected_margin=float(sum(s.expected_margin for s in suggestions)),
            latency_ms=1000.0 * (time.perf_counter() - start),
        )

    def up_sell_for(self, item_id: str, n: int) -> UpSellResponse:
        start = time.perf_counter()
        anchor = self.item_index(item_id)
        if anchor is None:
            raise KeyError(f"Item {item_id} is not in the catalogue.")

        suggestions = self.up_sell.suggest(anchor, n=n)
        items = [
            self._to_item_out(s.item_idx, rank, s.score, s.reason)
            for rank, s in enumerate(suggestions, start=1)
        ]
        return UpSellResponse(
            anchor_item=item_id,
            anchor_price=float(self.interactions.item_mean_price[anchor]),
            n_returned=len(items),
            suggestions=items,
            latency_ms=1000.0 * (time.perf_counter() - start),
        )

    def customer_profile(self, customer_id: int) -> CustomerProfileResponse:
        user_idx = self.user_index(customer_id)
        if user_idx is None:
            raise KeyError(f"Customer {customer_id} is unknown to the engine.")

        facts = self.customer_facts.get(customer_id, {})
        segment, clv = self._customer_value(customer_id)

        rfm_scores = None
        probability_alive = None
        if self.artifacts.rfm is not None and customer_id in self.artifacts.rfm.table.index:
            row = self.artifacts.rfm.table.loc[customer_id]
            rfm_scores = {
                "recency_days": float(row["recency_days"]),
                "frequency": float(row["frequency"]),
                "monetary": float(row["monetary"]),
                "r_score": float(row["r_score"]),
                "f_score": float(row["f_score"]),
                "m_score": float(row["m_score"]),
            }
        if self.artifacts.clv is not None and customer_id in self.artifacts.clv.table.index:
            probability_alive = float(
                self.artifacts.clv.table.loc[customer_id, "probability_alive"]
            )

        seen = self.interactions.seen_items(user_idx)
        weights = self.interactions.matrix[user_idx]
        order = np.argsort(-weights.data)[:10] if weights.nnz else np.array([], int)
        top_purchased = [
            self._to_item_out(int(weights.indices[j]), rank, float(weights.data[j]))
            for rank, j in enumerate(order, start=1)
        ]

        return CustomerProfileResponse(
            customer_id=customer_id,
            n_distinct_items=int(seen.size),
            n_orders=int(facts.get("n_orders", 0)),
            total_spend=float(facts.get("total_spend", 0.0)),
            segment=segment,
            rfm_scores=rfm_scores,
            predicted_clv=clv,
            probability_alive=probability_alive,
            top_purchased=top_purchased,
        )

    def model_inventory(self) -> ModelsResponse:
        infos: List[ModelInfo] = []
        for name, model in sorted(self.artifacts.models.items()):
            result = self.artifacts.results.get(name)
            infos.append(
                ModelInfo(
                    name=name,
                    hyperparameters={k: str(v) for k, v in model.params.items()},
                    fit_seconds=self.artifacts.fit_seconds.get(name),
                    ndcg_at_10=(
                        float(result.get("ndcg@10")) if result and np.isfinite(result.get("ndcg@10")) else None
                    ),
                    coverage_at_10=(
                        float(result.get("coverage@10")) if result and np.isfinite(result.get("coverage@10")) else None
                    ),
                    supports_cold_start=model.supports_cold_start,
                )
            )
        return ModelsResponse(
            serving_model=self.serving_name,
            primary_metric=self.cfg.evaluation.primary_metric,
            models=infos,
        )

    def health(self) -> HealthResponse:
        from recsys import __version__

        return HealthResponse(
            status="ok",
            version=__version__,
            models_loaded=sorted(self.artifacts.models),
            n_users=self.split.n_users,
            n_items=self.split.n_items,
            serving_model=self.serving_name,
        )

    # --------------------------------------------------------------- helpers
    def _customer_value(self, customer_id: int) -> tuple[Optional[str], Optional[float]]:
        segment = None
        if self.artifacts.rfm is not None:
            segment = self.artifacts.rfm.segment_of(customer_id)
        clv = None
        if self.artifacts.clv is not None and customer_id in self.artifacts.clv.table.index:
            clv = float(self.artifacts.clv.table.loc[customer_id, "clv"])
        return segment, clv


# ===========================================================================
def create_app(cfg: Config, project_root: Optional[Path] = None):
    """Construct the FastAPI application with a warmed-up service."""
    from fastapi import FastAPI, HTTPException, Query
    from fastapi.middleware.cors import CORSMiddleware

    from recsys import __version__

    app = FastAPI(
        title="Hyper-Personalization Recommendation Engine",
        description=(
            "Hybrid recommendation service over the Online Retail II corpus. "
            "Software artefact of diploma thesis 281549."
        ),
        version=__version__,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    service = RecommendationService(cfg, project_root=project_root)
    max_n = cfg.service.max_top_n

    @app.get("/health", response_model=HealthResponse, tags=["system"])
    def health() -> HealthResponse:
        return service.health()

    @app.get("/models", response_model=ModelsResponse, tags=["system"])
    def models() -> ModelsResponse:
        return service.model_inventory()

    @app.get(
        "/recommend/{customer_id}",
        response_model=RecommendationResponse,
        tags=["recommendations"],
        summary="Personalized top-N recommendations",
    )
    def recommend(
        customer_id: int,
        n: int = Query(cfg.service.default_top_n, ge=1, le=max_n),
        explain: bool = Query(False, description="Include per-item justifications."),
        model: Optional[str] = Query(None, description="Override the serving model."),
    ) -> RecommendationResponse:
        try:
            return service.recommend(customer_id, n=n, explain=explain, model_name=model)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except Exception as exc:  # pragma: no cover
            logger.error("recommend failed: %s", exc, exc_info=True)
            raise HTTPException(status_code=500, detail="Internal error.") from exc

    @app.post(
        "/cross-sell",
        response_model=CrossSellResponse,
        tags=["merchandising"],
        summary="Basket-conditioned complementary products",
    )
    def cross_sell(request: BasketRequest) -> CrossSellResponse:
        try:
            return service.cross_sell_for(request)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except RuntimeError as exc:
            raise HTTPException(status_code=503, detail=str(exc)) from exc

    @app.get(
        "/up-sell/{item_id}",
        response_model=UpSellResponse,
        tags=["merchandising"],
        summary="Higher-priced substitutes for an anchor product",
    )
    def up_sell(
        item_id: str, n: int = Query(5, ge=1, le=max_n)
    ) -> UpSellResponse:
        try:
            return service.up_sell_for(item_id, n=n)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    @app.get(
        "/customer/{customer_id}",
        response_model=CustomerProfileResponse,
        tags=["customers"],
        summary="RFM segment, CLV and purchase history",
    )
    def customer(customer_id: int) -> CustomerProfileResponse:
        try:
            return service.customer_profile(customer_id)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc

    return app
