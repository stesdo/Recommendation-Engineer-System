"""Pydantic request/response schemas for the HTTP API.

Declaring the wire format explicitly buys three things at once: automatic input
validation with informative 422 responses, self-documenting OpenAPI output, and
a stable contract that decouples the storefront from the internals of the
engine.
"""

from __future__ import annotations

from typing import Dict, List, Optional

from pydantic import BaseModel, Field

__all__ = [
    "HealthResponse",
    "ItemOut",
    "RecommendationResponse",
    "BasketRequest",
    "CrossSellResponse",
    "UpSellResponse",
    "CustomerProfileResponse",
    "ModelInfo",
    "ModelsResponse",
]


class HealthResponse(BaseModel):
    status: str = Field(..., examples=["ok"])
    version: str
    models_loaded: List[str]
    n_users: int
    n_items: int
    serving_model: str


class ItemOut(BaseModel):
    rank: int = Field(..., ge=1, description="Position in the ranked list.")
    item_id: str = Field(..., description="Catalogue stock code.")
    description: str = Field("", description="Product description.")
    price: float = Field(0.0, ge=0.0, description="Mean observed unit price.")
    score: float = Field(..., description="Model affinity score.")
    reason: Optional[str] = Field(
        None, description="Human-readable justification for the recommendation."
    )


class RecommendationResponse(BaseModel):
    customer_id: int
    model: str
    n_returned: int
    items: List[ItemOut]
    segment: Optional[str] = Field(
        None, description="RFM segment of the customer, when available."
    )
    predicted_clv: Optional[float] = Field(
        None, description="Predicted 12-month customer lifetime value."
    )
    latency_ms: float


class BasketRequest(BaseModel):
    item_ids: List[str] = Field(
        ..., min_length=1, description="Stock codes currently in the basket."
    )
    n: int = Field(5, ge=1, le=50, description="Number of suggestions.")
    margin_weight: float = Field(
        0.3,
        ge=0.0,
        le=1.0,
        description=(
            "Trade-off between association strength (0.0) and gross margin (1.0)."
        ),
    )


class CrossSellResponse(BaseModel):
    basket: List[str]
    n_returned: int
    suggestions: List[ItemOut]
    total_expected_margin: float
    latency_ms: float


class UpSellResponse(BaseModel):
    anchor_item: str
    anchor_price: float
    n_returned: int
    suggestions: List[ItemOut]
    latency_ms: float


class CustomerProfileResponse(BaseModel):
    customer_id: int
    n_distinct_items: int
    n_orders: int
    total_spend: float
    segment: Optional[str] = None
    rfm_scores: Optional[Dict[str, float]] = None
    predicted_clv: Optional[float] = None
    probability_alive: Optional[float] = None
    top_purchased: List[ItemOut] = Field(default_factory=list)


class ModelInfo(BaseModel):
    name: str
    hyperparameters: Dict[str, str]
    fit_seconds: Optional[float] = None
    ndcg_at_10: Optional[float] = None
    coverage_at_10: Optional[float] = None
    supports_cold_start: bool = False


class ModelsResponse(BaseModel):
    serving_model: str
    primary_metric: str
    models: List[ModelInfo]
