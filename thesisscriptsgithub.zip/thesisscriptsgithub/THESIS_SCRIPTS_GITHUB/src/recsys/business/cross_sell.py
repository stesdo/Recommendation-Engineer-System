"""Cross-selling and up-selling engines.

The recommender models of :mod:`recsys.models` answer "what will this customer
buy next?". Merchandising asks two sharper questions, and this module answers
them explicitly.

**Cross-sell** — given the current basket, which *complementary* article should
be offered? The answer is derived from association-rule lift, restricted to
items not already in the basket, with an optional margin weighting so that the
engine prefers complements that are also profitable.

**Up-sell** — given the article a customer is viewing, which *substitute* at a
higher price point should be surfaced? Substitutability is approximated by
content similarity (products with similar descriptions are usually
interchangeable), constrained to a price band: an article twenty times more
expensive is not an up-sell, it is an insult.

The distinction matters commercially. Cross-selling grows basket size; up-selling
grows average unit value. They are optimised by different objectives, and a
system that conflates them will systematically under-perform on both.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np
import scipy.sparse as sp

from recsys.logging_utils import get_logger
from recsys.models.association_rules import AssociationRulesRecommender

logger = get_logger(__name__)

__all__ = ["CrossSellSuggestion", "CrossSellEngine", "UpSellEngine"]


@dataclass
class CrossSellSuggestion:
    """A single merchandising suggestion with its economic rationale."""

    item_idx: int
    score: float
    reason: str
    price: float = 0.0
    expected_margin: float = 0.0
    item_id: Optional[str] = None
    description: Optional[str] = None


class CrossSellEngine:
    """Suggest complements for a basket, ranked by lift × expected margin."""

    def __init__(
        self,
        rules_model: AssociationRulesRecommender,
        item_price: np.ndarray,
        gross_margin: float = 0.35,
        item_ids: Optional[np.ndarray] = None,
        descriptions: Optional[np.ndarray] = None,
    ) -> None:
        if not rules_model.is_fitted:
            raise RuntimeError("CrossSellEngine requires a fitted rules model.")
        self.rules = rules_model
        self.item_price = np.asarray(item_price, dtype=np.float64)
        self.gross_margin = float(gross_margin)
        self.item_ids = item_ids
        self.descriptions = descriptions

    def suggest(
        self,
        basket: Sequence[int],
        n: int = 5,
        margin_weight: float = 0.3,
    ) -> List[CrossSellSuggestion]:
        """Rank complements for the given basket.

        Parameters
        ----------
        basket:
            Item indices currently in the cart.
        n:
            Number of suggestions to return.
        margin_weight:
            Convex weight ``w`` blending association strength with expected
            margin: ``score = (1 − w)·lift_norm + w·margin_norm``. At ``w = 0``
            the engine maximises attach probability; at ``w = 1`` it maximises
            immediate profit and will happily suggest irrelevant expensive
            items. The default of 0.3 reflects the standard merchandising
            compromise.
        """
        basket = np.asarray(list(basket), dtype=np.int64)
        if basket.size == 0 or self.rules.rule_matrix_ is None:
            return []

        n_items = self.rules.rule_matrix_.shape[0]
        basket = basket[(basket >= 0) & (basket < n_items)]
        if basket.size == 0:
            return []

        # Aggregate lift from every basket item to every candidate consequent.
        indicator = sp.csr_matrix(
            (np.ones(basket.size), (np.zeros(basket.size), basket)),
            shape=(1, n_items),
        )
        lift = np.asarray((indicator @ self.rules.rule_matrix_).todense()).ravel()
        lift[basket] = 0.0                       # never suggest what is in the cart

        if not np.any(lift > 0):
            return []

        margin = self.item_price * self.gross_margin
        scores = (1.0 - margin_weight) * self._normalise(lift) + (
            margin_weight * self._normalise(np.where(lift > 0, margin, 0.0))
        )
        scores[lift <= 0] = 0.0                  # margin alone must not qualify

        top = np.argsort(-scores)[: max(n, 0)]
        suggestions: List[CrossSellSuggestion] = []
        for item_idx in top:
            if scores[item_idx] <= 0:
                continue
            anchor = self._strongest_anchor(basket, int(item_idx))
            suggestions.append(
                CrossSellSuggestion(
                    item_idx=int(item_idx),
                    score=float(scores[item_idx]),
                    reason=(
                        f"Frequently bought with item #{anchor} "
                        f"(lift {lift[item_idx]:.2f})"
                    ),
                    price=float(self.item_price[item_idx]),
                    expected_margin=float(margin[item_idx]),
                    item_id=self._item_id(int(item_idx)),
                    description=self._description(int(item_idx)),
                )
            )
        return suggestions

    def _strongest_anchor(self, basket: np.ndarray, consequent: int) -> int:
        assert self.rules.rule_matrix_ is not None
        column = self.rules.rule_matrix_[:, consequent]
        best, best_lift = int(basket[0]), 0.0
        for item in basket:
            value = float(column[item, 0])
            if value > best_lift:
                best, best_lift = int(item), value
        return best

    @staticmethod
    def _normalise(values: np.ndarray) -> np.ndarray:
        peak = float(np.max(values)) if values.size else 0.0
        return values / peak if peak > 0 else values

    def _item_id(self, idx: int) -> Optional[str]:
        return str(self.item_ids[idx]) if self.item_ids is not None else None

    def _description(self, idx: int) -> Optional[str]:
        return str(self.descriptions[idx]) if self.descriptions is not None else None


# ===========================================================================
class UpSellEngine:
    """Suggest higher-priced substitutes for an anchor article."""

    def __init__(
        self,
        content_features: sp.csr_matrix,
        item_price: np.ndarray,
        item_ids: Optional[np.ndarray] = None,
        descriptions: Optional[np.ndarray] = None,
    ) -> None:
        self.features = sp.csr_matrix(content_features, dtype=np.float32)
        self.item_price = np.asarray(item_price, dtype=np.float64)
        self.item_ids = item_ids
        self.descriptions = descriptions

    def suggest(
        self,
        anchor_item: int,
        n: int = 5,
        min_price_ratio: float = 1.15,
        max_price_ratio: float = 3.0,
        min_similarity: float = 0.05,
    ) -> List[CrossSellSuggestion]:
        """Rank substitutes for ``anchor_item`` inside a price corridor.

        The corridor is essential: an up-sell must be recognisably the *same
        kind of thing*, only better. Empirically, conversion collapses beyond
        roughly a 3× price step, which motivates the default upper bound.
        """
        if not 0 <= anchor_item < self.features.shape[0]:
            return []

        anchor_price = float(self.item_price[anchor_item])
        if anchor_price <= 0:
            return []

        similarity = np.asarray(
            (self.features[anchor_item] @ self.features.T).todense()
        ).ravel()
        similarity[anchor_item] = 0.0

        price_ratio = self.item_price / anchor_price
        eligible = (
            (price_ratio >= min_price_ratio)
            & (price_ratio <= max_price_ratio)
            & (similarity >= min_similarity)
        )
        if not np.any(eligible):
            return []

        # Rank by similarity, mildly rewarding the additional revenue captured.
        uplift = np.clip((price_ratio - 1.0) / max(max_price_ratio - 1.0, 1e-9), 0, 1)
        scores = np.where(eligible, 0.75 * similarity + 0.25 * uplift, 0.0)

        top = np.argsort(-scores)[: max(n, 0)]
        return [
            CrossSellSuggestion(
                item_idx=int(i),
                score=float(scores[i]),
                reason=(
                    f"Premium alternative — {price_ratio[i]:.1f}× the price, "
                    f"similarity {similarity[i]:.2f}"
                ),
                price=float(self.item_price[i]),
                expected_margin=float(self.item_price[i] - anchor_price),
                item_id=str(self.item_ids[i]) if self.item_ids is not None else None,
                description=(
                    str(self.descriptions[i]) if self.descriptions is not None else None
                ),
            )
            for i in top
            if scores[i] > 0
        ]
