"""Deployment uplift and revenue simulation.

Offline accuracy is a *proxy*. Management does not fund NDCG; it funds revenue.
This module bridges the two by making the bridging assumptions explicit and
auditable, which is methodologically preferable to the common alternative of
quoting an accuracy improvement and letting the reader imagine its commercial
consequence.

The model is a four-stage funnel:

.. code-block:: text

    impressions → clicks → purchases → revenue → margin

with

.. math::

    \\mathrm{CTR}_{\\text{model}} = \\mathrm{CTR}_{\\text{base}}
        \\cdot \\bigl(1 + \\varepsilon \\cdot \\Delta_{\\mathrm{rel}}\\mathrm{NDCG}\\bigr),

where :math:`\\varepsilon` is the *elasticity* of click-through with respect to
relative NDCG improvement. Setting ε is the single judgemental input; the
default of 1.8 is taken from the mid-range of published online/offline
correlation studies. Because the whole result scales monotonically in ε, the
module also reports a **sensitivity analysis** across a range of ε values, so
the conclusion never rests on one unverifiable constant.

A limitation must be stated plainly, and is discussed in thesis §7.5: no offline
simulation can substitute for an A/B test. What this module delivers is a
transparent, parameterised order-of-magnitude estimate — not a measurement.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from recsys.config import BusinessConfig
from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = ["UpliftScenario", "SimulationResult", "RevenueSimulator"]


@dataclass
class UpliftScenario:
    """Funnel outcome for a single model under a given elasticity."""

    model_name: str
    ndcg: float
    ndcg_lift_pct: float
    ctr: float
    clicks: float
    purchases: float
    revenue: float
    margin: float
    revenue_uplift_vs_baseline: float
    revenue_uplift_pct: float


@dataclass
class SimulationResult:
    scenarios: List[UpliftScenario] = field(default_factory=list)
    sensitivity: Optional[pd.DataFrame] = None
    assumptions: Dict[str, float] = field(default_factory=dict)

    def to_frame(self) -> pd.DataFrame:
        return pd.DataFrame(
            [
                {
                    "model": s.model_name,
                    "ndcg@10": s.ndcg,
                    "ndcg_lift_%": s.ndcg_lift_pct,
                    "ctr_%": 100.0 * s.ctr,
                    "clicks": s.clicks,
                    "purchases": s.purchases,
                    "revenue": s.revenue,
                    "margin": s.margin,
                    "revenue_uplift": s.revenue_uplift_vs_baseline,
                    "revenue_uplift_%": s.revenue_uplift_pct,
                }
                for s in self.scenarios
            ]
        )

    def best(self) -> Optional[UpliftScenario]:
        return max(self.scenarios, key=lambda s: s.revenue) if self.scenarios else None


class RevenueSimulator:
    """Translate accuracy differences into a funnel-based revenue estimate."""

    def __init__(self, cfg: BusinessConfig, average_order_value: float) -> None:
        self.cfg = cfg
        self.aov = float(average_order_value)

    def simulate(
        self,
        model_scores: Dict[str, float],
        baseline_model: str = "popularity",
        elasticity: Optional[float] = None,
    ) -> SimulationResult:
        """Run the funnel for every model, relative to ``baseline_model``.

        Parameters
        ----------
        model_scores:
            ``{model_name → NDCG@k}`` — the accuracy of each candidate system.
        baseline_model:
            The incumbent whose revenue defines the zero point. Defaults to the
            non-personalized popularity ranker, which is the honest counterfactual
            for "what we would do without a recommender".
        elasticity:
            Override for ``business.ctr_lift_per_ndcg_point``.
        """
        cfg = self.cfg
        eps = float(elasticity if elasticity is not None else cfg.ctr_lift_per_ndcg_point)

        if not model_scores:
            return SimulationResult([], None, {})

        baseline_ndcg = model_scores.get(
            baseline_model, min(model_scores.values())
        )
        if baseline_ndcg <= 0:
            baseline_ndcg = max(min(model_scores.values()), 1e-6)

        baseline_revenue = self._funnel(cfg.baseline_ctr)["revenue"]

        scenarios: List[UpliftScenario] = []
        for name, ndcg in sorted(model_scores.items(), key=lambda kv: -kv[1]):
            relative_lift = (ndcg - baseline_ndcg) / baseline_ndcg
            ctr = cfg.baseline_ctr * (1.0 + eps * relative_lift)
            ctr = float(np.clip(ctr, 0.0, 1.0))

            funnel = self._funnel(ctr)
            uplift = funnel["revenue"] - baseline_revenue
            scenarios.append(
                UpliftScenario(
                    model_name=name,
                    ndcg=float(ndcg),
                    ndcg_lift_pct=100.0 * relative_lift,
                    ctr=ctr,
                    clicks=funnel["clicks"],
                    purchases=funnel["purchases"],
                    revenue=funnel["revenue"],
                    margin=funnel["margin"],
                    revenue_uplift_vs_baseline=uplift,
                    revenue_uplift_pct=(
                        100.0 * uplift / baseline_revenue if baseline_revenue else 0.0
                    ),
                )
            )

        sensitivity = self._sensitivity(model_scores, baseline_ndcg, baseline_revenue)

        assumptions = {
            "impressions": float(cfg.simulation_impressions),
            "baseline_ctr": cfg.baseline_ctr,
            "attach_rate": cfg.attach_rate,
            "average_order_value": self.aov,
            "gross_margin": cfg.gross_margin,
            "elasticity": eps,
        }
        logger.info(
            "  uplift simulation — %d impressions, baseline CTR %.2f%%, "
            "attach %.1f%%, AOV £%.2f, ε=%.2f.",
            cfg.simulation_impressions,
            100 * cfg.baseline_ctr,
            100 * cfg.attach_rate,
            self.aov,
            eps,
        )
        best = max(scenarios, key=lambda s: s.revenue)
        logger.info(
            "  best scenario: '%s' → revenue £%.0f (%+.1f%% vs %s).",
            best.model_name,
            best.revenue,
            best.revenue_uplift_pct,
            baseline_model,
        )
        return SimulationResult(scenarios, sensitivity, assumptions)

    # ------------------------------------------------------------------ funnel
    def _funnel(self, ctr: float) -> Dict[str, float]:
        cfg = self.cfg
        impressions = float(cfg.simulation_impressions)
        clicks = impressions * ctr
        purchases = clicks * cfg.attach_rate
        revenue = purchases * self.aov
        return {
            "impressions": impressions,
            "clicks": clicks,
            "purchases": purchases,
            "revenue": revenue,
            "margin": revenue * cfg.gross_margin,
        }

    def _sensitivity(
        self,
        model_scores: Dict[str, float],
        baseline_ndcg: float,
        baseline_revenue: float,
    ) -> pd.DataFrame:
        """Revenue uplift of each model across a grid of elasticity values.

        Reporting this grid is what allows the reader to discount the headline
        figure appropriately: if the qualitative conclusion (personalization
        pays) holds for ε = 0.5 as well as ε = 3.0, the conclusion is robust to
        the one assumption the analysis cannot verify offline.
        """
        grid = [0.5, 1.0, 1.5, 1.8, 2.5, 3.0]
        rows = []
        for eps in grid:
            row: Dict[str, float] = {"elasticity": eps}
            for name, ndcg in model_scores.items():
                relative = (ndcg - baseline_ndcg) / baseline_ndcg
                ctr = float(np.clip(self.cfg.baseline_ctr * (1.0 + eps * relative), 0, 1))
                revenue = self._funnel(ctr)["revenue"]
                row[name] = (
                    100.0 * (revenue - baseline_revenue) / baseline_revenue
                    if baseline_revenue
                    else 0.0
                )
            rows.append(row)
        return pd.DataFrame(rows).set_index("elasticity").round(2)


def coverage_revenue_analysis(
    item_revenue: np.ndarray, item_popularity: np.ndarray, exposure: np.ndarray
) -> pd.DataFrame:
    """Relate catalogue exposure to historical revenue by popularity tercile.

    This diagnostic answers the long-tail question quantitatively: does the
    recommender surface articles that historically generated revenue but receive
    little organic traffic? A system that only exposes the head is leaving the
    tail's revenue unaddressed.
    """
    order = np.argsort(-item_popularity)
    n = order.size
    if n == 0:
        return pd.DataFrame()

    thirds = np.array_split(order, 3)
    labels = ["head (top 33%)", "torso (middle 33%)", "tail (bottom 33%)"]
    total_revenue = float(item_revenue.sum()) or 1.0
    total_exposure = float(exposure.sum()) or 1.0

    rows = []
    for label, group in zip(labels, thirds):
        rows.append(
            {
                "segment": label,
                "items": int(group.size),
                "revenue_share_pct": 100.0 * float(item_revenue[group].sum()) / total_revenue,
                "exposure_share_pct": 100.0 * float(exposure[group].sum()) / total_exposure,
                "items_exposed": int((exposure[group] > 0).sum()),
                "exposure_rate_pct": 100.0 * float((exposure[group] > 0).mean()),
            }
        )
    return pd.DataFrame(rows)
