"""Customer Lifetime Value under a non-contractual purchasing regime.

E-retail is a *non-contractual* setting: customers do not announce their
departure, so "churn" is latent and must be inferred. The standard apparatus is
the pair of models below, which together decompose expected future value into a
transaction-count component and a monetary component.

BG/NBD — Beta-Geometric / Negative Binomial Distribution
--------------------------------------------------------
Fader, Hardie and Lee (2005) model each customer with two latent parameters:

* a Poisson purchase rate :math:`\\lambda \\sim \\mathrm{Gamma}(r, \\alpha)`;
* a per-transaction "death" probability :math:`p \\sim \\mathrm{Beta}(a, b)`,
  where after each purchase the customer becomes inactive with probability p.

Marginalising over the population heterogeneity yields a closed-form likelihood
in the sufficient statistics :math:`(x, t_x, T)` — frequency, recency and
observation period — and consequently a closed-form expectation for the number
of transactions in a future window.

Gamma–Gamma monetary model
--------------------------
Fader, Hardie and Lee (2005b) model the average transaction value with a
Gamma distribution whose scale itself varies across customers according to a
Gamma. The crucial assumption — empirically testable and checked in Chapter 7 —
is that monetary value is independent of purchase frequency.

CLV
---
Combining the two components and discounting at rate d:

.. math::

    \\mathrm{CLV} = \\sum_{t=1}^{H} \\frac{E[X_t] \\cdot E[M] \\cdot m}{(1 + d)^{t}}

with ``m`` the gross margin and ``H`` the horizon in periods.

Estimation uses maximum likelihood via Nelder–Mead, which is derivative-free and
robust to the flat regions the BG/NBD likelihood exhibits when the data are
sparse. A closed-form heuristic fallback is provided when optimisation fails, so
the pipeline never aborts on a degenerate customer cohort.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import betaln, gammaln, hyp2f1

from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = ["BGNBDModel", "GammaGammaModel", "CLVCalculator", "CLVResult"]


@dataclass
class CLVResult:
    """Per-customer CLV table plus fitted model parameters."""

    table: pd.DataFrame
    bgnbd_params: Dict[str, float]
    gamma_params: Dict[str, float]
    horizon_days: int
    discount_rate: float
    gross_margin: float

    def top_customers(self, n: int = 20) -> pd.DataFrame:
        return self.table.nlargest(n, "clv")

    def total_clv(self) -> float:
        return float(self.table["clv"].sum())

    def decile_summary(self) -> pd.DataFrame:
        """Concentration of predicted value across customer deciles."""
        df = self.table.copy()
        df["decile"] = pd.qcut(
            df["clv"].rank(method="first"), 10, labels=range(10, 0, -1)
        )
        summary = df.groupby("decile", observed=True).agg(
            customers=("clv", "size"),
            total_clv=("clv", "sum"),
            mean_clv=("clv", "mean"),
            mean_frequency=("frequency", "mean"),
            mean_monetary=("monetary_value", "mean"),
        )
        total = summary["total_clv"].sum()
        summary["clv_share_pct"] = 100.0 * summary["total_clv"] / total if total else 0.0
        return summary


# ===========================================================================
class BGNBDModel:
    """Beta-Geometric / NBD model of repeat-purchase behaviour."""

    def __init__(self) -> None:
        self.r: float = 1.0        # Gamma shape for purchase rate
        self.alpha: float = 1.0    # Gamma scale for purchase rate
        self.a: float = 1.0        # Beta shape for dropout
        self.b: float = 1.0        # Beta shape for dropout
        self.is_fitted: bool = False
        self.log_likelihood_: float = float("nan")

    # ------------------------------------------------------------------- fit
    def fit(
        self,
        frequency: np.ndarray,
        recency: np.ndarray,
        T: np.ndarray,
    ) -> "BGNBDModel":
        """Maximum-likelihood estimation of (r, α, a, b).

        Parameters
        ----------
        frequency:
            Number of *repeat* purchases (x). A customer with a single purchase
            has x = 0.
        recency:
            Age of the customer at their last purchase (t_x), in days.
        T:
            Total observation period (days since first purchase).
        """
        x = np.asarray(frequency, dtype=np.float64)
        t_x = np.asarray(recency, dtype=np.float64)
        T_ = np.asarray(T, dtype=np.float64)

        valid = (T_ > 0) & (t_x >= 0) & (x >= 0) & (t_x <= T_)
        x, t_x, T_ = x[valid], t_x[valid], T_[valid]
        if x.size < 10:
            logger.warning(
                "Only %d valid customers for BG/NBD; using heuristic parameters.",
                x.size,
            )
            self._heuristic(x, T_)
            return self

        def unpack(params: np.ndarray) -> tuple[float, float, float, float]:
            """Map unconstrained parameters onto the admissible region.

            All four parameters are obtained by exponentiation, which enforces
            exactly the region Fader, Hardie and Lee (2005a) require:
            ``r, α, a, b > 0``. In particular ``a`` is **not** restricted to
            ``a > 1``. The conditional expectation of §eq. 10 contains the
            factor ``(a + b + x − 1)/(a − 1)``, which is negative for ``a < 1``
            — but so is the bracketed survival term ``1 − (·)^(r+x)·₂F₁``,
            because ``c = a + b + x − 1 < b + x`` forces the hypergeometric
            function above ``(1 − z)^-(r+x)``. The quotient is therefore
            positive throughout ``0 < a < 1``, and restricting the optimiser to
            ``a > 1`` merely truncates the likelihood surface: FHL's own CDNOW
            estimate is ``a = 0.793 < 1``.
            """
            r, alpha, a, b = np.exp(params)
            return r, alpha, a, b

        def negative_log_likelihood(params: np.ndarray) -> float:
            r, alpha, a, b = unpack(params)
            if not np.all(np.isfinite([r, alpha, a, b])):
                return 1e10
            try:
                ll = self._log_likelihood(x, t_x, T_, r, alpha, a, b)
                return -ll if np.isfinite(ll) else 1e10
            except (FloatingPointError, ValueError):  # pragma: no cover
                return 1e10

        best: Optional[np.ndarray] = None
        best_value = np.inf
        # Multi-start: the BG/NBD likelihood surface has flat regions where a
        # single start can stall far from the optimum.
        for start in ([0.0, 0.0, 0.0, 0.0], [0.5, 2.0, 0.5, 1.0], [-0.5, 1.0, -0.5, 0.5]):
            try:
                result = minimize(
                    negative_log_likelihood,
                    np.array(start, dtype=np.float64),
                    method="Nelder-Mead",
                    options={"maxiter": 3000, "xatol": 1e-6, "fatol": 1e-6},
                )
                if result.fun < best_value:
                    best_value, best = float(result.fun), result.x
            except Exception:  # pragma: no cover
                continue

        if best is None or not np.isfinite(best_value) or best_value >= 1e9:
            logger.warning("BG/NBD optimisation failed; using heuristic parameters.")
            self._heuristic(x, T_)
            return self

        self.r, self.alpha, self.a, self.b = (float(v) for v in unpack(best))
        self.log_likelihood_ = -best_value
        self.is_fitted = True
        logger.info(
            "  BG/NBD fitted: r=%.4f α=%.4f a=%.4f b=%.4f (LL=%.2f, n=%d).",
            self.r, self.alpha, self.a, self.b, self.log_likelihood_, x.size,
        )
        return self

    def _heuristic(self, x: np.ndarray, T: np.ndarray) -> None:
        """Method-of-moments fallback when MLE is unavailable.

        ``a`` is set strictly above one for the reason documented in ``unpack``.
        """
        mean_x = float(np.mean(x)) if x.size else 0.5
        mean_T = float(np.mean(T)) if T.size else 365.0
        self.r, self.alpha = 1.0, max(mean_T / max(mean_x + 0.5, 0.5), 1.0)
        self.a, self.b = 1.5, 2.0
        self.is_fitted = True

    @staticmethod
    def _log_likelihood(
        x: np.ndarray,
        t_x: np.ndarray,
        T: np.ndarray,
        r: float,
        alpha: float,
        a: float,
        b: float,
    ) -> float:
        """Individual-level BG/NBD log-likelihood, summed over customers."""
        ln_A1 = gammaln(r + x) - gammaln(r) + r * np.log(alpha)
        ln_A2 = betaln(a, b + x) - betaln(a, b)
        ln_A3 = -(r + x) * np.log(alpha + T)

        # The fourth term only applies to customers with at least one repeat.
        ln_A4 = np.full_like(x, -np.inf, dtype=np.float64)
        active = x > 0
        if np.any(active):
            ln_A4[active] = (
                betaln(a + 1.0, b + x[active] - 1.0)
                - betaln(a, b)
                - (r + x[active]) * np.log(alpha + t_x[active])
            )

        # log-sum-exp of (A2 + A3) and A4, both already on the log scale.
        term_1 = ln_A2 + ln_A3
        stacked = np.vstack([term_1, ln_A4])
        max_term = np.max(stacked, axis=0)
        finite = np.isfinite(max_term)
        log_sum = np.full_like(max_term, -np.inf)
        log_sum[finite] = max_term[finite] + np.log(
            np.sum(np.exp(stacked[:, finite] - max_term[finite]), axis=0)
        )
        return float(np.sum(ln_A1 + log_sum))

    # -------------------------------------------------------------- predict
    def expected_transactions(
        self,
        t: float,
        frequency: np.ndarray,
        recency: np.ndarray,
        T: np.ndarray,
    ) -> np.ndarray:
        """E[X(T, T + t) | x, t_x, T] — expected purchases in the next ``t`` days."""
        if not self.is_fitted:
            raise RuntimeError("BGNBDModel must be fitted before prediction.")
        r, alpha, a, b = self.r, self.alpha, self.a, self.b
        x = np.asarray(frequency, dtype=np.float64)
        t_x = np.asarray(recency, dtype=np.float64)
        T_ = np.asarray(T, dtype=np.float64)

        # Equation 10 has a removable singularity at exactly a = 1, where both
        # (a - 1) and the survival bracket vanish. That point has measure zero
        # under a continuous MLE; if the optimiser lands on it we displace it by
        # the smallest amount that keeps the ratio finite, and say so, rather
        # than silently substituting a different model.
        if abs(a - 1.0) < 1e-9:
            logger.warning(
                "BG/NBD dropout shape a = %.12f is numerically indistinguishable "
                "from 1, where equation 10 is 0/0; displacing by 1e-9 for "
                "prediction only.",
                a,
            )
            a = 1.0 + 1e-9 if a >= 1.0 else 1.0 - 1e-9

        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            # First factor: (a + b + x − 1) / (a − 1)
            scale = (a + b + x - 1.0) / (a - 1.0)

            # Second factor: 1 − [(α+T)/(α+T+t)]^(r+x) · ₂F₁(r+x, b+x; a+b+x−1; z)
            z = t / (alpha + T_ + t)
            decay = ((alpha + T_) / (alpha + T_ + t)) ** (r + x)
            gauss = hyp2f1(r + x, b + x, a + b + x - 1.0, z)
            survival = 1.0 - decay * gauss

            numerator = scale * survival

            # Divide by the odds that the customer is already inactive.
            denominator = 1.0 + np.where(
                x > 0,
                (a / np.maximum(b + x - 1.0, 1e-10))
                * ((alpha + T_) / (alpha + t_x)) ** (r + x),
                0.0,
            )
            expected = numerator / denominator

        return np.nan_to_num(np.maximum(expected, 0.0), nan=0.0, posinf=0.0)

    def probability_alive(
        self, frequency: np.ndarray, recency: np.ndarray, T: np.ndarray
    ) -> np.ndarray:
        """P(alive | x, t_x, T) — the latent-churn posterior."""
        if not self.is_fitted:
            raise RuntimeError("BGNBDModel must be fitted before prediction.")
        r, alpha, a, b = self.r, self.alpha, self.a, self.b
        x = np.asarray(frequency, dtype=np.float64)
        t_x = np.asarray(recency, dtype=np.float64)
        T_ = np.asarray(T, dtype=np.float64)

        with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
            ratio = np.where(
                x > 0,
                (a / np.maximum(b + x - 1.0, 1e-10))
                * ((alpha + T_) / (alpha + t_x)) ** (r + x),
                0.0,
            )
            p_alive = 1.0 / (1.0 + ratio)
        return np.clip(np.nan_to_num(p_alive, nan=1.0), 0.0, 1.0)


# ===========================================================================
class GammaGammaModel:
    """Gamma–Gamma model of monetary value per transaction."""

    def __init__(self) -> None:
        self.p: float = 1.0
        self.q: float = 1.0
        self.v: float = 1.0
        self.is_fitted: bool = False

    def fit(self, frequency: np.ndarray, monetary_value: np.ndarray) -> "GammaGammaModel":
        x = np.asarray(frequency, dtype=np.float64)
        m = np.asarray(monetary_value, dtype=np.float64)
        valid = (x > 0) & (m > 0) & np.isfinite(m)
        x, m = x[valid], m[valid]

        if x.size < 10:
            logger.warning("Insufficient data for Gamma–Gamma; using moment estimates.")
            self._heuristic(m)
            return self

        def negative_log_likelihood(params: np.ndarray) -> float:
            p, q, v = np.exp(params)
            if not np.all(np.isfinite([p, q, v])):
                return 1e10
            try:
                ll = np.sum(
                    gammaln(p * x + q)
                    - gammaln(p * x)
                    - gammaln(q)
                    + q * np.log(v)
                    + (p * x - 1.0) * np.log(m)
                    + (p * x) * np.log(x)
                    - (p * x + q) * np.log(v + x * m)
                )
                return -ll if np.isfinite(ll) else 1e10
            except (FloatingPointError, ValueError):  # pragma: no cover
                return 1e10

        try:
            result = minimize(
                negative_log_likelihood,
                np.array([0.0, 0.0, np.log(max(np.mean(m), 1.0))]),
                method="Nelder-Mead",
                options={"maxiter": 3000},
            )
            # The objective returns 1e10 as its failure sentinel, which *is*
            # finite — testing ``np.isfinite(result.fun)`` would therefore
            # accept a total optimiser failure as a successful fit. Guard on the
            # sentinel magnitude instead, matching the BG/NBD branch.
            if result.fun < 1e9:
                self.p, self.q, self.v = (float(z) for z in np.exp(result.x))
                self.is_fitted = True
                logger.info(
                    "  Gamma–Gamma fitted: p=%.4f q=%.4f v=%.4f (n=%d).",
                    self.p, self.q, self.v, x.size,
                )
                return self
        except Exception:  # pragma: no cover
            pass

        logger.warning("Gamma–Gamma optimisation failed; using moment estimates.")
        self._heuristic(m)
        return self

    def _heuristic(self, m: np.ndarray) -> None:
        mean_m = float(np.mean(m)) if m.size else 1.0
        self.p, self.q, self.v = 2.0, 3.0, max(mean_m * 2.0, 1.0)
        self.is_fitted = True

    def conditional_expected_average_value(
        self, frequency: np.ndarray, monetary_value: np.ndarray
    ) -> np.ndarray:
        """E[M | x, m̄] — the shrinkage estimator of average transaction value.

        The estimate is a precision-weighted blend of the customer's observed
        average and the population mean, so a customer with a single expensive
        order is not credited with a permanently high value.
        """
        if not self.is_fitted:
            raise RuntimeError("GammaGammaModel must be fitted before prediction.")
        x = np.asarray(frequency, dtype=np.float64)
        m = np.asarray(monetary_value, dtype=np.float64)
        p, q, v = self.p, self.q, self.v

        with np.errstate(invalid="ignore", divide="ignore"):
            population_mean = (p * v) / max(q - 1.0, 1e-10)
            individual_weight = (p * x) / (p * x + q - 1.0)
            expected = individual_weight * m + (1.0 - individual_weight) * population_mean
        return np.nan_to_num(np.maximum(expected, 0.0), nan=0.0)


# ===========================================================================
class CLVCalculator:
    """Assemble the transaction and monetary components into a CLV forecast."""

    def __init__(
        self,
        horizon_days: int = 365,
        discount_rate: float = 0.10,
        gross_margin: float = 0.35,
    ) -> None:
        self.horizon_days = int(horizon_days)
        self.discount_rate = float(discount_rate)
        self.gross_margin = float(gross_margin)
        self.bgnbd = BGNBDModel()
        self.gamma = GammaGammaModel()

    def compute(self, frame: pd.DataFrame) -> CLVResult:
        """Fit both sub-models and produce the per-customer CLV table."""
        summary = self._rfm_matrix(frame)

        self.bgnbd.fit(
            summary["frequency"].to_numpy(),
            summary["recency"].to_numpy(),
            summary["T"].to_numpy(),
        )
        self.gamma.fit(
            summary["frequency"].to_numpy(),
            summary["monetary_value"].to_numpy(),
        )

        summary["predicted_transactions"] = self.bgnbd.expected_transactions(
            float(self.horizon_days),
            summary["frequency"].to_numpy(),
            summary["recency"].to_numpy(),
            summary["T"].to_numpy(),
        )
        summary["probability_alive"] = self.bgnbd.probability_alive(
            summary["frequency"].to_numpy(),
            summary["recency"].to_numpy(),
            summary["T"].to_numpy(),
        )
        summary["expected_avg_value"] = self.gamma.conditional_expected_average_value(
            summary["frequency"].to_numpy(),
            summary["monetary_value"].to_numpy(),
        )

        # Monthly discounting over the horizon.
        n_periods = max(int(round(self.horizon_days / 30.0)), 1)
        monthly_rate = (1.0 + self.discount_rate) ** (1.0 / 12.0) - 1.0
        discount = np.sum(
            [1.0 / (1.0 + monthly_rate) ** t for t in range(1, n_periods + 1)]
        ) / n_periods

        summary["clv"] = (
            summary["predicted_transactions"]
            * summary["expected_avg_value"]
            * self.gross_margin
            * discount
        )
        summary["clv"] = summary["clv"].clip(lower=0.0)

        logger.info(
            "  CLV computed for %d customers — total £%.0f, mean £%.2f, "
            "median £%.2f (horizon %d d, margin %.0f%%).",
            len(summary),
            float(summary["clv"].sum()),
            float(summary["clv"].mean()),
            float(summary["clv"].median()),
            self.horizon_days,
            100 * self.gross_margin,
        )

        return CLVResult(
            table=summary,
            bgnbd_params={
                "r": self.bgnbd.r, "alpha": self.bgnbd.alpha,
                "a": self.bgnbd.a, "b": self.bgnbd.b,
                "log_likelihood": self.bgnbd.log_likelihood_,
            },
            gamma_params={"p": self.gamma.p, "q": self.gamma.q, "v": self.gamma.v},
            horizon_days=self.horizon_days,
            discount_rate=self.discount_rate,
            gross_margin=self.gross_margin,
        )

    @staticmethod
    def _rfm_matrix(frame: pd.DataFrame) -> pd.DataFrame:
        """Build the (frequency, recency, T, monetary_value) sufficient statistics."""
        observation_end = frame["invoice_date"].max()

        orders = (
            frame.groupby(["customer_id", "invoice"])
            .agg(order_date=("invoice_date", "min"), order_value=("revenue", "sum"))
            .reset_index()
            .sort_values(["customer_id", "order_date"], kind="mergesort")
        )
        summary = (
            orders.groupby("customer_id")
            .agg(
                n_orders=("invoice", "nunique"),
                first_order=("order_date", "min"),
                last_order=("order_date", "max"),
                total_value=("order_value", "sum"),
                # ``orders`` is sorted by date within each customer, so "first"
                # is the value of the initial purchase.
                first_order_value=("order_value", "first"),
            )
        )
        # BG/NBD convention: frequency counts *repeat* purchases.
        summary["frequency"] = (summary["n_orders"] - 1).clip(lower=0).astype(float)
        summary["recency"] = (
            summary["last_order"] - summary["first_order"]
        ).dt.days.astype(float)
        summary["T"] = (
            observation_end - summary["first_order"]
        ).dt.days.astype(float).clip(lower=1.0)

        # Monetary value is the mean value of the *repeat* orders, which is the
        # statistic the Gamma-Gamma likelihood and its shrinkage estimator both
        # assume: they treat m̄ as the average of exactly ``x`` draws, where
        # ``x = frequency`` counts repeat orders. Dividing the lifetime total by
        # all ``x + 1`` orders would mix in the first purchase, pull every
        # customer's mean toward the grand mean, and suppress the cross-customer
        # dispersion the model reads as within-customer precision.
        repeat_orders = summary["n_orders"] - 1
        repeat_total = summary["total_value"] - summary["first_order_value"]
        summary["monetary_value"] = np.where(
            repeat_orders > 0,
            repeat_total / repeat_orders.where(repeat_orders > 0, 1),
            0.0,
        )
        summary["monetary_value"] = summary["monetary_value"].clip(lower=0.0)
        return summary
