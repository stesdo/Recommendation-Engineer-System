"""Business-value layer: CLV, merchandising engines and revenue simulation."""

from __future__ import annotations

from recsys.business.clv import (
    BGNBDModel,
    CLVCalculator,
    CLVResult,
    GammaGammaModel,
)
from recsys.business.cross_sell import (
    CrossSellEngine,
    CrossSellSuggestion,
    UpSellEngine,
)
from recsys.business.simulation import (
    RevenueSimulator,
    SimulationResult,
    UpliftScenario,
    coverage_revenue_analysis,
)

__all__ = [
    "BGNBDModel",
    "GammaGammaModel",
    "CLVCalculator",
    "CLVResult",
    "CrossSellEngine",
    "UpSellEngine",
    "CrossSellSuggestion",
    "RevenueSimulator",
    "SimulationResult",
    "UpliftScenario",
    "coverage_revenue_analysis",
]
