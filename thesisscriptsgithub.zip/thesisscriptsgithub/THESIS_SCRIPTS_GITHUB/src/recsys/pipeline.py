"""End-to-end experiment orchestration.

The pipeline is the executable specification of the empirical chapters. Running
``python -m recsys.cli run`` reproduces every number, table and figure reported
in Chapters 5–7, in the following order:

1. **Acquisition** — obtain the transaction log (download, cache or surrogate).
2. **Cleaning** — apply the auditable filtering protocol; emit the attrition table.
3. **Description** — compute the descriptive statistics and long-tail diagnostics.
4. **Partitioning** — construct the temporally consistent train/val/test split.
5. **Feature construction** — interaction matrices, RFM, TF-IDF content.
6. **Model estimation** — fit every enabled algorithm, recording wall-clock cost.
7. **Hybridisation** — assemble the meta-recommender over the fitted components.
8. **Evaluation** — full-catalogue ranking, 15 metrics, 3 cut-offs.
9. **Inference** — Wilcoxon tests, bootstrap intervals, Holm correction.
10. **Business analysis** — CLV, merchandising exemplars, uplift simulation.
11. **Persistence** — write every artefact to ``artifacts/<run_id>/``.

Each stage is individually timed and each artefact is written to disk, so a
failure in a late stage never destroys the results of the earlier ones.
"""

from __future__ import annotations

import json
import platform
import sys
import time
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np
import pandas as pd

from recsys.business.clv import CLVCalculator, CLVResult
from recsys.business.cross_sell import CrossSellEngine, UpSellEngine
from recsys.business.simulation import (
    RevenueSimulator,
    SimulationResult,
    coverage_revenue_analysis,
)
from recsys.config import Config
from recsys.data.loader import DataLoader
from recsys.data.preprocessing import (
    TransactionCleaner,
    compute_dataset_statistics,
)
from recsys.data.splitting import DataSplit, TemporalSplitter
from recsys.evaluation.evaluator import EvaluationResult, Evaluator, results_to_frame
from recsys.evaluation.statistics import (
    StatisticalReport,
    average_ranks,
    compare_models,
    significance_matrix,
)
from recsys.features.content import ContentFeatureBuilder, ContentFeatures
from recsys.features.interactions import InteractionBuilder, InteractionData
from recsys.features.rfm import RFMResult, compute_rfm
from recsys.logging_utils import TIMINGS, get_logger, timed
from recsys.models import (
    FitContext,
    HybridRecommender,
    Recommender,
    build_model,
)

logger = get_logger(__name__)

__all__ = ["PipelineArtifacts", "Pipeline"]


@dataclass
class PipelineArtifacts:
    """Every object produced by a run, retained for inspection and serving."""

    run_id: str
    output_dir: Path
    raw_source: str = ""
    clean_frame: Optional[pd.DataFrame] = None
    dataset_stats: Dict[str, float] = field(default_factory=dict)
    cleaning_report: Optional[pd.DataFrame] = None
    split: Optional[DataSplit] = None
    interactions: Optional[InteractionData] = None
    content: Optional[ContentFeatures] = None
    rfm: Optional[RFMResult] = None
    models: Dict[str, Recommender] = field(default_factory=dict)
    fit_seconds: Dict[str, float] = field(default_factory=dict)
    results: Dict[str, EvaluationResult] = field(default_factory=dict)
    results_frame: Optional[pd.DataFrame] = None
    statistical_report: Optional[StatisticalReport] = None
    clv: Optional[CLVResult] = None
    simulation: Optional[SimulationResult] = None
    cross_sell_examples: Optional[pd.DataFrame] = None
    up_sell_examples: Optional[pd.DataFrame] = None
    long_tail_analysis: Optional[pd.DataFrame] = None
    timings: Dict[str, float] = field(default_factory=dict)

    def best_model_name(self, metric: str = "ndcg@10") -> Optional[str]:
        if not self.results:
            return None
        scored = {
            name: r.get(metric)
            for name, r in self.results.items()
            if np.isfinite(r.get(metric))
        }
        return max(scored, key=scored.get) if scored else None


class Pipeline:
    """Execute the full experimental protocol."""

    def __init__(self, cfg: Config, project_root: Optional[Path] = None) -> None:
        self.cfg = cfg
        self.root = Path(project_root) if project_root else Path.cwd()
        self.run_id = f"{cfg.experiment.name}_{datetime.now():%Y%m%d_%H%M%S}"
        self.output_dir = self.root / cfg.experiment.artifacts_dir / self.run_id
        self.artifacts = PipelineArtifacts(run_id=self.run_id, output_dir=self.output_dir)
        self._seed_everything(cfg.experiment.random_seed)

    @staticmethod
    def _seed_everything(seed: int) -> None:
        """Fix every source of randomness the pipeline touches."""
        import random

        random.seed(seed)
        np.random.seed(seed)

    # ======================================================================
    def run(self) -> PipelineArtifacts:
        """Execute all stages and return the collected artefacts."""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        start = time.perf_counter()

        logger.info("=" * 78)
        logger.info("RUN %s", self.run_id)
        logger.info("=" * 78)
        self._write_environment()
        self.cfg.snapshot(self.output_dir / "config.snapshot.yaml")

        with timed("01_data_acquisition", logger):
            frame = self._stage_acquire()
        with timed("02_cleaning", logger):
            clean = self._stage_clean(frame)
        with timed("03_description", logger):
            self._stage_describe(clean)
        with timed("04_splitting", logger):
            split = self._stage_split(clean)
        with timed("05_features", logger):
            interactions, content = self._stage_features(split)
        with timed("06_model_fitting", logger):
            models = self._stage_fit(interactions, content, split)
        with timed("07_evaluation", logger):
            results = self._stage_evaluate(models, interactions, content, split)
        with timed("08_statistics", logger):
            self._stage_statistics(results)
        with timed("09_business", logger):
            self._stage_business(clean, split, interactions, content, models, results)
        with timed("10_persistence", logger):
            self._stage_persist()

        self.artifacts.timings = dict(TIMINGS)
        elapsed = time.perf_counter() - start
        logger.info("=" * 78)
        logger.info("RUN COMPLETE in %.1f s — artefacts in %s", elapsed, self.output_dir)
        best = self.artifacts.best_model_name(self.cfg.evaluation.primary_metric)
        if best:
            score = self.artifacts.results[best].get(self.cfg.evaluation.primary_metric)
            logger.info(
                "Best model: '%s' with %s = %.4f",
                best,
                self.cfg.evaluation.primary_metric,
                score,
            )
        logger.info("=" * 78)
        return self.artifacts

    # ======================================================================
    # stages
    # ======================================================================
    def _stage_acquire(self) -> pd.DataFrame:
        loader = DataLoader(self.cfg.data, project_root=self.root)
        raw = loader.load()
        self.artifacts.raw_source = raw.source
        logger.info("Dataset — %s", raw.describe())
        return raw.frame

    def _stage_clean(self, frame: pd.DataFrame) -> pd.DataFrame:
        cleaner = TransactionCleaner(self.cfg.preprocessing)
        clean = cleaner.clean(frame)
        if clean.empty:
            raise RuntimeError(
                "Cleaning removed every transaction. Relax the filters in "
                "config.yaml (notably preprocessing.min_user_interactions)."
            )
        self.artifacts.clean_frame = clean
        self.artifacts.cleaning_report = cleaner.report.to_frame()
        return clean

    def _stage_describe(self, clean: pd.DataFrame) -> None:
        stats = compute_dataset_statistics(clean)
        self.artifacts.dataset_stats = stats
        logger.info(
            "Descriptives — %d users, %d items, density %.4f%%, "
            "Gini(popularity)=%.3f, AOV £%.2f.",
            int(stats["n_users"]),
            int(stats["n_items"]),
            stats["density_pct"],
            stats["gini_item_popularity"],
            stats["mean_order_value"],
        )

    def _stage_split(self, clean: pd.DataFrame) -> DataSplit:
        splitter = TemporalSplitter(self.cfg.splitting)
        split = splitter.split(clean)
        if split.test.empty:
            raise RuntimeError(
                "The test partition is empty. Reduce splitting.test_ratio or "
                "relax splitting.min_train_interactions_for_eval."
            )
        self.artifacts.split = split
        return split

    def _stage_features(self, split: DataSplit):
        builder = InteractionBuilder(self.cfg.features)
        interactions = builder.build(
            split.train,
            n_users=split.n_users,
            n_items=split.n_items,
            reference_date=split.train["invoice_date"].max(),
        )
        content = ContentFeatureBuilder(self.cfg.features).build(
            split.train, n_items=split.n_items, item_ids=split.item_ids
        )
        self.artifacts.interactions = interactions
        self.artifacts.content = content
        return interactions, content

    def _stage_fit(
        self,
        interactions: InteractionData,
        content: ContentFeatures,
        split: DataSplit,
    ) -> Dict[str, Recommender]:
        context = FitContext(
            train_frame=split.train,
            content_features=content,
            item_ids=split.item_ids,
            user_ids=split.user_ids,
            random_seed=self.cfg.experiment.random_seed,
        )

        models: Dict[str, Recommender] = {}
        for name in self.cfg.models.enabled_models():
            if name == "hybrid":
                continue                          # assembled after the bases
            params = self.cfg.models.params(name)
            try:
                t0 = time.perf_counter()
                model = build_model(name, **params)
                model.fit(interactions, context)
                self.artifacts.fit_seconds[name] = time.perf_counter() - t0
                models[name] = model
            except Exception as exc:
                # A single failing algorithm must not abort the comparison.
                logger.error("Model '%s' failed to fit: %s", name, exc, exc_info=True)

        if self.cfg.models.is_enabled("hybrid") and models:
            try:
                params = self.cfg.models.params("hybrid")
                t0 = time.perf_counter()
                hybrid = HybridRecommender(base_models=models, **params)
                hybrid.fit(interactions, context)
                self.artifacts.fit_seconds["hybrid"] = time.perf_counter() - t0
                models["hybrid"] = hybrid
            except Exception as exc:
                logger.error("Hybrid assembly failed: %s", exc, exc_info=True)

        if not models:
            raise RuntimeError("No model could be fitted; aborting.")
        self.artifacts.models = models
        logger.info("Fitted %d models: %s", len(models), sorted(models))
        return models

    def _stage_evaluate(
        self,
        models: Dict[str, Recommender],
        interactions: InteractionData,
        content: ContentFeatures,
        split: DataSplit,
    ) -> Dict[str, EvaluationResult]:
        evaluator = Evaluator(
            self.cfg.evaluation,
            interactions,
            item_features=content.matrix,
            item_price=interactions.item_mean_price,
        )
        ground_truth = split.test_ground_truth(
            exclude_seen=self.cfg.evaluation.exclude_seen
        )
        logger.info("Ground truth covers %d users.", len(ground_truth))

        results = evaluator.evaluate_all(
            models, ground_truth, seed=self.cfg.experiment.random_seed
        )
        self.artifacts.results = results
        frame = results_to_frame(results)
        self.artifacts.results_frame = frame

        primary = self.cfg.evaluation.primary_metric
        if primary in frame.columns:
            ranking = frame[primary].sort_values(ascending=False)
            logger.info("Ranking by %s:", primary)
            for rank, (name, score) in enumerate(ranking.items(), start=1):
                logger.info("  %d. %-20s %.4f", rank, name, score)
        return results

    def _stage_statistics(self, results: Dict[str, EvaluationResult]) -> None:
        if not self.cfg.statistics.enabled or len(results) < 2:
            logger.info("Statistical testing skipped.")
            return
        per_user = {n: r.per_user for n, r in results.items() if r.per_user}
        if len(per_user) < 2:
            logger.warning("Insufficient per-user data for significance testing.")
            return

        metric = self.cfg.evaluation.primary_metric
        report = compare_models(per_user, metric, self.cfg.statistics)
        self.artifacts.statistical_report = report

        n_sig = len(report.significant_pairs())
        logger.info(
            "Statistical testing — %d of %d pairwise comparisons significant "
            "at α=%.2f (%s correction).",
            n_sig,
            len(report.comparisons),
            self.cfg.statistics.alpha,
            self.cfg.statistics.correction,
        )
        for c in sorted(report.comparisons, key=lambda x: x.p_value_corrected)[:5]:
            logger.info(
                "  %-18s vs %-18s Δ=%+.4f p=%.4f %s",
                c.model_a, c.model_b, c.delta, c.p_value_corrected,
                "✓" if c.significant else "",
            )

    def _stage_business(
        self,
        clean: pd.DataFrame,
        split: DataSplit,
        interactions: InteractionData,
        content: ContentFeatures,
        models: Dict[str, Recommender],
        results: Dict[str, EvaluationResult],
    ) -> None:
        cfg = self.cfg.business

        # --- RFM segmentation ---------------------------------------------
        try:
            self.artifacts.rfm = compute_rfm(clean, quantiles=cfg.rfm_quantiles)
        except Exception as exc:
            logger.error("RFM computation failed: %s", exc)

        # --- CLV ----------------------------------------------------------
        try:
            calculator = CLVCalculator(
                horizon_days=cfg.clv_prediction_horizon_days,
                discount_rate=cfg.clv_discount_rate,
                gross_margin=cfg.gross_margin,
            )
            self.artifacts.clv = calculator.compute(clean)
        except Exception as exc:
            logger.error("CLV computation failed: %s", exc, exc_info=True)

        # --- Merchandising exemplars --------------------------------------
        rules = models.get("association_rules")
        if rules is not None:
            try:
                engine = CrossSellEngine(
                    rules,
                    interactions.item_mean_price,
                    gross_margin=cfg.gross_margin,
                    item_ids=split.item_ids,
                    descriptions=content.descriptions,
                )
                anchors = np.argsort(-interactions.item_popularity)[:10]
                rows = []
                for anchor in anchors:
                    for s in engine.suggest([int(anchor)], n=3):
                        rows.append(
                            {
                                "anchor_item": str(split.item_ids[anchor]),
                                "anchor_description": str(content.descriptions[anchor]),
                                "suggested_item": s.item_id,
                                "suggested_description": s.description,
                                "score": round(s.score, 4),
                                "price": round(s.price, 2),
                                "expected_margin": round(s.expected_margin, 2),
                                "reason": s.reason,
                            }
                        )
                self.artifacts.cross_sell_examples = pd.DataFrame(rows)
                logger.info("  generated %d cross-sell exemplars.", len(rows))
            except Exception as exc:
                logger.error("Cross-sell generation failed: %s", exc)

        try:
            up_engine = UpSellEngine(
                content.matrix,
                interactions.item_mean_price,
                item_ids=split.item_ids,
                descriptions=content.descriptions,
            )
            anchors = np.argsort(-interactions.item_popularity)[:10]
            rows = []
            for anchor in anchors:
                for s in up_engine.suggest(int(anchor), n=3):
                    rows.append(
                        {
                            "anchor_item": str(split.item_ids[anchor]),
                            "anchor_description": str(content.descriptions[anchor]),
                            "anchor_price": round(
                                float(interactions.item_mean_price[anchor]), 2
                            ),
                            "suggested_item": s.item_id,
                            "suggested_description": s.description,
                            "suggested_price": round(s.price, 2),
                            "score": round(s.score, 4),
                            "reason": s.reason,
                        }
                    )
            self.artifacts.up_sell_examples = pd.DataFrame(rows)
            logger.info("  generated %d up-sell exemplars.", len(rows))
        except Exception as exc:
            logger.error("Up-sell generation failed: %s", exc)

        # --- Uplift simulation --------------------------------------------
        if cfg.simulate_uplift and results:
            try:
                metric = self.cfg.evaluation.primary_metric
                scores = {
                    n: r.get(metric)
                    for n, r in results.items()
                    if np.isfinite(r.get(metric))
                }
                aov = float(self.artifacts.dataset_stats.get("mean_order_value", 20.0))
                simulator = RevenueSimulator(cfg, average_order_value=aov)
                self.artifacts.simulation = simulator.simulate(scores)
            except Exception as exc:
                logger.error("Uplift simulation failed: %s", exc, exc_info=True)

        # --- Long-tail exposure -------------------------------------------
        best = self.artifacts.best_model_name(self.cfg.evaluation.primary_metric)
        if best and best in models:
            try:
                exposure = self._compute_exposure(models[best], split)
                self.artifacts.long_tail_analysis = coverage_revenue_analysis(
                    interactions.item_revenue, interactions.item_popularity, exposure
                )
            except Exception as exc:
                logger.error("Long-tail analysis failed: %s", exc)

    #: Users sampled when measuring catalogue exposure for the long-tail table.
    EXPOSURE_SAMPLE = 1000

    def _compute_exposure(self, model: Recommender, split: DataSplit) -> np.ndarray:
        """Count how often each item is recommended by the winning model.

        The sample is drawn with a seeded RNG rather than taken as the first
        *n* user indices: index order follows sorted customer id, which is not
        a random property, and truncating it would bias the exposure profile.
        """
        exposure = np.zeros(split.n_items, dtype=np.float64)
        candidates = sorted(
            split.test_ground_truth(
                exclude_seen=self.cfg.evaluation.exclude_seen
            ).keys()
        )
        if len(candidates) > self.EXPOSURE_SAMPLE:
            rng = np.random.default_rng(self.cfg.experiment.random_seed)
            users = sorted(
                rng.choice(candidates, size=self.EXPOSURE_SAMPLE, replace=False).tolist()
            )
        else:
            users = candidates
        k = self.cfg.evaluation.primary_cutoff
        for user in users:
            recommended = model.recommend(user, n=k, exclude_seen=True)
            exposure[recommended] += 1.0
        return exposure

    # ======================================================================
    # persistence
    # ======================================================================
    def _write_environment(self) -> None:
        env = {
            "run_id": self.run_id,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "python": sys.version.split()[0],
            "platform": platform.platform(),
            "processor": platform.processor(),
            "numpy": np.__version__,
            "pandas": pd.__version__,
            "random_seed": self.cfg.experiment.random_seed,
        }
        try:
            import scipy
            import sklearn

            env["scipy"] = scipy.__version__
            env["scikit_learn"] = sklearn.__version__
        except Exception:  # pragma: no cover
            pass
        (self.output_dir / "environment.json").write_text(
            json.dumps(env, indent=2), encoding="utf-8"
        )

    def _stage_persist(self) -> None:
        art = self.artifacts
        out = self.output_dir
        out.mkdir(parents=True, exist_ok=True)

        def save_frame(frame: Optional[pd.DataFrame], name: str, index: bool = True) -> None:
            if frame is None or frame.empty:
                return
            try:
                frame.to_csv(out / f"{name}.csv", index=index, encoding="utf-8")
                logger.info("  wrote %s.csv (%d rows)", name, len(frame))
            except Exception as exc:  # pragma: no cover
                logger.error("  failed to write %s.csv: %s", name, exc)

        save_frame(art.results_frame, "results")
        save_frame(art.cleaning_report, "cleaning_report", index=False)
        save_frame(art.cross_sell_examples, "cross_sell_examples", index=False)
        save_frame(art.up_sell_examples, "up_sell_examples", index=False)
        save_frame(art.long_tail_analysis, "long_tail_analysis", index=False)

        if art.dataset_stats:
            pd.Series(art.dataset_stats).to_csv(out / "dataset_statistics.csv", header=["value"])

        if art.rfm is not None:
            save_frame(art.rfm.segment_summary, "rfm_segments")

        if art.clv is not None:
            save_frame(art.clv.decile_summary(), "clv_deciles")
            save_frame(art.clv.top_customers(50), "clv_top_customers")
            (out / "clv_parameters.json").write_text(
                json.dumps(
                    {"bgnbd": art.clv.bgnbd_params, "gamma_gamma": art.clv.gamma_params},
                    indent=2,
                ),
                encoding="utf-8",
            )

        if art.statistical_report is not None:
            save_frame(art.statistical_report.summary_frame(), "significance_tests", index=False)
            (out / "significance_tests.md").write_text(
                art.statistical_report.format_markdown(), encoding="utf-8"
            )
            try:
                per_user = {n: r.per_user for n, r in art.results.items() if r.per_user}
                save_frame(
                    significance_matrix(per_user, self.cfg.evaluation.primary_metric),
                    "p_value_matrix",
                )
                save_frame(
                    average_ranks(per_user, self.cfg.evaluation.primary_metric),
                    "average_ranks",
                )
            except Exception as exc:  # pragma: no cover
                logger.debug("  rank/p-matrix export skipped: %s", exc)

        if art.simulation is not None:
            save_frame(art.simulation.to_frame(), "uplift_simulation", index=False)
            save_frame(art.simulation.sensitivity, "uplift_sensitivity")
            (out / "simulation_assumptions.json").write_text(
                json.dumps(art.simulation.assumptions, indent=2), encoding="utf-8"
            )

        rules = art.models.get("association_rules")
        if rules is not None and hasattr(rules, "rules_frame"):
            save_frame(rules.rules_frame(200), "association_rules", index=False)

        # Consolidated machine-readable summary.
        summary = {
            "run_id": art.run_id,
            "data_source": art.raw_source,
            "dataset_statistics": art.dataset_stats,
            "models_fitted": sorted(art.models),
            "fit_seconds": {k: round(v, 2) for k, v in art.fit_seconds.items()},
            "primary_metric": self.cfg.evaluation.primary_metric,
            "best_model": art.best_model_name(self.cfg.evaluation.primary_metric),
            "results": {
                name: {k: (None if not np.isfinite(v) else round(float(v), 6))
                       for k, v in r.aggregate.items()}
                for name, r in art.results.items()
            },
            "stage_timings_seconds": {k: round(v, 2) for k, v in TIMINGS.items()},
        }
        (out / "summary.json").write_text(
            json.dumps(summary, indent=2, default=str), encoding="utf-8"
        )
        logger.info("  wrote summary.json")

        if self.cfg.experiment.save_figures:
            self._write_figures()

    def _write_figures(self) -> None:
        """Render the figures reproduced in Chapter 6."""
        try:
            import matplotlib

            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
        except Exception as exc:  # pragma: no cover
            logger.warning("  matplotlib unavailable; skipping figures (%s).", exc)
            return

        figures_dir = self.output_dir / "figures"
        figures_dir.mkdir(parents=True, exist_ok=True)
        art = self.artifacts

        # Figure 1 — accuracy comparison.
        if art.results_frame is not None:
            metric = self.cfg.evaluation.primary_metric
            if metric in art.results_frame.columns:
                data = art.results_frame[metric].sort_values()
                fig, ax = plt.subplots(figsize=(8, 4.5))
                ax.barh(data.index.astype(str), data.to_numpy(), color="#3b6ea5")
                ax.set_xlabel(metric.upper())
                ax.set_title(f"Model comparison — {metric.upper()}")
                for i, v in enumerate(data.to_numpy()):
                    ax.text(v, i, f" {v:.4f}", va="center", fontsize=8)
                fig.tight_layout()
                fig.savefig(figures_dir / "01_accuracy_comparison.png", dpi=150)
                plt.close(fig)

        # Figure 2 — accuracy versus catalogue coverage trade-off.
        if art.results_frame is not None:
            k = self.cfg.evaluation.primary_cutoff
            xcol, ycol = f"coverage@{k}", f"ndcg@{k}"
            if xcol in art.results_frame and ycol in art.results_frame:
                fig, ax = plt.subplots(figsize=(6.5, 5))
                for name, row in art.results_frame.iterrows():
                    ax.scatter(100 * row[xcol], row[ycol], s=90)
                    ax.annotate(
                        str(name),
                        (100 * row[xcol], row[ycol]),
                        textcoords="offset points",
                        xytext=(6, 4),
                        fontsize=8,
                    )
                ax.set_xlabel(f"Catalogue coverage@{k} (%)")
                ax.set_ylabel(f"NDCG@{k}")
                ax.set_title("Accuracy versus catalogue exposure")
                ax.grid(alpha=0.3)
                fig.tight_layout()
                fig.savefig(figures_dir / "02_accuracy_coverage_tradeoff.png", dpi=150)
                plt.close(fig)

        # Figure 3 — long-tail popularity distribution.
        if art.interactions is not None:
            popularity = np.sort(art.interactions.item_popularity)[::-1]
            fig, ax = plt.subplots(figsize=(7, 4.5))
            ax.plot(np.arange(1, popularity.size + 1), popularity, color="#a5453b")
            ax.set_xscale("log")
            ax.set_yscale("log")
            ax.set_xlabel("Item rank (log)")
            ax.set_ylabel("Distinct purchasers (log)")
            gini = art.dataset_stats.get("gini_item_popularity", float("nan"))
            ax.set_title(f"Long-tail item popularity (Gini = {gini:.3f})")
            ax.grid(alpha=0.3, which="both")
            fig.tight_layout()
            fig.savefig(figures_dir / "03_long_tail.png", dpi=150)
            plt.close(fig)

        # Figure 4 — RFM segment value.
        if art.rfm is not None and not art.rfm.segment_summary.empty:
            seg = art.rfm.segment_summary.head(10)
            fig, ax = plt.subplots(figsize=(8.5, 4.5))
            ax.bar(seg.index.astype(str), seg["revenue_share_pct"], color="#3b8f5a")
            ax.set_ylabel("Revenue share (%)")
            ax.set_title("Revenue contribution by RFM segment")
            plt.setp(ax.get_xticklabels(), rotation=35, ha="right", fontsize=8)
            fig.tight_layout()
            fig.savefig(figures_dir / "04_rfm_segments.png", dpi=150)
            plt.close(fig)

        # Figure 5 — revenue uplift sensitivity.
        if art.simulation is not None and art.simulation.sensitivity is not None:
            sens = art.simulation.sensitivity
            fig, ax = plt.subplots(figsize=(7.5, 4.5))
            for column in sens.columns:
                ax.plot(sens.index, sens[column], marker="o", label=str(column))
            ax.set_xlabel("CTR elasticity ε")
            ax.set_ylabel("Revenue uplift vs baseline (%)")
            ax.set_title("Sensitivity of projected uplift to the elasticity assumption")
            ax.legend(fontsize=8)
            ax.grid(alpha=0.3)
            fig.tight_layout()
            fig.savefig(figures_dir / "05_uplift_sensitivity.png", dpi=150)
            plt.close(fig)

        logger.info("  wrote figures to %s", figures_dir.name)
