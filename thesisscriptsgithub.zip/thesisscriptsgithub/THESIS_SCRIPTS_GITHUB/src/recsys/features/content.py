"""Textual content representation of the product catalogue.

The only descriptive attribute available in Online Retail II is the free-text
``Description`` field, which is short, upper-cased and noisy. Nevertheless it
carries genuine semantic signal ("RED RETRO SPOT MUG" shares terms with "BLUE
RETRO SPOT MUG"), and it is the *only* information available for a product that
has never been purchased. Content features therefore serve two purposes:

1. they enable recommendations for cold-start items, which collaborative
   filtering structurally cannot address; and
2. they provide an orthogonal similarity signal for the hybrid combiner,
   improving the diversity of the final ranking.

Representation follows the standard vector-space model with sub-linear term
frequency and smoothed inverse document frequency (Salton & Buckley, 1988). A
character-level fallback is not required because the vocabulary is small and
largely well-formed after normalisation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.feature_extraction.text import TfidfVectorizer

from recsys.config import FeatureConfig
from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = ["ContentFeatures", "ContentFeatureBuilder", "STOP_WORDS"]

#: Domain stop-words: retail-specific tokens that occur across the catalogue and
#: therefore carry no discriminative power, plus standard English function words.
STOP_WORDS = frozenset(
    {
        "set", "of", "pack", "the", "and", "with", "in", "for", "a", "an",
        "to", "on", "by", "or", "s", "x", "cm", "mm", "ml", "pcs", "pc",
        "assorted", "design", "designs", "colour", "colours", "color",
        "colors", "each", "per", "size", "large", "small", "mini", "new",
    }
)

_TOKEN_CLEANER = re.compile(r"[^a-z0-9\s]+")
_MULTISPACE = re.compile(r"\s+")


@dataclass
class ContentFeatures:
    """TF–IDF representation of the catalogue plus vocabulary metadata."""

    matrix: sp.csr_matrix            # items × terms, L2-normalised
    vocabulary: np.ndarray           # term strings, aligned with columns
    descriptions: np.ndarray         # canonical description per item index
    vectorizer: TfidfVectorizer

    @property
    def n_items(self) -> int:
        return self.matrix.shape[0]

    @property
    def n_terms(self) -> int:
        return self.matrix.shape[1]

    def similarity_to(self, item_idx: int, top_k: int = 10) -> List[tuple[int, float]]:
        """Return the ``top_k`` most textually similar items."""
        scores = np.asarray((self.matrix @ self.matrix[item_idx].T).todense()).ravel()
        scores[item_idx] = -np.inf
        k = min(top_k, scores.size - 1)
        if k <= 0:
            return []
        idx = np.argpartition(-scores, k)[:k]
        idx = idx[np.argsort(-scores[idx])]
        return [(int(i), float(scores[i])) for i in idx if np.isfinite(scores[i])]

    def top_terms(self, item_idx: int, n: int = 5) -> List[str]:
        row = self.matrix[item_idx]
        if row.nnz == 0:
            return []
        order = np.argsort(-row.data)[:n]
        return [str(self.vocabulary[row.indices[j]]) for j in order]


class ContentFeatureBuilder:
    """Build the item × term TF–IDF matrix from product descriptions."""

    def __init__(self, cfg: FeatureConfig) -> None:
        self.cfg = cfg

    def build(
        self,
        frame: pd.DataFrame,
        n_items: int,
        item_ids: Optional[Sequence[str]] = None,
    ) -> ContentFeatures:
        descriptions = self._canonical_descriptions(frame, n_items)
        corpus = [self._normalise(d) for d in descriptions]

        vectorizer = TfidfVectorizer(
            max_features=self.cfg.tfidf_max_features,
            ngram_range=(1, max(1, self.cfg.tfidf_ngram_max)),
            min_df=self.cfg.tfidf_min_df,
            sublinear_tf=True,
            norm="l2",
            stop_words=sorted(STOP_WORDS),
            token_pattern=r"(?u)\b[a-z][a-z0-9]{1,}\b",
        )
        try:
            matrix = vectorizer.fit_transform(corpus)
        except ValueError:  # pragma: no cover - empty/degenerate vocabulary
            logger.warning("TF-IDF vocabulary empty; falling back to unigram counts.")
            vectorizer = TfidfVectorizer(min_df=1, norm="l2")
            matrix = vectorizer.fit_transform([c or "unknown" for c in corpus])

        matrix = sp.csr_matrix(matrix, dtype=np.float32)
        vocabulary = np.asarray(vectorizer.get_feature_names_out())

        logger.info(
            "Content features — %d items × %d terms (nnz=%d, mean terms/item=%.1f).",
            matrix.shape[0],
            matrix.shape[1],
            matrix.nnz,
            matrix.nnz / max(matrix.shape[0], 1),
        )
        return ContentFeatures(
            matrix=matrix,
            vocabulary=vocabulary,
            descriptions=np.asarray(descriptions, dtype=object),
            vectorizer=vectorizer,
        )

    # ------------------------------------------------------------------ utils
    @staticmethod
    def _canonical_descriptions(frame: pd.DataFrame, n_items: int) -> List[str]:
        """Pick the modal description per item (descriptions vary across rows)."""
        descriptions = [""] * n_items
        if "description" not in frame.columns:
            return descriptions
        grouped = frame.groupby("item_idx")["description"]
        for item_idx, series in grouped:
            values = series.dropna().astype(str)
            values = values[values.str.len() > 0]
            if values.empty:
                continue
            modal = values.mode()
            idx = int(item_idx)
            if 0 <= idx < n_items:
                descriptions[idx] = str(modal.iloc[0]) if len(modal) else str(values.iloc[0])
        return descriptions

    @staticmethod
    def _normalise(text: str) -> str:
        """Lower-case, strip punctuation and collapse whitespace."""
        t = str(text).lower()
        t = _TOKEN_CLEANER.sub(" ", t)
        t = _MULTISPACE.sub(" ", t).strip()
        return t
