"""Feature engineering layer: interactions, behavioural and content features."""

from __future__ import annotations

from recsys.features.content import ContentFeatureBuilder, ContentFeatures
from recsys.features.interactions import (
    InteractionBuilder,
    InteractionData,
    bm25_weight,
    normalize_rows_l2,
    tfidf_weight,
)
from recsys.features.rfm import RFMResult, compute_rfm

__all__ = [
    "InteractionBuilder",
    "InteractionData",
    "normalize_rows_l2",
    "bm25_weight",
    "tfidf_weight",
    "compute_rfm",
    "RFMResult",
    "ContentFeatureBuilder",
    "ContentFeatures",
]
