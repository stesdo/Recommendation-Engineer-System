"""RFM behavioural segmentation.

Recency–Frequency–Monetary analysis (Hughes, 1994) is the canonical
non-parametric customer-value model in direct marketing, and it plays two roles
in this system. First, it supplies an *interpretable* segmentation that
management can act upon — the recommendation engine's output is conditioned on
segment membership in the business layer. Second, the RFM triple is the
sufficient statistic consumed by the probabilistic CLV models of
:mod:`recsys.business.clv`.

Quantile scoring is used rather than absolute thresholds, so the segmentation is
scale-free and transfers across catalogues and currencies. Recency is scored in
reverse (a *recent* purchase deserves a *high* score), which is a frequent source
of error in applied work.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import pandas as pd

from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = ["RFMResult", "compute_rfm", "SEGMENT_RULES"]


#: Managerial segment definitions expressed over the (R, F) score plane. The
#: mapping follows the widely used eleven-segment taxonomy popularised by
#: Putler/Blastanalytics and adapted to a 1–5 quantile scale.
SEGMENT_RULES = [
    ("Champions", lambda r, f, m: r >= 4 and f >= 4),
    ("Loyal Customers", lambda r, f, m: r >= 3 and f >= 4),
    ("Potential Loyalist", lambda r, f, m: r >= 4 and 2 <= f <= 3),
    ("Recent Customers", lambda r, f, m: r >= 4 and f <= 1),
    ("Promising", lambda r, f, m: r == 3 and f <= 2),
    ("Need Attention", lambda r, f, m: r == 3 and f == 3),
    ("About to Sleep", lambda r, f, m: r == 2 and f <= 2),
    ("At Risk", lambda r, f, m: r <= 2 and f >= 3),
    ("Cannot Lose Them", lambda r, f, m: r <= 1 and f >= 4),
    ("Hibernating", lambda r, f, m: r <= 2 and f == 2),
    ("Lost", lambda r, f, m: r <= 1 and f <= 1),
]


@dataclass
class RFMResult:
    """Per-customer RFM table plus segment aggregates."""

    table: pd.DataFrame          # index: customer_id
    segment_summary: pd.DataFrame
    reference_date: pd.Timestamp

    def segment_of(self, customer_id: int) -> Optional[str]:
        if customer_id in self.table.index:
            return str(self.table.loc[customer_id, "segment"])
        return None

    def as_dict(self) -> Dict[int, Dict[str, float]]:
        return self.table.to_dict(orient="index")


def compute_rfm(
    frame: pd.DataFrame,
    reference_date: Optional[pd.Timestamp] = None,
    quantiles: int = 5,
) -> RFMResult:
    """Compute RFM scores and managerial segments.

    Parameters
    ----------
    frame:
        Cleaned transaction log with ``customer_id``, ``invoice``,
        ``invoice_date`` and ``revenue`` columns.
    reference_date:
        "Today" for the recency computation. Defaults to one day after the last
        observed transaction, which avoids zero-recency degeneracies.
    quantiles:
        Number of score bands (5 by default → scores in 1…5).
    """
    if frame.empty:
        raise ValueError("Cannot compute RFM on an empty frame.")

    ref = reference_date or (frame["invoice_date"].max() + pd.Timedelta(days=1))

    agg = (
        frame.groupby("customer_id")
        .agg(
            last_purchase=("invoice_date", "max"),
            first_purchase=("invoice_date", "min"),
            frequency=("invoice", "nunique"),
            monetary=("revenue", "sum"),
            n_items=("stock_code", "nunique"),
            n_lines=("invoice", "size"),
        )
    )
    agg["recency_days"] = (ref - agg["last_purchase"]).dt.days.astype(float)
    agg["tenure_days"] = (ref - agg["first_purchase"]).dt.days.astype(float)
    agg["avg_order_value"] = agg["monetary"] / agg["frequency"].clip(lower=1)

    agg["r_score"] = _quantile_score(-agg["recency_days"], quantiles)  # reversed
    agg["f_score"] = _quantile_score(agg["frequency"], quantiles)
    agg["m_score"] = _quantile_score(agg["monetary"], quantiles)
    agg["rfm_score"] = agg["r_score"] + agg["f_score"] + agg["m_score"]
    agg["rfm_cell"] = (
        agg["r_score"].astype(int).astype(str)
        + agg["f_score"].astype(int).astype(str)
        + agg["m_score"].astype(int).astype(str)
    )
    agg["segment"] = [
        _assign_segment(int(r), int(f), int(m))
        for r, f, m in zip(agg["r_score"], agg["f_score"], agg["m_score"])
    ]

    summary = (
        agg.groupby("segment")
        .agg(
            customers=("monetary", "size"),
            revenue=("monetary", "sum"),
            avg_recency_days=("recency_days", "mean"),
            avg_frequency=("frequency", "mean"),
            avg_monetary=("monetary", "mean"),
            avg_order_value=("avg_order_value", "mean"),
        )
        .sort_values("revenue", ascending=False)
    )
    total_rev = summary["revenue"].sum()
    summary["revenue_share_pct"] = 100.0 * summary["revenue"] / total_rev if total_rev else 0.0
    summary["customer_share_pct"] = 100.0 * summary["customers"] / summary["customers"].sum()

    logger.info(
        "RFM computed for %d customers across %d segments (reference %s).",
        len(agg),
        summary.shape[0],
        f"{ref:%Y-%m-%d}",
    )
    return RFMResult(table=agg, segment_summary=summary, reference_date=ref)


# ---------------------------------------------------------------------------
def _quantile_score(series: pd.Series, quantiles: int) -> pd.Series:
    """Map a numeric series onto integer scores 1…q by empirical quantiles.

    ``pd.qcut`` fails when the distribution is heavily tied (a frequent case:
    the majority of customers place exactly one order). The fallback is a
    rank-based assignment, which degrades gracefully.
    """
    try:
        binned = pd.qcut(series.rank(method="first"), q=quantiles, labels=False)
        return (binned + 1).astype(int)
    except (ValueError, IndexError):  # pragma: no cover - degenerate input
        ranks = series.rank(method="average", pct=True)
        return np.ceil(ranks * quantiles).clip(1, quantiles).astype(int)


def _assign_segment(r: int, f: int, m: int) -> str:
    for name, predicate in SEGMENT_RULES:
        if predicate(r, f, m):
            return name
    return "Others"
