"""Construction of the sparse user × item interaction matrix.

Retail purchase logs supply *implicit* feedback: we observe that a customer
bought an article, never that they liked it, and the absence of a purchase
conflates disinterest with non-exposure. Following Hu, Koren and Volinsky (2008)
we therefore separate two quantities:

*preference* :math:`p_{ui} \\in \\{0,1\\}`
    whether any interaction occurred;
*confidence* :math:`c_{ui} \\ge 0`
    how strongly we believe the observed preference.

The confidence transformation is the single most consequential modelling choice
in this layer, and four alternatives are offered:

``binary``
    :math:`c_{ui} = 1`. Discards intensity; a robust baseline.
``count``
    :math:`c_{ui} = n_{ui}`, the number of distinct invoices. Linear in
    repetition and consequently dominated by wholesale bulk buyers.
``log_count``
    :math:`c_{ui} = 1 + \\alpha \\log(1 + n_{ui})`. Concave saturation; the
    default, because repeat purchase carries diminishing evidential value.
``monetary``
    :math:`c_{ui} = 1 + \\alpha \\log(1 + r_{ui})` on cumulative revenue, which
    aligns the objective with contribution margin rather than unit volume.

An optional exponential *recency decay* multiplies each weight by
:math:`2^{-\\Delta t / h}` where :math:`\\Delta t` is the age of the interaction
in days and :math:`h` the configured half-life. This encodes the empirical
non-stationarity of taste, and is the mechanism through which the system
implements the "current digital footprint" notion of the thesis.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

import numpy as np
import pandas as pd
import scipy.sparse as sp

from recsys.config import FeatureConfig
from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = [
    "InteractionData",
    "InteractionBuilder",
    "normalize_rows_l2",
    "bm25_weight",
    "tfidf_weight",
]


@dataclass
class InteractionData:
    """Sparse interaction matrices plus the auxiliary statistics models need."""

    matrix: sp.csr_matrix            # weighted confidence, users × items
    binary: sp.csr_matrix            # 0/1 preference, users × items
    item_popularity: np.ndarray      # distinct users per item
    item_revenue: np.ndarray         # cumulative revenue per item
    item_mean_price: np.ndarray      # mean observed unit price per item
    user_activity: np.ndarray        # distinct items per user
    n_users: int
    n_items: int

    def user_row(self, user_idx: int) -> sp.csr_matrix:
        return self.matrix[user_idx]

    def seen_items(self, user_idx: int) -> np.ndarray:
        start, end = self.binary.indptr[user_idx], self.binary.indptr[user_idx + 1]
        return self.binary.indices[start:end]

    @property
    def density(self) -> float:
        denom = self.n_users * self.n_items
        return self.matrix.nnz / denom if denom else 0.0

    def summary(self) -> str:
        return (
            f"{self.n_users:,}×{self.n_items:,} nnz={self.matrix.nnz:,} "
            f"density={100 * self.density:.4f}%"
        )


class InteractionBuilder:
    """Turn a transaction frame into weighted sparse matrices."""

    def __init__(self, cfg: FeatureConfig) -> None:
        self.cfg = cfg

    def build(
        self,
        frame: pd.DataFrame,
        n_users: int,
        n_items: int,
        reference_date: Optional[pd.Timestamp] = None,
    ) -> InteractionData:
        if frame.empty:
            raise ValueError("Cannot build interactions from an empty frame.")
        cfg = self.cfg

        # Aggregate the transaction log to the (user, item) grain. ``invoice``
        # cardinality — not row count — is the correct notion of repetition,
        # since a single basket may contain the same article on several lines.
        agg = (
            frame.groupby(["user_idx", "item_idx"])
            .agg(
                n_invoices=("invoice", "nunique"),
                quantity=("quantity", "sum"),
                revenue=("revenue", "sum"),
                last_date=("invoice_date", "max"),
                mean_price=("unit_price", "mean"),
            )
            .reset_index()
        )

        weights = self._confidence(agg)

        if cfg.apply_recency_decay:
            ref = reference_date or frame["invoice_date"].max()
            age_days = (ref - agg["last_date"]).dt.total_seconds() / 86_400.0
            decay = np.power(2.0, -np.maximum(age_days.to_numpy(), 0.0)
                             / cfg.recency_half_life_days)
            weights = weights * decay
            logger.info(
                "Recency decay applied (half-life %.0f d): weight range [%.4f, %.4f].",
                cfg.recency_half_life_days,
                float(weights.min()),
                float(weights.max()),
            )

        rows = agg["user_idx"].to_numpy(dtype=np.int32)
        cols = agg["item_idx"].to_numpy(dtype=np.int32)
        shape = (n_users, n_items)

        matrix = sp.csr_matrix(
            (weights.astype(np.float32), (rows, cols)), shape=shape
        )
        matrix.eliminate_zeros()
        binary = sp.csr_matrix(
            (np.ones(rows.size, dtype=np.float32), (rows, cols)), shape=shape
        )

        item_popularity = np.asarray(binary.sum(axis=0)).ravel()
        user_activity = np.asarray(binary.sum(axis=1)).ravel()

        item_revenue = np.zeros(n_items, dtype=np.float64)
        np.add.at(item_revenue, cols, agg["revenue"].to_numpy(dtype=np.float64))

        item_mean_price = np.zeros(n_items, dtype=np.float64)
        price_counts = np.zeros(n_items, dtype=np.float64)
        np.add.at(item_mean_price, cols, agg["mean_price"].to_numpy(dtype=np.float64))
        np.add.at(price_counts, cols, 1.0)
        with np.errstate(invalid="ignore", divide="ignore"):
            item_mean_price = np.where(
                price_counts > 0, item_mean_price / price_counts, 0.0
            )

        data = InteractionData(
            matrix=matrix,
            binary=binary,
            item_popularity=item_popularity,
            item_revenue=item_revenue,
            item_mean_price=item_mean_price,
            user_activity=user_activity,
            n_users=n_users,
            n_items=n_items,
        )
        logger.info("Interaction matrix — %s (weighting=%s)", data.summary(), cfg.weighting)
        return data

    # ----------------------------------------------------------- confidence
    def _confidence(self, agg: pd.DataFrame) -> np.ndarray:
        cfg = self.cfg
        n = agg["n_invoices"].to_numpy(dtype=np.float64)
        if cfg.weighting == "binary":
            return np.ones_like(n)
        if cfg.weighting == "count":
            return n
        if cfg.weighting == "log_count":
            return 1.0 + cfg.log_alpha * np.log1p(n)
        if cfg.weighting == "monetary":
            revenue = np.maximum(agg["revenue"].to_numpy(dtype=np.float64), 0.0)
            return 1.0 + cfg.log_alpha * np.log1p(revenue)
        raise ValueError(f"Unsupported weighting scheme: {cfg.weighting!r}")


# ---------------------------------------------------------------------------
# Re-weighting transforms shared by several models
# ---------------------------------------------------------------------------
def normalize_rows_l2(matrix: sp.csr_matrix) -> sp.csr_matrix:
    """Scale each row to unit Euclidean norm (zero rows left untouched)."""
    m = matrix.tocsr(copy=True).astype(np.float32)
    norms = np.sqrt(np.asarray(m.multiply(m).sum(axis=1)).ravel())
    norms[norms == 0] = 1.0
    inv = sp.diags(1.0 / norms)
    return sp.csr_matrix(inv @ m)


def bm25_weight(
    matrix: sp.csr_matrix, k1: float = 1.2, b: float = 0.75
) -> sp.csr_matrix:
    """Okapi BM25 re-weighting of an interaction matrix.

    Introduced to collaborative filtering by analogy with document retrieval
    (Robertson & Zaragoza, 2009): items play the role of terms and users of
    documents. The ``b`` parameter controls length normalisation, penalising
    users with very long histories, while ``k1`` saturates term frequency. This
    transform is the standard remedy for popularity bias in item-kNN.
    """
    m = matrix.tocsc(copy=True).astype(np.float64)

    # Document frequency of item j = number of users who interacted with j,
    # i.e. the number of stored entries in column j. On a CSC matrix that is
    # the column pointer difference; ``m.indices`` holds *row* (user) indices
    # and must not be used here.
    n_users = m.shape[0]
    doc_freq = np.diff(m.indptr).astype(np.float64)
    idf = np.log((n_users - doc_freq + 0.5) / (doc_freq + 0.5) + 1.0)

    row_sums = np.asarray(matrix.sum(axis=1)).ravel().astype(np.float64)
    avg_len = row_sums.mean() if row_sums.size else 1.0
    if avg_len <= 0:
        avg_len = 1.0
    length_norm = k1 * (1.0 - b + b * row_sums / avg_len)

    m = m.tocoo()
    tf = m.data
    denom = tf + length_norm[m.row]
    denom[denom == 0] = 1e-12
    weighted = tf * (k1 + 1.0) / denom * idf[m.col]
    out = sp.csr_matrix((weighted.astype(np.float32), (m.row, m.col)), shape=m.shape)
    out.eliminate_zeros()
    return out


def tfidf_weight(matrix: sp.csr_matrix) -> sp.csr_matrix:
    """Classical TF–IDF re-weighting (sub-linear TF, smoothed IDF)."""
    m = matrix.tocoo(copy=True).astype(np.float64)
    n_users = m.shape[0]
    doc_freq = np.bincount(m.col, minlength=m.shape[1]).astype(np.float64)
    idf = np.log((1.0 + n_users) / (1.0 + doc_freq)) + 1.0
    weighted = np.sqrt(m.data) * idf[m.col]
    out = sp.csr_matrix((weighted.astype(np.float32), (m.row, m.col)), shape=m.shape)
    out.eliminate_zeros()
    return out
