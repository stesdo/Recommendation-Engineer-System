"""Evaluation and statistical-inference machinery."""

from __future__ import annotations

from recsys.evaluation.evaluator import EvaluationResult, Evaluator, results_to_frame
from recsys.evaluation.statistics import (
    PairwiseComparison,
    StatisticalReport,
    average_ranks,
    bonferroni_correction,
    compare_models,
    critical_difference,
    holm_correction,
    paired_bootstrap_ci,
    significance_matrix,
)
import recsys.evaluation.metrics  # noqa: F401

__all__ = [
    "EvaluationResult",
    "Evaluator",
    "results_to_frame",
    "PairwiseComparison",
    "StatisticalReport",
    "significance_matrix",
    "compare_models",
    "paired_bootstrap_ci",
    "holm_correction",
    "bonferroni_correction",
    "critical_difference",
    "average_ranks",
]
