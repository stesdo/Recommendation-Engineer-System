"""Offline evaluation loop.

The evaluator implements a *strong generalisation* protocol: models are trained
on the past and asked to rank the entire catalogue for the future period. Two
design decisions deserve emphasis because they determine whether the reported
numbers are meaningful.

**Full-catalogue ranking, not sampled negatives.** A widespread shortcut is to
score the held-out positive against 99 random negatives. Krichene and Rendle
(2020) proved that this yields *inconsistent* estimates: the induced ranking of
algorithms can differ from — and even invert — the ranking obtained on the full
catalogue. This implementation therefore always ranks all items.

**Per-user metric vectors are retained.** Aggregate means alone cannot support
inference. By keeping the per-user vector of every metric, the evaluator enables
the paired Wilcoxon tests and bootstrap confidence intervals of
:mod:`recsys.evaluation.statistics`, which is what licenses claims such as
"model A outperforms model B" rather than "model A had a higher average".
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence

import numpy as np
import pandas as pd
import scipy.sparse as sp

from recsys.config import EvaluationConfig
from recsys.evaluation import metrics as M
from recsys.features.interactions import InteractionData
from recsys.logging_utils import ProgressReporter, get_logger
from recsys.models.base import Recommender, top_n_from_scores

logger = get_logger(__name__)

__all__ = ["EvaluationResult", "Evaluator"]


@dataclass
class EvaluationResult:
    """Aggregate scores plus the per-user vectors needed for inference."""

    model_name: str
    aggregate: Dict[str, float]
    per_user: Dict[str, np.ndarray] = field(default_factory=dict)
    n_users_evaluated: int = 0
    elapsed_seconds: float = 0.0

    def get(self, metric: str, default: float = float("nan")) -> float:
        return self.aggregate.get(metric, default)

    def to_series(self) -> pd.Series:
        s = pd.Series(self.aggregate, name=self.model_name)
        s["n_users_evaluated"] = self.n_users_evaluated
        s["eval_seconds"] = self.elapsed_seconds
        return s

    def summary(self, cutoff: int = 10) -> str:
        parts = [
            f"{m}@{cutoff}={self.aggregate.get(f'{m}@{cutoff}', float('nan')):.4f}"
            for m in ("precision", "recall", "ndcg", "map", "hit_rate")
        ]
        return f"{self.model_name}: " + "  ".join(parts)


class Evaluator:
    """Rank the catalogue for every evaluable user and score the rankings."""

    #: Users scored per ``score_batch`` call. Chosen so that the dense score
    #: block stays well inside cache-friendly memory (512 × ~4k items × 8 B
    #: ≈ 16 MB) while still amortising the matrix product.
    USER_BLOCK = 512

    def __init__(
        self,
        cfg: EvaluationConfig,
        interactions: InteractionData,
        item_features: Optional[sp.csr_matrix] = None,
        item_price: Optional[np.ndarray] = None,
    ) -> None:
        self.cfg = cfg
        self.interactions = interactions
        self.item_features = item_features
        self.item_price = (
            item_price
            if item_price is not None
            else np.ones(interactions.n_items, dtype=np.float64)
        )
        self.max_cutoff = max(cfg.cutoffs)

        # The "obvious" set used by serendipity must be exactly what a
        # non-personalised baseline would surface, otherwise the baseline
        # scores non-zero serendipity against its own definition. The
        # popularity ranker shows the globally top-``max_cutoff`` items to
        # every user, minus whatever each user has already bought; the union
        # over users is therefore the head of the popularity distribution, and
        # its size is bounded by the deepest cut-off plus the largest number of
        # seen items skipped for any single user.
        head_size = self._baseline_head_size()
        self.popular_items = np.argsort(-interactions.item_popularity)[:head_size]
        logger.debug(
            "  serendipity 'obvious' head: %d items (baseline exposure).", head_size
        )

    def _baseline_head_size(self) -> int:
        """Number of distinct items a popularity baseline can ever expose.

        Ranking by static popularity and dropping already-purchased items, a
        user sees the top ``max_cutoff`` items not in their own history. The
        union across users is the top ``max_cutoff + max_seen_prefix`` items,
        where ``max_seen_prefix`` is the largest count of head items any single
        user has already bought.
        """
        order = np.argsort(-self.interactions.item_popularity)
        rank_of_item = np.empty_like(order)
        rank_of_item[order] = np.arange(order.size)

        deepest = 0
        binary = self.interactions.binary
        for user_idx in range(self.interactions.n_users):
            seen = binary.indices[binary.indptr[user_idx] : binary.indptr[user_idx + 1]]
            if seen.size == 0:
                continue
            # How far down the popularity order must we go to find max_cutoff
            # items this user has not seen?
            seen_ranks = np.sort(rank_of_item[seen])
            depth = self.max_cutoff
            for r in seen_ranks:
                if r < depth:
                    depth += 1
                else:
                    break
            deepest = max(deepest, depth)
        return int(min(max(deepest, self.max_cutoff), self.interactions.n_items))

    # ------------------------------------------------------------------- API
    def evaluate(
        self,
        model: Recommender,
        ground_truth: Dict[int, np.ndarray],
        seed: int = 42,
    ) -> EvaluationResult:
        """Score ``model`` against the held-out ground truth."""
        start = time.perf_counter()
        users = self._select_users(ground_truth, seed)
        if not users:
            logger.warning("No evaluable users for model '%s'.", model.name)
            return EvaluationResult(model.name, {}, {}, 0, 0.0)

        per_user: Dict[str, List[float]] = {}
        all_recommendations: List[np.ndarray] = []
        exposure = np.zeros(self.interactions.n_items, dtype=np.float64)

        reporter = ProgressReporter(len(users), f"eval[{model.name}]", logger, 5.0)
        # Users are scored in blocks through ``score_batch`` so that models with
        # a natural matrix form (EASE, iALS, BPR, content) amortise one BLAS
        # call over many users instead of paying per-user memory traffic. The
        # default ``score_batch`` falls back to a loop, so every model works.
        for block_start in range(0, len(users), self.USER_BLOCK):
            block = users[block_start : block_start + self.USER_BLOCK]
            score_block = np.asarray(model.score_batch(block), dtype=np.float64)
            if score_block.shape != (len(block), self.interactions.n_items):
                raise ValueError(
                    f"Model '{model.name}' score_batch returned "
                    f"{score_block.shape}; expected "
                    f"{(len(block), self.interactions.n_items)}."
                )

            for row, user_idx in enumerate(block):
                relevant = ground_truth[user_idx]
                scores = score_block[row]
                if self.cfg.exclude_seen:
                    seen = self.interactions.seen_items(user_idx)
                    if seen.size:
                        scores = scores.copy()
                        scores[seen] = -np.inf
                recommended = top_n_from_scores(scores, self.max_cutoff)

                all_recommendations.append(recommended)
                if recommended.size:
                    exposure[recommended[: self.cfg.primary_cutoff]] += 1.0

                for k in self.cfg.cutoffs:
                    self._score_one(per_user, recommended, relevant, k)
                reporter.update(1)
        reporter.close()

        aggregate = {
            name: float(np.mean(values)) for name, values in per_user.items()
        }
        aggregate.update(self._aggregate_only(all_recommendations, exposure))

        elapsed = time.perf_counter() - start
        result = EvaluationResult(
            model_name=model.name,
            aggregate=aggregate,
            per_user={k: np.asarray(v, dtype=np.float64) for k, v in per_user.items()},
            n_users_evaluated=len(users),
            elapsed_seconds=elapsed,
        )
        logger.info("  %s  [%.1f s]", result.summary(self.cfg.primary_cutoff), elapsed)
        return result

    def evaluate_all(
        self,
        models: Dict[str, Recommender],
        ground_truth: Dict[int, np.ndarray],
        seed: int = 42,
    ) -> Dict[str, EvaluationResult]:
        results: Dict[str, EvaluationResult] = {}
        for name, model in models.items():
            logger.info("Evaluating model '%s' …", name)
            results[name] = self.evaluate(model, ground_truth, seed=seed)
        return results

    # -------------------------------------------------------------- internals
    def _select_users(
        self, ground_truth: Dict[int, np.ndarray], seed: int
    ) -> List[int]:
        """Deterministically sample the evaluated user population.

        Sampling is seeded and sorted so that *every* model is evaluated on
        exactly the same users — a precondition for the paired significance
        tests applied downstream.
        """
        users = sorted(u for u, items in ground_truth.items() if items.size > 0)
        cap = self.cfg.max_eval_users
        if cap is not None and len(users) > cap:
            rng = np.random.default_rng(seed)
            users = sorted(rng.choice(users, size=cap, replace=False).tolist())
            logger.info("  evaluating a seeded sample of %d users.", len(users))
        return users

    def _score_one(
        self,
        per_user: Dict[str, List[float]],
        recommended: np.ndarray,
        relevant: np.ndarray,
        k: int,
    ) -> None:
        """Compute every per-user metric at cut-off ``k``."""
        add = lambda name, value: per_user.setdefault(f"{name}@{k}", []).append(value)

        add("precision", M.precision_at_k(recommended, relevant, k))
        add("recall", M.recall_at_k(recommended, relevant, k))
        add("f1", M.f1_at_k(recommended, relevant, k))
        add("hit_rate", M.hit_rate_at_k(recommended, relevant, k))
        add("map", M.average_precision_at_k(recommended, relevant, k))
        add("mrr", M.reciprocal_rank_at_k(recommended, relevant, k))
        add("ndcg", M.ndcg_at_k(recommended, relevant, k))

        add(
            "novelty",
            M.novelty_at_k(
                recommended,
                self.interactions.item_popularity,
                self.interactions.n_users,
                k,
            ),
        )
        add("diversity", M.intra_list_diversity(recommended, self.item_features, k))
        add(
            "serendipity",
            M.serendipity_at_k(recommended, relevant, self.popular_items, k),
        )
        add(
            "popularity_bias",
            M.popularity_bias_at_k(recommended, self.interactions.item_popularity, k),
        )
        add(
            "expected_revenue",
            M.expected_revenue_at_k(recommended, relevant, self.item_price, k),
        )

    def _aggregate_only(
        self, all_recommendations: Sequence[np.ndarray], exposure: np.ndarray
    ) -> Dict[str, float]:
        """Catalogue-level metrics that have no per-user counterpart."""
        out: Dict[str, float] = {}
        for k in self.cfg.cutoffs:
            out[f"coverage@{k}"] = M.catalogue_coverage(
                all_recommendations, self.interactions.n_items, k
            )
        out["exposure_gini"] = M.gini_index(exposure)
        out["exposure_entropy"] = M.shannon_entropy(exposure)
        out["exposed_items"] = float((exposure > 0).sum())
        return out


def results_to_frame(results: Dict[str, EvaluationResult]) -> pd.DataFrame:
    """Assemble a model × metric comparison table."""
    frame = pd.DataFrame({name: r.to_series() for name, r in results.items()}).T
    frame.index.name = "model"
    return frame
