"""Ranking, beyond-accuracy and business metrics.

The evaluation framework of this thesis is deliberately three-dimensional,
because a recommender optimised on accuracy alone tends to degenerate into a
popularity ranker: it maximises the probability of a hit while narrowing
catalogue exposure, suppressing discovery and eroding the long-tail revenue that
motivates personalization in the first place (Kaminskas & Bridge, 2017;
Castells et al., 2015).

Axis 1 — accuracy
    ``precision@k``, ``recall@k``, ``f1@k``, ``hit_rate@k``, ``map@k``,
    ``mrr@k``, ``ndcg@k``.

Axis 2 — beyond accuracy
    ``coverage@k`` (catalogue exposure), ``gini@k`` (equality of exposure),
    ``novelty@k`` (mean self-information), ``diversity@k`` (intra-list
    dissimilarity), ``serendipity@k`` (relevant *and* unexpected),
    ``popularity_bias@k`` (mean normalised popularity of recommended items).

Axis 3 — business value
    ``expected_revenue@k``, ``expected_margin@k``, ``arpu@k``.

All per-user functions return a scalar for a single ranked list, so the evaluator
can retain per-user vectors for the paired significance tests of
:mod:`recsys.evaluation.statistics`. Aggregation is always the arithmetic mean
over evaluated users — the *macro* average — because a micro average would let a
handful of wholesale buyers with hundreds of test purchases dominate the score.
"""

from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np
import scipy.sparse as sp

__all__ = [
    "precision_at_k",
    "recall_at_k",
    "f1_at_k",
    "hit_rate_at_k",
    "average_precision_at_k",
    "reciprocal_rank_at_k",
    "ndcg_at_k",
    "novelty_at_k",
    "intra_list_diversity",
    "serendipity_at_k",
    "popularity_bias_at_k",
    "expected_revenue_at_k",
    "catalogue_coverage",
    "gini_index",
    "shannon_entropy",
    "ACCURACY_METRICS",
    "BEYOND_ACCURACY_METRICS",
    "BUSINESS_METRICS",
]

ACCURACY_METRICS = (
    "precision", "recall", "f1", "hit_rate", "map", "mrr", "ndcg",
)
BEYOND_ACCURACY_METRICS = (
    "novelty", "diversity", "serendipity", "popularity_bias",
)
BUSINESS_METRICS = ("expected_revenue", "expected_margin")


# ===========================================================================
# Axis 1 — accuracy
# ===========================================================================
def precision_at_k(recommended: np.ndarray, relevant: np.ndarray, k: int) -> float:
    """Fraction of the top-k that is relevant.

    Precision is the metric that most directly maps onto the opportunity cost of
    a recommendation slot: with a fixed carousel of k positions, precision is
    the expected proportion of slots that produce value.
    """
    if k <= 0 or recommended.size == 0:
        return 0.0
    top = recommended[:k]
    hits = np.isin(top, relevant).sum()
    return float(hits) / float(k)


def recall_at_k(recommended: np.ndarray, relevant: np.ndarray, k: int) -> float:
    """Fraction of the relevant set retrieved within the top-k."""
    if relevant.size == 0:
        return 0.0
    top = recommended[:k]
    hits = np.isin(top, relevant).sum()
    return float(hits) / float(relevant.size)


def f1_at_k(recommended: np.ndarray, relevant: np.ndarray, k: int) -> float:
    """Harmonic mean of precision and recall at k."""
    p = precision_at_k(recommended, relevant, k)
    r = recall_at_k(recommended, relevant, k)
    return 0.0 if (p + r) == 0 else 2.0 * p * r / (p + r)


def hit_rate_at_k(recommended: np.ndarray, relevant: np.ndarray, k: int) -> float:
    """1 if at least one relevant item appears in the top-k, else 0.

    The binary variant answers the question a product manager actually asks:
    *did the module work at all for this session?*
    """
    if relevant.size == 0 or recommended.size == 0:
        return 0.0
    return 1.0 if np.isin(recommended[:k], relevant).any() else 0.0


def average_precision_at_k(
    recommended: np.ndarray, relevant: np.ndarray, k: int
) -> float:
    """Average of the precisions computed at each relevant hit position.

    AP rewards placing relevant items early and is the per-user term whose mean
    is Mean Average Precision (MAP).
    """
    if relevant.size == 0 or recommended.size == 0:
        return 0.0
    top = recommended[:k]
    hits = np.isin(top, relevant)
    if not hits.any():
        return 0.0
    positions = np.arange(1, top.size + 1)
    cumulative_precision = np.cumsum(hits) / positions
    return float(np.sum(cumulative_precision * hits) / min(relevant.size, k))


def reciprocal_rank_at_k(
    recommended: np.ndarray, relevant: np.ndarray, k: int
) -> float:
    """Inverse of the rank of the first relevant item (0 if none in top-k)."""
    if relevant.size == 0 or recommended.size == 0:
        return 0.0
    top = recommended[:k]
    hits = np.flatnonzero(np.isin(top, relevant))
    return 0.0 if hits.size == 0 else 1.0 / float(hits[0] + 1)


def ndcg_at_k(recommended: np.ndarray, relevant: np.ndarray, k: int) -> float:
    """Normalised Discounted Cumulative Gain with binary relevance.

    .. math::

        \\mathrm{DCG@k} = \\sum_{j=1}^{k} \\frac{2^{g_j} - 1}{\\log_2(j + 1)}

    With binary gains this reduces to summing :math:`1 / \\log_2(j+1)` over the
    positions of relevant items. The ideal DCG normaliser assumes all relevant
    items occupy the leading positions, which bounds the metric in [0, 1] and
    makes it comparable across users with different numbers of test purchases.
    NDCG is the primary metric of this thesis because it is the only accuracy
    measure that is simultaneously graded, position-discounted and normalised.
    """
    if relevant.size == 0 or recommended.size == 0:
        return 0.0
    top = recommended[:k]
    hits = np.isin(top, relevant).astype(np.float64)
    discounts = 1.0 / np.log2(np.arange(2, top.size + 2))
    dcg = float(np.sum(hits * discounts))

    ideal_n = min(int(relevant.size), k)
    idcg = float(np.sum(1.0 / np.log2(np.arange(2, ideal_n + 2))))
    return dcg / idcg if idcg > 0 else 0.0


# ===========================================================================
# Axis 2 — beyond accuracy
# ===========================================================================
def novelty_at_k(
    recommended: np.ndarray, item_popularity: np.ndarray, n_users: int, k: int
) -> float:
    """Mean self-information (surprisal) of the recommended items.

    .. math:: \\mathrm{Novelty@k} = \\frac{1}{k}\\sum_{i \\in R_k} -\\log_2 p_i

    where :math:`p_i` is the empirical purchase probability of item *i*
    (Zhou et al., 2010; Vargas & Castells, 2011). A ranking of blockbusters has
    low novelty; recommending an item purchased by one customer in a thousand
    contributes ≈10 bits.
    """
    if recommended.size == 0 or n_users <= 0:
        return 0.0
    top = recommended[:k]
    probs = np.clip(item_popularity[top] / float(n_users), 1e-10, 1.0)
    return float(np.mean(-np.log2(probs)))


def intra_list_diversity(
    recommended: np.ndarray, item_features: Optional[sp.csr_matrix], k: int
) -> float:
    """Mean pairwise cosine *dis*similarity inside the recommended list.

    Intra-list diversity (Ziegler et al., 2005) measures whether the k slots
    carry k distinct propositions or k variations of one. Computed over the
    content feature space, which is already L2-normalised, so the cosine
    similarity is a plain dot product.
    """
    if item_features is None or recommended.size < 2:
        return 0.0
    top = recommended[:k]
    if top.size < 2:
        return 0.0
    block = item_features[top]
    similarity = np.asarray((block @ block.T).todense(), dtype=np.float64)
    n = top.size
    upper = similarity[np.triu_indices(n, k=1)]
    return float(1.0 - np.mean(upper)) if upper.size else 0.0


def serendipity_at_k(
    recommended: np.ndarray,
    relevant: np.ndarray,
    popular_items: np.ndarray,
    k: int,
) -> float:
    """Fraction of the top-k that is relevant *and* not trivially predictable.

    Following Ge, Delgado-Battenfeld and Jannach (2010), serendipity is
    relevance minus obviousness: a hit on an item the popularity baseline would
    already have surfaced carries no serendipitous value.
    """
    if recommended.size == 0 or relevant.size == 0 or k <= 0:
        return 0.0
    top = recommended[:k]
    is_relevant = np.isin(top, relevant)
    is_obvious = np.isin(top, popular_items)
    return float(np.sum(is_relevant & ~is_obvious)) / float(k)


def popularity_bias_at_k(
    recommended: np.ndarray, item_popularity: np.ndarray, k: int
) -> float:
    """Mean popularity of the recommended items, normalised by the maximum.

    High values indicate the model is exploiting the head of the distribution
    rather than personalising; this is the quantitative counterpart of the
    "filter bubble / blockbuster amplification" argument of Chapter 3.
    """
    if recommended.size == 0:
        return 0.0
    peak = float(item_popularity.max())
    if peak <= 0:
        return 0.0
    return float(np.mean(item_popularity[recommended[:k]]) / peak)


# ===========================================================================
# Axis 3 — business value
# ===========================================================================
def expected_revenue_at_k(
    recommended: np.ndarray,
    relevant: np.ndarray,
    item_price: np.ndarray,
    k: int,
    position_decay: float = 0.85,
) -> float:
    """Position-discounted monetary value of the correctly ranked items.

    Accuracy metrics treat a £0.42 greeting card and a £45 cake stand as
    equivalent successes. This metric restores the economic dimension by
    weighting each hit by its unit price and by a geometric position discount
    :math:`\\gamma^{j-1}` that models declining attention down the carousel.
    """
    if recommended.size == 0 or relevant.size == 0:
        return 0.0
    top = recommended[:k]
    hits = np.isin(top, relevant)
    if not hits.any():
        return 0.0
    positions = np.arange(top.size)
    discounts = position_decay ** positions
    return float(np.sum(item_price[top] * hits * discounts))


# ===========================================================================
# Catalogue-level (aggregate) metrics
# ===========================================================================
def catalogue_coverage(
    all_recommended: Sequence[np.ndarray], n_items: int, k: int
) -> float:
    """Share of the catalogue that appears in at least one user's top-k.

    Coverage is an aggregate rather than a per-user quantity, and it is the
    metric that most clearly exposes the failure mode of a popularity ranker:
    perfect accuracy on the head with 1% coverage means 99% of the assortment is
    commercially invisible.
    """
    if n_items <= 0:
        return 0.0
    exposed = set()
    for recommendation in all_recommended:
        exposed.update(int(i) for i in recommendation[:k])
    return len(exposed) / float(n_items)


def gini_index(exposure_counts: np.ndarray) -> float:
    """Gini coefficient of the recommendation-exposure distribution.

    ``0`` denotes perfectly equal exposure across the catalogue, ``1`` that a
    single item absorbs all impressions.
    """
    x = np.asarray(exposure_counts, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan")
    x = np.sort(x)
    n, total = x.size, x.sum()
    if total <= 0:
        return 0.0
    index = np.arange(1, n + 1, dtype=float)
    return float((2.0 * np.sum(index * x)) / (n * total) - (n + 1.0) / n)


def shannon_entropy(exposure_counts: np.ndarray) -> float:
    """Shannon entropy (bits) of the exposure distribution.

    Complements the Gini index: entropy is maximised by uniform exposure and is
    directly interpretable as the effective number of distinct items
    (:math:`2^H`) that the system surfaces.
    """
    x = np.asarray(exposure_counts, dtype=float)
    total = x.sum()
    if total <= 0:
        return 0.0
    p = x[x > 0] / total
    return float(-np.sum(p * np.log2(p)))
