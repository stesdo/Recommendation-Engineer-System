"""Statistical inference for paired comparisons.

A ranking of model means carries no measure of uncertainty. This module
implements the analysis that upgrades descriptive comparison into statistical
inference:

1. **Wilcoxon signed-rank test** (Wilcoxon, 1945; Demšar, 2006) — the
   non-parametric paired test recommended for recommender-system evaluation
   because metric differences are rarely normally distributed. The test
   statistic and p-value are reported for every pair of models.

2. **Paired bootstrap confidence interval** (Efron & Tibshirani, 1994) — a
   computationally intensive but distribution-free interval for the mean
   difference between two models, resampling users with replacement.

3. **Holm–Bonferroni correction** (Holm, 1979) — when testing K models, the
   number of pairwise comparisons is K(K−1)/2. A naive α = 0.05 would produce
   a family-wise error rate of roughly 1 − 0.95^{#pairs} ≈ 0.7 for seven
   models. The step-down procedure controls the FWER at α while maintaining
   higher power than the conservative Bonferroni correction.

All computations use ``float64`` throughout, and the random seed is fixed, so
results are deterministic and reproducible.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
import pandas as pd
from scipy.stats import norm, rankdata, wilcoxon

from recsys.config import StatisticsConfig
from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = [
    "PairwiseComparison",
    "StatisticalReport",
    "significance_matrix",
    "compare_models",
    "paired_bootstrap_ci",
    "holm_correction",
    "bonferroni_correction",
    "critical_difference",
]


@dataclass
class PairwiseComparison:
    model_a: str
    model_b: str
    metric: str
    mean_a: float
    mean_b: float
    delta: float                     # mean_b − mean_a
    rel_delta_pct: float
    statistic: float
    p_value_raw: float
    p_value_corrected: float
    significant: bool
    ci_low: float
    ci_high: float
    n_pairs: int


@dataclass
class StatisticalReport:
    comparisons: List[PairwiseComparison] = field(default_factory=list)
    n_users: int = 0
    alpha: float = 0.05

    def significant_pairs(self) -> List[PairwiseComparison]:
        return [c for c in self.comparisons if c.significant]

    def summary_frame(self) -> pd.DataFrame:
        rows = [
            {
                "comparison": f"{c.model_a} vs {c.model_b}",
                "metric": c.metric,
                "mean_a": c.mean_a,
                "mean_b": c.mean_b,
                "delta": c.delta,
                "p_value": c.p_value_corrected,
                "significant": c.significant,
                "ci_low": c.ci_low,
                "ci_high": c.ci_high,
            }
            for c in self.comparisons
        ]
        return pd.DataFrame(rows)

    def format_markdown(self) -> str:
        """Formatted for direct inclusion in thesis §6.3."""
        from io import StringIO

        df = self.summary_frame()
        lines = [
            f"| Comparison | Metric | Δ | p (corr.) | 95% CI |",
            "|------------|--------|---|-----------|--------|",
        ]
        for c in self.comparisons:
            sig = "✓" if c.significant else ""
            lines.append(
                f"| {c.model_a} vs {c.model_b} | {c.metric} | "
                f"{c.delta:+.4f} | {c.p_value_corrected:.4f} {sig} | "
                f"[{c.ci_low:+.4f}, {c.ci_high:+.4f}] |"
            )
        return "\n".join(lines)


# ---------------------------------------------------------------------------
def significance_matrix(
    results: Dict[str, Dict[str, np.ndarray]], metric: str
) -> pd.DataFrame:
    """Symmetric matrix of raw p-values for a single metric."""
    names = sorted(results.keys())
    n = len(names)
    mat = np.ones((n, n), dtype=np.float64)
    for i in range(n):
        for j in range(n):
            if i == j:
                continue
            va, vb = results[names[i]][metric], results[names[j]][metric]
            mask = np.isfinite(va) & np.isfinite(vb)
            if mask.sum() < 5:
                mat[i, j] = np.nan
                continue
            try:
                _, p = wilcoxon(va[mask], vb[mask], zero_method="zsplit", alternative="two-sided")
                mat[i, j] = float(p)
            except Exception:
                mat[i, j] = np.nan
    return pd.DataFrame(mat, index=names, columns=names)


# ---------------------------------------------------------------------------
def compare_models(
    per_user: Dict[str, Dict[str, np.ndarray]],
    metric: str,
    cfg: StatisticsConfig,
) -> StatisticalReport:
    """Run the full pairwise comparison protocol for one metric.

    Parameters
    ----------
    per_user:
        ``{model_name → {metric_name → vector_of_user_scores}}``
    metric:
        The specific metric key (e.g. ``"ndcg@10"``) to compare.
    cfg:
        Statistical configuration (α, bootstrap iterations, correction method).
    """
    names = sorted(per_user.keys())
    comparisons: List[PairwiseComparison] = []

    for i in range(len(names)):
        for j in range(len(names)):
            if i >= j:
                continue
            a, b = names[i], names[j]
            va = per_user[a].get(metric, np.zeros(0))
            vb = per_user[b].get(metric, np.zeros(0))
            common = np.isfinite(va) & np.isfinite(vb)
            va, vb = va[common], vb[common]

            if va.size < 5:
                logger.debug("  skipping '%s' vs '%s': < 5 paired observations.", a, b)
                comparisons.append(
                    PairwiseComparison(
                        a, b, metric, float("nan"), float("nan"),
                        float("nan"), float("nan"), float("nan"),
                        float("nan"), 1.0, False,
                        float("nan"), float("nan"), int(va.size),
                    )
                )
                continue

            mean_a, mean_b = float(np.mean(va)), float(np.mean(vb))
            delta = mean_b - mean_a

            try:
                stat, p_raw = wilcoxon(
                    vb, va, zero_method="zsplit", alternative="two-sided"
                )
            except Exception:
                stat, p_raw = 0.0, 1.0

            ci_low, ci_high = paired_bootstrap_ci(
                va, vb, cfg.bootstrap_iterations, cfg.alpha
            )

            rel = 100.0 * delta / abs(mean_a) if abs(mean_a) > 1e-12 else 0.0
            comparisons.append(
                PairwiseComparison(
                    a, b, metric, mean_a, mean_b, delta, rel,
                    float(stat), float(p_raw), float(p_raw),  # corrected filled below
                    False, ci_low, ci_high, int(va.size),
                )
            )

    # Apply multiplicity correction over all comparisons for this metric.
    # Each branch must honour the configured method exactly: silently
    # substituting one correction for another would misreport the inference.
    if cfg.correction in ("holm", "bonferroni"):
        comps = [c for c in comparisons if not np.isnan(c.p_value_raw)]
        raw = np.array([c.p_value_raw for c in comps])
        if cfg.correction == "bonferroni":
            corrected = bonferroni_correction(raw)
        else:
            corrected = holm_correction(raw)
        for c, pc in zip(comps, corrected):
            c.p_value_corrected = float(pc)
            c.significant = bool(pc < cfg.alpha)
        for c in comparisons:
            if np.isnan(c.p_value_raw):
                c.p_value_corrected = 1.0
                c.significant = False
    else:
        # correction == "none": report the uncorrected p-value and judge
        # significance directly against α.
        for c in comparisons:
            if np.isnan(c.p_value_raw):
                c.p_value_corrected = 1.0
                c.significant = False
            else:
                c.p_value_corrected = float(c.p_value_raw)
                c.significant = bool(c.p_value_raw < cfg.alpha)

    return StatisticalReport(comparisons, n_users=int(va.size) if 'va' in locals() else 0, alpha=cfg.alpha)


# ---------------------------------------------------------------------------
def paired_bootstrap_ci(
    a: np.ndarray, b: np.ndarray, iterations: int, alpha: float
) -> Tuple[float, float]:
    """Bootstrap confidence interval for the mean paired difference b − a.

    Resamples indices with replacement, computes the mean difference on each
    resample, and returns the percentile interval at the (1 − α) level.
    """
    n = a.size
    if n < 2:
        return float("nan"), float("nan")
    rng = np.random.default_rng(42)
    diffs = np.empty(min(iterations, 5000), dtype=np.float64)
    for i in range(diffs.size):
        idx = rng.integers(0, n, size=n)
        diffs[i] = np.mean(b[idx] - a[idx], dtype=np.float64)
    low = np.percentile(diffs, 100.0 * alpha / 2.0)
    high = np.percentile(diffs, 100.0 * (1.0 - alpha / 2.0))
    return float(low), float(high)


# ---------------------------------------------------------------------------
# multiplicity correction
# ---------------------------------------------------------------------------
def bonferroni_correction(p_values: np.ndarray) -> np.ndarray:
    """Classical Bonferroni multiplicity correction.

    Multiplies every p-value by the number of hypotheses m and clips at 1:
    :math:`\\tilde p_j = \\min(1, m\\,p_j)`. Uniformly at least as conservative
    as Holm–Bonferroni, which is why ``holm`` is the default; it is retained so
    that the more conservative bound can be requested explicitly.
    """
    n = len(p_values)
    if n == 0:
        return p_values
    return np.minimum(1.0, np.asarray(p_values, dtype=np.float64) * float(n))


def holm_correction(p_values: np.ndarray) -> np.ndarray:
    """Holm–Bonferroni step-down multiplicity correction.

    Given m null hypotheses with p-values :math:`p_{(1)} \\le p_{(2)} \\le ... \\le p_{(m)}`,
    reject :math:`H_0^{(j)}` if :math:`p_{(j)} \\le \\alpha / (m - j + 1)`. The
    *corrected* p-value for rank j is :math:`\\min(1, \\max_{k \\le j} p_{(k)} (m − k + 1))`.
    """
    n = len(p_values)
    if n == 0:
        return p_values
    order = np.argsort(p_values)
    ranks = np.empty(n, dtype=np.float64)
    ranks[order] = np.arange(1, n + 1, dtype=np.float64)
    corrected = np.minimum(1.0, p_values * (n - ranks + 1.0))
    cummax = np.maximum.accumulate(corrected[order])
    result = np.empty(n, dtype=np.float64)
    result[order] = np.minimum(cummax, 1.0)
    return result


# ---------------------------------------------------------------------------
# critical-difference diagram (Demšar, 2006)
# ---------------------------------------------------------------------------
def critical_difference(n_models: int, n_datasets: int, alpha: float = 0.05) -> float:
    """Critical difference for the Nemenyi post-hoc test.

    Used to generate the CD diagram in thesis §6.3. ``n_datasets`` is the number
    of observably independent measurements — in our case the number of evaluated
    users.

    Note the ``/ sqrt(2)``: Demšar (2006) tabulates :math:`q_\\alpha` as the
    studentized-range quantile *divided by* :math:`\\sqrt 2` (for k = 2 and
    α = 0.05, :math:`q_\\alpha = 1.960 = 2.772/\\sqrt 2`). Omitting it inflates
    every critical difference by a factor of 1.414.
    """
    from scipy.stats import studentized_range

    q_alpha = studentized_range.ppf(1.0 - alpha, n_models, np.inf) / np.sqrt(2.0)
    return float(q_alpha * np.sqrt(n_models * (n_models + 1.0) / (6.0 * n_datasets)))


def average_ranks(
    per_user: Dict[str, Dict[str, np.ndarray]], metric: str
) -> pd.DataFrame:
    """Compute the average rank of each model across users for a given metric.

    At each user, models are ranked from best to worst; the mean of those ranks
    is the preferred quantity for the Nemenyi test.
    """
    models = sorted(per_user.keys())
    n_users = next(iter(per_user.values()))[metric].size if per_user else 0
    ranks = np.full((n_users, len(models)), np.nan, dtype=np.float64)

    for u in range(n_users):
        scores = np.array(
            [per_user[m][metric][u] for m in models], dtype=np.float64
        )
        valid = np.isfinite(scores)
        ranks[u, valid] = len(models) - rankdata(scores[valid], method="average") + 1.0

    avg = pd.DataFrame(
        {"model": models, "avg_rank": np.nanmean(ranks, axis=0)}
    ).sort_values("avg_rank")
    avg["avg_rank"] = avg["avg_rank"].round(3)
    return avg.set_index("model")
