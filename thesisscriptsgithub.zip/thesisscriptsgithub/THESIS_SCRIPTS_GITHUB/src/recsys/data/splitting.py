"""Temporally consistent train/validation/test partitioning.

Offline evaluation of recommender systems is notoriously easy to get wrong. The
dominant error in the applied literature is *temporal leakage*: partitioning
interactions at random, so that the model is trained on events that occur after
the events it is asked to predict. Because purchasing behaviour is strongly
non-stationary (seasonality, product life-cycles, fashion), random splits inflate
accuracy by a factor that has been reported to exceed two (Ji et al., 2020;
Meng et al., 2020).

This module therefore implements only *causally admissible* protocols:

``temporal_global``
    A single global timestamp τ separates past from future. Everything before τ
    is training data; everything after is the test set. This is the protocol
    that most closely mirrors a production deployment, where a model trained on
    the history of the whole customer base is used to serve the next period.

``leave_last_out``
    Each user's chronologically last interaction is held out. This yields a
    balanced test load across users but leaks *relative* future information
    (user A's held-out event may precede user B's training events). It is
    retained as a secondary protocol for comparability with the literature.

Both protocols yield a :class:`DataSplit` that additionally carries dense index
mappings, since all downstream linear algebra operates on contiguous integer
identifiers rather than raw customer/stock codes.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Optional

import numpy as np
import pandas as pd

from recsys.config import SplittingConfig
from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = ["DataSplit", "TemporalSplitter"]


@dataclass
class DataSplit:
    """Result of a partitioning operation.

    Attributes
    ----------
    train, validation, test:
        Transaction-level frames carrying dense ``user_idx``/``item_idx`` columns.
    user_map, item_map:
        Raw identifier → dense index.
    user_ids, item_ids:
        Dense index → raw identifier (inverse of the maps above).
    split_time:
        The global boundary timestamp (``None`` for ``leave_last_out``).
    """

    train: pd.DataFrame
    validation: pd.DataFrame
    test: pd.DataFrame
    user_map: Dict[int, int]
    item_map: Dict[str, int]
    user_ids: np.ndarray
    item_ids: np.ndarray
    split_time: Optional[pd.Timestamp]
    strategy: str

    @property
    def n_users(self) -> int:
        return len(self.user_ids)

    @property
    def n_items(self) -> int:
        return len(self.item_ids)

    def test_ground_truth(self, exclude_seen: bool = True) -> Dict[int, np.ndarray]:
        """Map ``user_idx → array of relevant item_idx`` for the test period.

        When ``exclude_seen`` is true (the default, and the setting that matches
        ``evaluation.exclude_seen``) items the user already bought during
        training are removed from the ground truth. This is not cosmetic: the
        ranking layer masks already-purchased items out of the candidate set, so
        retaining them here would leave targets that *no* model can return,
        depressing recall and NDCG by a user-dependent amount and putting the
        metrics on a scale whose maximum is below 1. Excluding them makes the
        task "predict the next *new* article", which is what the ranker is
        actually asked to do, and restores a genuine [0, 1] range.
        """
        if self.test.empty:
            return {}
        grouped = self.test.groupby("user_idx")["item_idx"].unique()
        truth = {int(u): np.asarray(v, dtype=np.int32) for u, v in grouped.items()}
        if not exclude_seen:
            return truth

        seen = self.train_seen_items()
        filtered: Dict[int, np.ndarray] = {}
        for user_idx, items in truth.items():
            already = seen.get(user_idx)
            if already is not None and already.size:
                items = np.setdiff1d(items, already, assume_unique=False)
            if items.size:
                filtered[user_idx] = items.astype(np.int32)
        return filtered

    def train_seen_items(self) -> Dict[int, np.ndarray]:
        """Map ``user_idx → array of item_idx already purchased in training``."""
        grouped = self.train.groupby("user_idx")["item_idx"].unique()
        return {int(u): np.asarray(v, dtype=np.int32) for u, v in grouped.items()}

    def summary(self) -> str:
        return (
            f"strategy={self.strategy} users={self.n_users:,} items={self.n_items:,} "
            f"train={len(self.train):,} val={len(self.validation):,} "
            f"test={len(self.test):,}"
            + (f" τ={self.split_time:%Y-%m-%d}" if self.split_time is not None else "")
        )


class TemporalSplitter:
    """Construct causally admissible partitions of the interaction log."""

    def __init__(self, cfg: SplittingConfig) -> None:
        self.cfg = cfg

    # ------------------------------------------------------------------- API
    def split(self, df: pd.DataFrame) -> DataSplit:
        if df.empty:
            raise ValueError("Cannot split an empty interaction log.")
        df = df.sort_values("invoice_date", kind="mergesort").reset_index(drop=True)

        if self.cfg.strategy == "temporal_global":
            train, validation, test = self._temporal_global(df)
        else:
            train, validation, test = self._leave_last_out(df)

        # The vocabulary is defined by the TRAINING partition alone: an item or
        # user unseen during training cannot be represented by a collaborative
        # model, and silently admitting them would corrupt the index space.
        user_ids = np.sort(train["customer_id"].unique())
        item_ids = np.sort(train["stock_code"].unique())
        user_map = {int(u): i for i, u in enumerate(user_ids)}
        item_map = {str(s): i for i, s in enumerate(item_ids)}

        train = self._densify(train, user_map, item_map)
        validation = self._densify(validation, user_map, item_map)
        test = self._densify(test, user_map, item_map)

        # Evaluation is restricted to users with enough training signal.
        min_n = self.cfg.min_train_interactions_for_eval
        if min_n > 1 and not test.empty:
            degree = train.groupby("user_idx")["item_idx"].nunique()
            eligible = set(degree[degree >= min_n].index.astype(int))
            before = test["user_idx"].nunique()
            test = test.loc[test["user_idx"].isin(eligible)]
            logger.info(
                "Evaluable users: %d → %d (require ≥%d training interactions).",
                before,
                test["user_idx"].nunique(),
                min_n,
            )

        split_time = (
            pd.Timestamp(train["invoice_date"].max())
            if self.cfg.strategy == "temporal_global"
            else None
        )
        result = DataSplit(
            train=train,
            validation=validation,
            test=test,
            user_map=user_map,
            item_map=item_map,
            user_ids=user_ids,
            item_ids=item_ids,
            split_time=split_time,
            strategy=self.cfg.strategy,
        )
        logger.info("Split — %s", result.summary())
        return result

    # -------------------------------------------------------------- protocols
    def _temporal_global(self, df: pd.DataFrame):
        """Split on two global quantiles of the timestamp distribution."""
        cfg = self.cfg
        times = df["invoice_date"]
        test_start = times.quantile(1.0 - cfg.test_ratio)
        val_start = times.quantile(1.0 - cfg.test_ratio - cfg.validation_ratio)

        train = df.loc[times < val_start]
        validation = df.loc[(times >= val_start) & (times < test_start)]
        test = df.loc[times >= test_start]

        logger.info(
            "Temporal boundaries — train < %s ≤ val < %s ≤ test",
            f"{val_start:%Y-%m-%d}",
            f"{test_start:%Y-%m-%d}",
        )
        return train, validation, test

    def _leave_last_out(self, df: pd.DataFrame):
        """Hold out each user's last (and second-to-last) interaction."""
        df = df.copy()
        df["_rank_desc"] = (
            df.groupby("customer_id")["invoice_date"]
            .rank(method="first", ascending=False)
            .astype(int)
        )
        test = df.loc[df["_rank_desc"] == 1]
        validation = df.loc[df["_rank_desc"] == 2]
        train = df.loc[df["_rank_desc"] > 2]
        drop = ["_rank_desc"]
        return train.drop(columns=drop), validation.drop(columns=drop), test.drop(columns=drop)

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def _densify(
        df: pd.DataFrame, user_map: Dict[int, int], item_map: Dict[str, int]
    ) -> pd.DataFrame:
        """Attach dense indices, discarding out-of-vocabulary rows."""
        if df.empty:
            out = df.copy()
            out["user_idx"] = pd.Series(dtype=np.int32)
            out["item_idx"] = pd.Series(dtype=np.int32)
            return out
        out = df.copy()
        out["user_idx"] = out["customer_id"].map(user_map)
        out["item_idx"] = out["stock_code"].map(item_map)
        before = len(out)
        out = out.dropna(subset=["user_idx", "item_idx"])
        if before != len(out):
            logger.debug(
                "  discarded %d out-of-vocabulary rows during densification.",
                before - len(out),
            )
        out["user_idx"] = out["user_idx"].astype(np.int32)
        out["item_idx"] = out["item_idx"].astype(np.int32)
        return out.reset_index(drop=True)
