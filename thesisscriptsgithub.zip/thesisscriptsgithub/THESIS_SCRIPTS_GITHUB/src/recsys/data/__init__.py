"""Data acquisition, cleaning and partitioning layer."""

from __future__ import annotations

from recsys.data.loader import CANONICAL_COLUMNS, DataLoader, RawDataset
from recsys.data.preprocessing import (
    CleaningReport,
    TransactionCleaner,
    compute_dataset_statistics,
    gini_coefficient,
)
from recsys.data.splitting import DataSplit, TemporalSplitter

__all__ = [
    "DataLoader",
    "RawDataset",
    "CANONICAL_COLUMNS",
    "TransactionCleaner",
    "CleaningReport",
    "compute_dataset_statistics",
    "gini_coefficient",
    "TemporalSplitter",
    "DataSplit",
]
