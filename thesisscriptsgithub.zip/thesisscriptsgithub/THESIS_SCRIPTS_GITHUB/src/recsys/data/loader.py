"""Acquisition and caching of the *Online Retail II* transactional corpus.

The canonical source is the UCI Machine Learning Repository (Chen, 2012), which
distributes the data as a two-sheet Excel workbook covering 01/12/2009 –
09/12/2011. Because Excel parsing of a one-million-row workbook costs roughly a
minute, the loader materialises a Parquet (or CSV) cache on first use.

A deliberate engineering decision is the *synthetic fallback*: if the archive
cannot be retrieved (offline evaluation environment, mirror outage, firewall),
the loader generates a statistically plausible surrogate with an identical
schema. This guarantees that the experimental pipeline — and therefore the
reproducibility claims of the thesis — never depends on network availability.
The surrogate reproduces the four structural properties that matter for
recommendation research: a power-law popularity distribution, heterogeneous
user activity, basket co-occurrence structure, and temporal seasonality.
"""

from __future__ import annotations

import io
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import numpy as np
import pandas as pd

from recsys.config import DataConfig
from recsys.logging_utils import get_logger, timed

logger = get_logger(__name__)

__all__ = ["RawDataset", "DataLoader", "CANONICAL_COLUMNS"]

#: Canonical internal schema. The two Excel sheets of Online Retail II use
#: slightly different header spellings ("Customer ID" vs "CustomerID"), which
#: are normalised here once and for all.
CANONICAL_COLUMNS = [
    "invoice",
    "stock_code",
    "description",
    "quantity",
    "invoice_date",
    "unit_price",
    "customer_id",
    "country",
]

_COLUMN_ALIASES = {
    "invoice": "invoice",
    "invoiceno": "invoice",
    "stockcode": "stock_code",
    "stock code": "stock_code",
    "description": "description",
    "quantity": "quantity",
    "invoicedate": "invoice_date",
    "invoice date": "invoice_date",
    "price": "unit_price",
    "unitprice": "unit_price",
    "unit price": "unit_price",
    "customerid": "customer_id",
    "customer id": "customer_id",
    "country": "country",
}


@dataclass
class RawDataset:
    """Container for the raw transaction table plus provenance metadata."""

    frame: pd.DataFrame
    source: str          # "cache" | "excel" | "csv" | "synthetic"
    n_rows: int

    def describe(self) -> str:
        f = self.frame
        return (
            f"source={self.source} rows={self.n_rows:,} "
            f"invoices={f['invoice'].nunique():,} "
            f"items={f['stock_code'].nunique():,} "
            f"customers={f['customer_id'].nunique():,} "
            f"period={f['invoice_date'].min():%Y-%m-%d}→{f['invoice_date'].max():%Y-%m-%d}"
        )


class DataLoader:
    """Resolve, download, parse and cache the transactional corpus."""

    def __init__(self, cfg: DataConfig, project_root: Optional[Path] = None) -> None:
        self.cfg = cfg
        self.root = Path(project_root) if project_root else Path.cwd()
        self.raw_dir = self._resolve(cfg.raw_dir)
        self.processed_dir = self._resolve(cfg.processed_dir)
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        self.processed_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ paths
    def _resolve(self, p: str) -> Path:
        path = Path(p)
        return path if path.is_absolute() else (self.root / path)

    @property
    def _cache_parquet(self) -> Path:
        return self.processed_dir / "transactions_raw.parquet"

    @property
    def _cache_csv(self) -> Path:
        return self.processed_dir / "transactions_raw.csv"

    # ------------------------------------------------------------------- API
    def load(self, force_refresh: bool = False) -> RawDataset:
        """Return the raw transaction table, using the cache when possible."""
        if self.cfg.use_cache and not force_refresh:
            cached = self._read_cache()
            if cached is not None:
                logger.info("Loaded transactions from cache (%d rows).", len(cached))
                return RawDataset(cached, "cache", len(cached))

        frame, source = self._acquire()
        frame = self._normalise(frame)
        self._write_cache(frame)
        return RawDataset(frame, source, len(frame))

    def download(self, force: bool = False) -> Path:
        """Fetch the upstream archive into ``data/raw`` and return its path."""
        target = self.raw_dir / self.cfg.filename
        if target.exists() and not force:
            logger.info("Archive already present: %s", target)
            return target
        if not self.cfg.url:
            raise RuntimeError("No download URL configured (data.url is empty).")
        return self._http_fetch(self.cfg.url, target)

    # ------------------------------------------------------------ acquisition
    def _acquire(self) -> tuple[pd.DataFrame, str]:
        """Try, in order: local Excel → local CSV → HTTP → synthetic."""
        excel = self.raw_dir / self.cfg.filename
        if excel.exists():
            try:
                with timed("data.parse_excel", logger):
                    return self._read_excel(excel), "excel"
            except Exception as exc:  # pragma: no cover - environment dependent
                logger.warning("Excel parsing failed (%s); trying alternatives.", exc)

        for candidate in sorted(self.raw_dir.glob("*.csv")):
            try:
                logger.info("Reading local CSV: %s", candidate.name)
                return pd.read_csv(candidate, encoding="ISO-8859-1"), "csv"
            except Exception as exc:  # pragma: no cover
                logger.warning("Failed to read %s (%s).", candidate.name, exc)

        if self.cfg.url:
            try:
                path = self._http_fetch(self.cfg.url, excel)
                with timed("data.parse_excel", logger):
                    return self._read_excel(path), "excel"
            except Exception as exc:
                logger.warning("Remote acquisition failed: %s", exc)

        if not self.cfg.allow_synthetic_fallback:
            raise RuntimeError(
                "Dataset unavailable and synthetic fallback is disabled. "
                f"Place '{self.cfg.filename}' inside {self.raw_dir}."
            )

        logger.warning(
            "Falling back to the synthetic surrogate corpus "
            "(%d transactions). Results remain internally valid but are not "
            "comparable to published Online Retail II benchmarks.",
            self.cfg.synthetic_n_transactions,
        )
        with timed("data.generate_synthetic", logger):
            return self._synthesise(self.cfg.synthetic_n_transactions), "synthetic"

    def _http_fetch(self, url: str, target: Path) -> Path:
        import requests  # local import: keeps the core import-light

        logger.info("Downloading %s …", url)
        response = requests.get(url, timeout=120, stream=True)
        response.raise_for_status()
        payload = response.content

        target.parent.mkdir(parents=True, exist_ok=True)
        # The UCI endpoint serves a ZIP container; unwrap it transparently.
        if payload[:2] == b"PK":
            with zipfile.ZipFile(io.BytesIO(payload)) as archive:
                members = [
                    n for n in archive.namelist() if n.lower().endswith((".xlsx", ".csv"))
                ]
                if not members:
                    raise RuntimeError("Archive contains no .xlsx/.csv member.")
                member = members[0]
                extracted = self.raw_dir / Path(member).name
                extracted.write_bytes(archive.read(member))
                logger.info("Extracted %s (%.1f MB).", extracted.name,
                            extracted.stat().st_size / 1e6)
                return extracted
        target.write_bytes(payload)
        logger.info("Saved %s (%.1f MB).", target.name, target.stat().st_size / 1e6)
        return target

    # --------------------------------------------------------------- parsing
    @staticmethod
    def _read_excel(path: Path) -> pd.DataFrame:
        """Read every sheet of the workbook and concatenate them."""
        logger.info("Parsing workbook %s (this may take ~60 s) …", path.name)
        sheets = pd.read_excel(path, sheet_name=None, engine="openpyxl")
        frames = []
        for name, sheet in sheets.items():
            logger.info("  sheet '%s': %d rows", name, len(sheet))
            frames.append(sheet)
        return pd.concat(frames, ignore_index=True)

    @staticmethod
    def _normalise(frame: pd.DataFrame) -> pd.DataFrame:
        """Coerce heterogeneous headers and dtypes onto the canonical schema."""
        renamed = {}
        for col in frame.columns:
            key = str(col).strip().lower()
            if key in _COLUMN_ALIASES:
                renamed[col] = _COLUMN_ALIASES[key]
        frame = frame.rename(columns=renamed)

        missing = [c for c in CANONICAL_COLUMNS if c not in frame.columns]
        if missing:
            raise ValueError(
                f"Input table lacks required column(s): {missing}. "
                f"Observed columns: {list(frame.columns)}"
            )
        frame = frame[CANONICAL_COLUMNS].copy()

        frame["invoice"] = frame["invoice"].astype(str).str.strip()
        frame["stock_code"] = frame["stock_code"].astype(str).str.strip().str.upper()
        frame["description"] = (
            frame["description"].astype(str).str.strip().replace({"nan": ""})
        )
        frame["quantity"] = pd.to_numeric(frame["quantity"], errors="coerce")
        frame["unit_price"] = pd.to_numeric(frame["unit_price"], errors="coerce")
        frame["invoice_date"] = pd.to_datetime(frame["invoice_date"], errors="coerce")
        frame["customer_id"] = pd.to_numeric(frame["customer_id"], errors="coerce")
        frame["country"] = frame["country"].astype(str).str.strip()

        before = len(frame)
        frame = frame.dropna(subset=["invoice_date", "quantity", "unit_price"])
        if before != len(frame):
            logger.info("Dropped %d rows with unparsable core fields.", before - len(frame))
        return frame.reset_index(drop=True)

    # ----------------------------------------------------------------- cache
    def _read_cache(self) -> Optional[pd.DataFrame]:
        if self._cache_parquet.exists():
            try:
                return pd.read_parquet(self._cache_parquet)
            except Exception as exc:  # pragma: no cover
                logger.warning("Parquet cache unreadable (%s).", exc)
        if self._cache_csv.exists():
            try:
                return pd.read_csv(self._cache_csv, parse_dates=["invoice_date"])
            except Exception as exc:  # pragma: no cover
                logger.warning("CSV cache unreadable (%s).", exc)
        return None

    def _write_cache(self, frame: pd.DataFrame) -> None:
        if not self.cfg.use_cache:
            return
        try:
            frame.to_parquet(self._cache_parquet, index=False)
            logger.info("Cached transactions → %s", self._cache_parquet.name)
        except Exception:
            frame.to_csv(self._cache_csv, index=False)
            logger.info("Cached transactions → %s (CSV fallback)", self._cache_csv.name)

    # ------------------------------------------------------------- synthetic
    @staticmethod
    def _synthesise(n_transactions: int, seed: int = 42) -> pd.DataFrame:
        """Generate a surrogate corpus with realistic structural properties.

        Generative process
        ------------------
        1. *Catalogue*: ``n_items`` products with Zipf-distributed baseline
           popularity ``p_i ∝ i^{-1.1}`` and log-normal prices.
        2. *Latent themes*: each product belongs to one of ``n_themes`` semantic
           groups; baskets draw predominantly within a theme, which induces the
           co-occurrence structure that item-item models exploit.
        3. *Customers*: activity levels follow a log-normal, producing the long
           tail of one-purchase customers observed empirically.
        4. *Time*: purchase timestamps follow a two-year span modulated by a
           sinusoidal seasonal component peaking in November (pre-Christmas).
        """
        rng = np.random.default_rng(seed)

        n_items = 3_200
        n_customers = 4_500
        n_themes = 40
        avg_basket = 9.0

        # -- catalogue ------------------------------------------------------
        ranks = np.arange(1, n_items + 1)
        popularity = ranks ** -1.1
        popularity /= popularity.sum()
        item_theme = rng.integers(0, n_themes, size=n_items)
        prices = np.round(rng.lognormal(mean=0.9, sigma=0.75, size=n_items), 2)
        prices = np.clip(prices, 0.42, 300.0)

        adjectives = ["VINTAGE", "RETRO", "SET OF 6", "HAND MADE", "SMALL", "LARGE",
                      "WHITE", "RED", "BLUE", "PINK", "ANTIQUE", "CLASSIC",
                      "PAPER", "GLASS", "METAL", "WOODEN", "CERAMIC", "SILVER"]
        nouns = ["HEART DECORATION", "LANTERN", "TEA LIGHT HOLDER", "MUG", "CAKE STAND",
                 "NAPKINS", "BUNTING", "JAR", "CLOCK", "PHOTO FRAME", "DOORMAT",
                 "CUSHION COVER", "GIFT BAG", "NOTEBOOK", "CANDLE", "BOWL",
                 "PLACEMAT", "TRINKET BOX", "WATER BOTTLE", "APRON"]
        descriptions = np.array([
            f"{adjectives[rng.integers(len(adjectives))]} "
            f"{nouns[int(item_theme[i]) % len(nouns)]}"
            for i in range(n_items)
        ])
        stock_codes = np.array([f"{85000 + i}" if i % 7 else f"{20000 + i}A"
                                for i in range(n_items)])

        # -- customers ------------------------------------------------------
        activity = rng.lognormal(mean=0.0, sigma=1.0, size=n_customers)
        activity /= activity.sum()
        countries = np.array(["United Kingdom"] * 82 + ["Germany"] * 4 +
                             ["France"] * 4 + ["EIRE"] * 3 + ["Spain"] * 2 +
                             ["Netherlands"] * 2 + ["Belgium"] * 1 +
                             ["Switzerland"] * 1 + ["Portugal"] * 1)
        customer_country = rng.choice(countries, size=n_customers)

        # -- baskets --------------------------------------------------------
        n_invoices = max(int(n_transactions / avg_basket), 100)
        basket_sizes = np.clip(rng.poisson(avg_basket, n_invoices), 1, 80)
        invoice_customer = rng.choice(n_customers, size=n_invoices, p=activity)

        start = pd.Timestamp("2009-12-01")
        span_days = 730
        # Seasonal intensity: peaks near day 330 (November of year 1) and 695.
        raw_days = rng.uniform(0, span_days, size=n_invoices * 3)
        season = 1.0 + 0.9 * np.sin(2 * np.pi * (raw_days - 60) / 365.25) ** 4
        keep = rng.uniform(0, season.max(), size=raw_days.size) < season
        chosen_days = raw_days[keep][:n_invoices]
        if chosen_days.size < n_invoices:  # pragma: no cover - defensive
            extra = rng.uniform(0, span_days, size=n_invoices - chosen_days.size)
            chosen_days = np.concatenate([chosen_days, extra])
        invoice_dates = start + pd.to_timedelta(chosen_days, unit="D")

        theme_items = [np.flatnonzero(item_theme == t) for t in range(n_themes)]
        theme_probs = []
        for members in theme_items:
            p = popularity[members]
            theme_probs.append(p / p.sum() if p.sum() > 0 else None)

        rows_invoice, rows_item, rows_qty, rows_cust, rows_date = [], [], [], [], []
        for inv in range(n_invoices):
            size = int(basket_sizes[inv])
            theme = int(rng.integers(0, n_themes))
            members, probs = theme_items[theme], theme_probs[theme]
            n_theme = int(rng.binomial(size, 0.65))  # 65% within-theme cohesion
            picks = []
            if probs is not None and members.size:
                k = min(n_theme, members.size)
                if k > 0:
                    picks.append(rng.choice(members, size=k, replace=False, p=probs))
            k_glob = size - (picks[0].size if picks else 0)
            if k_glob > 0:
                picks.append(rng.choice(n_items, size=k_glob, replace=False,
                                        p=popularity))
            items = np.unique(np.concatenate(picks)) if picks else np.array([], int)
            if items.size == 0:
                continue
            qty = rng.integers(1, 13, size=items.size)
            rows_invoice.append(np.full(items.size, 536000 + inv))
            rows_item.append(items)
            rows_qty.append(qty)
            rows_cust.append(np.full(items.size, invoice_customer[inv]))
            rows_date.append(np.full(items.size, invoice_dates[inv]))

        item_idx = np.concatenate(rows_item)
        cust_idx = np.concatenate(rows_cust)
        frame = pd.DataFrame(
            {
                "invoice": np.concatenate(rows_invoice).astype(str),
                "stock_code": stock_codes[item_idx],
                "description": descriptions[item_idx],
                "quantity": np.concatenate(rows_qty).astype(int),
                "invoice_date": pd.to_datetime(np.concatenate(rows_date)),
                "unit_price": np.round(
                    prices[item_idx] * rng.uniform(0.95, 1.05, size=item_idx.size), 2
                ),
                "customer_id": (12346 + cust_idx).astype(float),
                "country": customer_country[cust_idx],
            }
        )
        return frame.sort_values("invoice_date").reset_index(drop=True)
