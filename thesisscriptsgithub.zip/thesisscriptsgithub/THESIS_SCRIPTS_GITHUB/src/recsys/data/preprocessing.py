"""Data cleaning, filtering and densification.

Transactional retail logs are operational artefacts, not research datasets.
Before any recommendation model can be estimated the log must be purged of
records that are semantically *not* purchases: cancellations, administrative
line items (postage, bank charges, manual adjustments), returns encoded as
negative quantities, and pricing anomalies. This module implements that
purification as an auditable sequence of steps, each of which reports the exact
number of rows it removed. The resulting :class:`CleaningReport` is reproduced
verbatim in Chapter 5 of the thesis.

The final stage is *iterative k-core filtering*, which repeatedly discards users
and items falling below an interaction threshold until a fixed point is reached.
A single non-iterative pass is insufficient: removing sparse items reduces user
degrees, which may push additional users below the threshold, and vice versa.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd

from recsys.config import PreprocessingConfig
from recsys.logging_utils import get_logger

logger = get_logger(__name__)

__all__ = ["CleaningReport", "TransactionCleaner", "compute_dataset_statistics"]

#: Stock codes that denote administrative or non-catalogue line items. These are
#: identified by manual inspection of the Online Retail II code vocabulary.
NON_PRODUCT_CODES = frozenset(
    {
        "POST", "D", "DOT", "M", "S", "AMAZONFEE", "BANK CHARGES", "B",
        "CRUK", "PADS", "C2", "GIFT", "TEST001", "TEST002", "ADJUST",
        "ADJUST2", "SP1002", "AMAZON", "DCGSSBOY", "DCGSSGIRL", "GIFT_0001_10",
        "GIFT_0001_20", "GIFT_0001_30", "GIFT_0001_40", "GIFT_0001_50",
        "BANK CHARGES ", "PADS TO MATCH ALL CUSHIONS",
    }
)


@dataclass
class CleaningReport:
    """Auditable record of every filtering decision."""

    steps: List[Tuple[str, int, int]] = field(default_factory=list)  # (name, before, after)

    def record(self, name: str, before: int, after: int) -> None:
        self.steps.append((name, before, after))
        removed = before - after
        pct = 100.0 * removed / before if before else 0.0
        logger.info(
            "  %-32s %8d → %8d  (−%d, −%.2f%%)", name, before, after, removed, pct
        )

    def to_frame(self) -> pd.DataFrame:
        df = pd.DataFrame(self.steps, columns=["step", "rows_before", "rows_after"])
        df["rows_removed"] = df["rows_before"] - df["rows_after"]
        df["pct_removed"] = 100.0 * df["rows_removed"] / df["rows_before"].replace(0, np.nan)
        return df

    @property
    def total_retention(self) -> float:
        if not self.steps:
            return 1.0
        return self.steps[-1][2] / self.steps[0][1] if self.steps[0][1] else 0.0


class TransactionCleaner:
    """Apply the cleaning protocol described in thesis §5.2."""

    def __init__(self, cfg: PreprocessingConfig) -> None:
        self.cfg = cfg
        self.report = CleaningReport()

    def clean(self, frame: pd.DataFrame) -> pd.DataFrame:
        cfg = self.cfg
        df = frame.copy()
        logger.info("Cleaning protocol — initial rows: %d", len(df))

        # (1) Exact duplicate transaction lines --------------------------------
        before = len(df)
        df = df.drop_duplicates(
            subset=["invoice", "stock_code", "quantity", "invoice_date", "unit_price"]
        )
        self.report.record("duplicate_lines", before, len(df))

        # (2) Cancellations ----------------------------------------------------
        if cfg.drop_cancellations:
            before = len(df)
            is_cancel = df["invoice"].astype(str).str.upper().str.startswith("C")
            df = df.loc[~is_cancel]
            self.report.record("cancellation_invoices", before, len(df))

        # (3) Non-positive quantities (returns / corrections) -------------------
        before = len(df)
        df = df.loc[df["quantity"] >= cfg.min_quantity]
        self.report.record("non_positive_quantity", before, len(df))

        # (4) Price sanity -----------------------------------------------------
        before = len(df)
        df = df.loc[
            (df["unit_price"] >= cfg.min_unit_price)
            & (df["unit_price"] <= cfg.max_unit_price)
        ]
        self.report.record("price_out_of_range", before, len(df))

        # (5) Extreme-value trimming ------------------------------------------
        if cfg.remove_price_outliers and len(df):
            before = len(df)
            q = cfg.outlier_quantile
            price_cap = df["unit_price"].quantile(q)
            qty_cap = df["quantity"].quantile(q)
            df = df.loc[(df["unit_price"] <= price_cap) & (df["quantity"] <= qty_cap)]
            self.report.record(f"extreme_values_q{q}", before, len(df))

        # (6) Administrative / non-catalogue codes -----------------------------
        if cfg.drop_non_product_codes:
            before = len(df)
            codes = df["stock_code"].astype(str).str.strip().str.upper()
            # Legitimate product codes always contain at least one digit.
            has_digit = codes.str.contains(r"\d", regex=True, na=False)
            df = df.loc[has_digit & ~codes.isin(NON_PRODUCT_CODES)]
            self.report.record("non_product_codes", before, len(df))

        # (7) Guest checkouts (missing customer identifier) --------------------
        if cfg.drop_missing_customer:
            before = len(df)
            df = df.loc[df["customer_id"].notna()]
            self.report.record("missing_customer_id", before, len(df))

        # (8) Derived monetary field -------------------------------------------
        df = df.copy()
        df["revenue"] = df["quantity"] * df["unit_price"]
        df["customer_id"] = df["customer_id"].astype(np.int64)

        # (9) Iterative k-core densification -----------------------------------
        df = self._k_core(df)

        logger.info(
            "Cleaning complete — %d rows retained (%.1f%% of input).",
            len(df),
            100.0 * self.report.total_retention,
        )
        return df.reset_index(drop=True)

    # ------------------------------------------------------------------ k-core
    def _k_core(self, df: pd.DataFrame) -> pd.DataFrame:
        """Iteratively enforce minimum user and item degrees until stable."""
        cfg = self.cfg
        if cfg.min_user_interactions <= 1 and cfg.min_item_interactions <= 1:
            return df

        before_total = len(df)
        for iteration in range(1, cfg.k_core_max_iterations + 1):
            n_before = len(df)

            item_deg = df.groupby("stock_code")["customer_id"].transform("nunique")
            df = df.loc[item_deg >= cfg.min_item_interactions]

            user_deg = df.groupby("customer_id")["stock_code"].transform("nunique")
            df = df.loc[user_deg >= cfg.min_user_interactions]

            if len(df) == n_before:
                logger.info("  k-core converged after %d iteration(s).", iteration)
                break
            logger.debug(
                "  k-core iteration %d: %d → %d rows", iteration, n_before, len(df)
            )
        else:  # pragma: no cover - only when max_iterations is exhausted
            logger.warning(
                "k-core did not converge within %d iterations.",
                cfg.k_core_max_iterations,
            )

        self.report.record(
            f"k_core(u≥{cfg.min_user_interactions},i≥{cfg.min_item_interactions})",
            before_total,
            len(df),
        )
        return df


def compute_dataset_statistics(df: pd.DataFrame) -> Dict[str, float]:
    """Descriptive statistics reported in thesis Table 5.2.

    Includes the *Gini coefficient* of the item-popularity distribution, which
    quantifies catalogue concentration and is the key evidence for the long-tail
    argument developed in Chapter 2.
    """
    n_users = int(df["customer_id"].nunique())
    n_items = int(df["stock_code"].nunique())
    n_inter = int(len(df.drop_duplicates(subset=["customer_id", "stock_code"])))
    density = n_inter / (n_users * n_items) if n_users and n_items else 0.0

    per_user = df.groupby("customer_id")["stock_code"].nunique()
    per_item = df.groupby("stock_code")["customer_id"].nunique()
    basket = df.groupby("invoice")["stock_code"].nunique()

    stats: Dict[str, float] = {
        "n_transactions": float(len(df)),
        "n_invoices": float(df["invoice"].nunique()),
        "n_users": float(n_users),
        "n_items": float(n_items),
        "n_unique_interactions": float(n_inter),
        "density_pct": 100.0 * density,
        "sparsity_pct": 100.0 * (1.0 - density),
        "mean_items_per_user": float(per_user.mean()),
        "median_items_per_user": float(per_user.median()),
        "mean_users_per_item": float(per_item.mean()),
        "median_users_per_item": float(per_item.median()),
        "mean_basket_size": float(basket.mean()),
        "median_basket_size": float(basket.median()),
        "total_revenue": float(df["revenue"].sum()) if "revenue" in df else float("nan"),
        "mean_order_value": float(df.groupby("invoice")["revenue"].sum().mean())
        if "revenue" in df
        else float("nan"),
        "gini_item_popularity": gini_coefficient(per_item.to_numpy(dtype=float)),
        "gini_user_activity": gini_coefficient(per_user.to_numpy(dtype=float)),
        "n_countries": float(df["country"].nunique()) if "country" in df else float("nan"),
        "span_days": float(
            (df["invoice_date"].max() - df["invoice_date"].min()).days
        ),
    }
    return stats


def gini_coefficient(values: np.ndarray) -> float:
    """Gini coefficient of a non-negative distribution.

    ``G = (2 Σ i·x_(i)) / (n Σ x) − (n+1)/n`` for sorted ``x_(i)``.
    ``G = 0`` denotes perfect equality; ``G → 1`` extreme concentration.
    """
    x = np.asarray(values, dtype=float)
    x = x[np.isfinite(x)]
    if x.size == 0:
        return float("nan")
    if np.any(x < 0):
        x = x - x.min()
    x = np.sort(x)
    n = x.size
    total = x.sum()
    if total <= 0:
        return 0.0
    index = np.arange(1, n + 1, dtype=float)
    return float((2.0 * np.sum(index * x)) / (n * total) - (n + 1.0) / n)
