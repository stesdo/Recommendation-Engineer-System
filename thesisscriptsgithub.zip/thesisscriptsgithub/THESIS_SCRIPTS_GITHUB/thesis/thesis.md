# Design and Implementation of a Digital Decision-Making System for Hyper-Personalised Product Exposure in E-Retail

**A Diploma Thesis**

**Student Registration Number: 3121077**

![](assets/recommendation_engine_cover.png)

---

## Abstract

Digital retailing has outgrown the merchandising logic on which it was founded. A catalogue of several thousand articles presented through a single, globally ranked storefront imposes on every visitor the same editorial judgement, irrespective of the behavioural evidence that the visitor has already generated. This thesis designs, implements and empirically evaluates a production-grade recommendation engine that replaces this *one-size-fits-all* arrangement with an automated, data-driven decision mechanism for product exposure. Seven families of recommendation algorithm — popularity ranking with recency decay, item-based k-nearest neighbours, the EASE^R linear autoencoder, implicit-feedback alternating least squares, Bayesian personalised ranking, content-based retrieval over TF–IDF product text, and association-rule mining — were implemented from first principles in Python, together with a four-strategy hybrid combiner. The system was evaluated on the UCI *Online Retail II* dataset (1,067,371 raw transaction lines; 773,564 after an auditable cleaning protocol; 5,527 customers; 4,197 products; 97.94% sparsity) under a temporally causal splitting protocol with full-catalogue ranking, a fifteen-metric evaluation framework spanning accuracy, beyond-accuracy and business value, and a complete inferential apparatus of Wilcoxon signed-rank tests, paired bootstrap confidence intervals and Holm–Bonferroni multiplicity correction. The EASE^R linear autoencoder achieved the highest ranking quality (NDCG@10 = 0.0922), a statistically significant improvement of 107.8% over the non-personalised popularity baseline (Holm-corrected *p* < 0.0001), and did so while raising catalogue coverage from 1.82% to 27.81% and reducing popularity bias by 43.9%. A funnel-based economic simulation, reported with an explicit sensitivity analysis over its single judgemental parameter, translates this accuracy improvement into a projected revenue uplift of between 54% and 323%. The thesis also documents a methodologically important structural result: a well-regularised *linear* model, trained in 0.74 seconds, decisively outperformed both latent-factor methods, which together consumed 149 seconds of training for lower accuracy — independently reproducing the finding of Ferrari Dacrema, Cremonesi and Jannach (2019) that algorithmic sophistication and empirical performance are only loosely coupled in this domain. Of the twenty-eight pairwise comparisons, twenty survive multiplicity correction, and the four mid-table systems form a single statistically indistinguishable cluster — a result reported here as a finding about the limits of resolution rather than concealed behind a strict ranking.

**Keywords:** recommender systems; hyper-personalisation; implicit feedback; collaborative filtering; EASE; customer lifetime value; cross-selling; e-commerce analytics.

---

## Table of Contents

1. Introduction
2. Literature Review and Theoretical Background
3. Data and Experimental Methodology
4. System Architecture and Algorithmic Design
5. Exploratory Analysis and Data Preparation
6. Empirical Results: Comparative Algorithm Evaluation
7. From Rankings to Revenue: The Business Layer
8. Discussion
9. Conclusions and Future Work
10. References
11. Appendix A — Reproduction Instructions
12. Appendix B — Complete Experimental Parameters

---

## List of Figures

| Figure | Title | Section |
|--------|-------|---------|
| 5.1 | Structural characteristics of the dataset | 5.1 |
| 5.2 | Temporal dynamics of demand | 5.2 |
| 5.3 | Auditable data-cleaning protocol | 5.3 |
| 5.4 | Temporally consistent partitioning | 5.4 |
| 6.1 | Comparative accuracy evaluation | 6.1 |
| 6.2 | Beyond-accuracy evaluation | 6.2 |
| 6.3 | Statistical validation of comparisons | 6.3 |
| 6.4 | Computational footprint of the algorithms | 6.4 |
| 7.1 | Customer segmentation and lifetime value | 7.1 |
| 7.2 | Cross-selling and long-tail exposure | 7.2 |
| 7.3 | Economic valuation of personalisation | 7.3 |
| 8.1 | Algorithm behaviour for a single customer | 8.1 |
| 9.1 | Consolidated summary of empirical findings | 9.1 |

---

## List of Tables

| Table | Title | Section |
|-------|-------|---------|
| 5.1 | Sequential attrition through the cleaning protocol | 5.3 |
| 5.2 | Descriptive statistics of the cleaned dataset | 5.3 |
| 6.1 | Accuracy at *k* = 10 | 6.1 |
| 6.2 | Beyond-accuracy metrics at *k* = 10 | 6.2 |
| 6.3 | Selected pairwise comparisons on NDCG@10 | 6.3 |
| 6.4 | Computational cost | 6.4 |
| 7.1 | RFM segmentation | 7.1 |
| 7.2 | Concentration of predicted 365-day CLV by decile | 7.1 |
| 7.3 | Representative cross-sell suggestions | 7.2 |
| 7.4 | Revenue and exposure by popularity tercile | 7.2 |
| 7.5 | Projected funnel outcomes | 7.3 |
| 7.6 | Sensitivity of projected revenue uplift to elasticity | 7.3 |
| B.1 | Data, preprocessing and feature-construction parameters | Appendix B |
| B.2 | Complete model hyperparameters | Appendix B |
| B.3 | Evaluation and inferential parameters | Appendix B |
| B.4 | Business and serving parameters | Appendix B |

---

# 1. Introduction

## 1.1 Problem Context

The economics of electronic retailing differ from those of physical retailing in one respect that is decisive for merchandising strategy: shelf space is effectively unconstrained, but *attention* is not. A physical store is disciplined by the cost of square metres, and its assortment is therefore curated in advance; an online store can list tens of thousands of articles at negligible marginal cost, but can still present only a handful of them above the fold. The constraint has migrated from inventory to interface, and with it the central merchandising question has changed from *what should we stock?* to *what should we show, to whom, and when?*

Traditional digital storefronts answer this question with a single global ranking — best-sellers, new arrivals, editorially curated collections — applied uniformly to every visitor. This *one-size-fits-all* strategy has two well-documented pathologies. First, it aggravates what Schwartz (2004) termed the **paradox of choice**: confronted with an undifferentiated catalogue, consumers experience decision paralysis, and the probability of abandonment rises with assortment size rather than falling. Second, it is self-reinforcing. A globally popular item receives disproportionate exposure, which generates disproportionate sales, which further entrenches its position; the remaining assortment becomes commercially invisible, and the **long tail** of demand identified by Anderson (2006) as the structural advantage of digital retail is never realised.

Contemporary digital marketing practice has responded with the doctrine of **hyper-personalisation**: the use of behavioural data to construct an individualised interface for each visitor in real time (Chaffey and Ellis-Chadwick, 2019). The proposition is intuitively compelling and commercially significant — Gomez-Uribe and Hunt (2016) attribute approximately 80% of Netflix viewing hours to algorithmic recommendation and estimate the annual value of the system at over one billion US dollars — but its implementation raises engineering and methodological questions that are considerably harder than the doctrine suggests.

A recommender is therefore better understood as a **decision policy** than as a passive predictor. Its output changes what the customer is able to notice, so today's ranking partly determines tomorrow's training data. Purchases are observed only for products that were stocked, exposed and selected; the absence of a purchase is not proof of irrelevance. This exposure mechanism makes the log *missing not at random* and creates a feedback loop in which naïve empirical-risk minimisation can reproduce the merchandising policy that generated the data. Schnabel *et al.* (2016) formalise recommendation as treatment assignment and show why propensity-aware evaluation is required for an unbiased estimate of a new exposure policy. The present dataset contains no historical exposure propensities, so this thesis cannot identify a causal treatment effect. Its offline metrics estimate the narrower, but still decision-relevant, question of how well each model re-ranks purchases observed in a causally later period. Keeping this estimand explicit prevents predictive association from being misreported as incremental commercial impact.

## 1.2 Aim and Objectives

The aim of this thesis is to design, implement and rigorously evaluate a digital system that acts as an **automated decision mechanism for product exposure**, converting a static browsing experience into a dynamic, personalised one on the basis of each customer's transactional digital footprint.

The aim is decomposed into six objectives:

1. **O1 — Implementation.** To implement, from first principles rather than by configuring an existing library, a representative set of recommendation algorithms spanning the principal methodological families, together with a hybrid combiner.
2. **O2 — Methodological rigour.** To evaluate these algorithms under a protocol that is causally admissible in its training signal (no future interaction is visible during fitting), unbiased (full-catalogue ranking rather than sampled negatives) and inferentially sound (paired significance testing with multiplicity correction), and to state precisely where that admissibility stops — the *k*-core densification step is applied to the full log before partitioning, and its measured effect is quantified in §8.5.
3. **O3 — Multi-dimensional assessment.** To measure not only accuracy but also catalogue coverage, novelty, diversity, serendipity and popularity bias, on the argument that a recommender optimised on accuracy alone degenerates into the very popularity ranker it was meant to replace.
4. **O4 — Commercial translation.** To connect ranking quality to the merchandising objectives stated in the brief — cross-selling, up-selling, conversion rate and customer lifetime value — through explicit, auditable economic models.
5. **O5 — Operational viability.** To deliver the system as deployable software: a configurable pipeline, a command-line interface, a REST service, structured logging and a unit-test suite.
6. **O6 — Reproducibility.** To ensure that every reported number can be regenerated from the repository by a third party.

## 1.3 Research Questions

- **RQ1.** By how much, and with what statistical confidence, does personalised ranking improve top-*N* recommendation quality over a non-personalised popularity baseline on real transactional retail data?
- **RQ2.** Which algorithmic family offers the best accuracy, and does algorithmic sophistication predict empirical performance?
- **RQ3.** What is the relationship between accuracy and beyond-accuracy properties, and is the widely assumed accuracy–diversity trade-off observed empirically?
- **RQ4.** How do accuracy differences translate into commercial outcomes, and how sensitive is that translation to its underlying assumptions?

## 1.4 Scope and Delimitations

Three delimitations are stated at the outset, in preference to allowing the reader to discover them later.

First, the brief specifies analysis of the digital footprint including *clicks, views and dwell time*. The *Online Retail II* dataset contains no clickstream: it is a transactional ledger. The system therefore models the **purchase footprint** — frequency, recency, monetary value and basket composition — which is a strict subset of, and the highest-value signal within, the digital footprint. The architecture accepts click and view events without code modification through the interaction-weighting interface (§4.3), but no such data were available for evaluation, and no claim is made about them.

Second, all commercial figures reported in Chapter 7 are **projections from an explicit model**, not measurements. Offline simulation cannot substitute for a randomised controlled trial; accordingly, the critical elasticity parameter is subjected to a sensitivity analysis and the conclusion is stated in terms of its robustness across that range.

Third, the evaluation is a single-dataset study. The findings are internally valid and reproducible but their external validity to other catalogues, particularly to business-to-consumer catalogues with different repeat-purchase dynamics, is an empirical question this thesis does not answer.

## 1.5 Contributions

The thesis makes five contributions. (i) A complete, from-scratch implementation of seven recommendation algorithm families plus a four-strategy hybrid, in approximately 8,000 lines of documented, type-annotated and unit-tested Python. (ii) A fifteen-metric, three-axis evaluation framework combined with a full inferential apparatus, applied to eight systems over 28 pairwise comparisons. (iii) An independent empirical reproduction of the Ferrari Dacrema, Cremonesi and Jannach (2019) result, in which a closed-form linear model outperforms both matrix-factorisation approaches by margins that are statistically significant after multiplicity correction. (iv) An explicit bridge from ranking metrics to revenue via RFM segmentation, BG/NBD and Gamma–Gamma lifetime-value modelling, and a transparent conversion-funnel simulation with sensitivity analysis. (v) A reproducible research artefact in which every figure and table in Chapters 5 to 9 is regenerated by a single command.

## 1.6 Structure of the Thesis

Chapter 2 reviews the theoretical and empirical literature. Chapter 3 describes the dataset and the experimental methodology. Chapter 4 sets out the system architecture and the mathematical formulation of each algorithm. Chapter 5 presents the exploratory analysis and the data-preparation results. Chapter 6 reports the comparative evaluation and its statistical validation. Chapter 7 develops the business layer. Chapter 8 discusses the findings, their limitations and their threats to validity. Chapter 9 concludes.

---

# 2. Literature Review and Theoretical Background

## 2.1 The Recommendation Problem

Formally, let $U$ denote a set of $m$ users and $I$ a set of $n$ items. The observed interaction data form a matrix $X \in \mathbb{R}^{m \times n}$ in which $x_{ui} > 0$ records an interaction between user $u$ and item $i$. The **top-*N* recommendation** task is to learn a scoring function $s: U \times I \to \mathbb{R}$ and, for each user, to return the $N$ unseen items of highest score.

The formulation conceals a critical distinction. In **explicit feedback** settings — the five-star ratings of the Netflix Prize — a rating is a direct statement of preference, and unobserved entries are genuinely *missing*. In **implicit feedback** settings, of which retail transaction logs are the canonical example, the data are fundamentally asymmetric: a purchase is weak positive evidence, but a non-purchase conflates disinterest with non-exposure. Hu, Koren and Volinsky (2008) established the standard treatment, separating a binary *preference* $p_{ui} = \mathbb{1}[x_{ui} > 0]$ from a *confidence* $c_{ui}$ that scales with the strength of the evidence. This distinction governs the design of the feature layer described in §4.3.

The scoring function also embeds a normative choice. Ranking by estimated purchase probability favours familiar, frequently exposed products; ranking by expected margin may favour expensive products; re-ranking for novelty or supplier exposure deliberately redistributes attention. These objectives are not interchangeable, and no scalar offline metric can establish that one is universally preferable. The appropriate formulation is a constrained multi-objective decision problem: relevance supplies a necessary lower bound on usefulness, while coverage, novelty, diversity and value describe materially different consequences of allocating scarce interface positions (Castells, Hurley and Vargas, 2015; Kaminskas and Bridge, 2017). This is why the thesis reports a metric vector and a Pareto interpretation rather than collapsing all objectives into a single, unvalidated composite score.

## 2.2 Collaborative Filtering

### 2.2.1 Neighbourhood methods

The earliest deployed recommenders computed similarities between users (Resnick *et al.*, 1994). Sarwar *et al.* (2001) demonstrated that the *item*-based formulation is superior in practice for three reasons: item–item relationships are more stable over time than user–user relationships, the similarity matrix can be precomputed offline, and the resulting recommendations are directly explainable as *"because you bought X"*. Deshpande and Karypis (2004) extended the approach to top-*N* recommendation and established truncation of the similarity matrix to the *k* strongest neighbours as standard practice, showing that truncation acts as a denoising operator and reliably improves accuracy rather than merely saving memory.

Two refinements are relevant here. Bell and Koren (2007) showed that raw cosine similarity over-rewards item pairs supported by very few co-purchases, and proposed shrinking the estimate towards zero in proportion to support — a maximum *a posteriori* estimate under a zero-mean prior. Separately, the transfer of information-retrieval weighting schemes to collaborative filtering, in particular Okapi BM25 (Robertson and Zaragoza, 2009) and the TF–IDF scheme of Salton and Buckley (1988), suppresses the influence of blockbuster items and of users with pathologically long histories.

### 2.2.2 Latent-factor methods

Matrix factorisation approximates $X \approx UV^\top$ with $U \in \mathbb{R}^{m \times f}$ and $V \in \mathbb{R}^{n \times f}$ for $f \ll \min(m, n)$, and became dominant after the Netflix Prize (Koren, Bell and Volinsky, 2009). Its adaptation to implicit feedback by Hu, Koren and Volinsky (2008) — iALS — treats all unobserved entries as negatives weighted by low confidence, and exploits an algebraic reorganisation of the normal equations to reduce the per-iteration cost from $O(mnf^2)$ to $O(\mathrm{nnz} \cdot f^2 + (m+n)f^3)$. Takács, Pilászy and Tikk (2011) subsequently replaced the exact Cholesky solve with a small number of conjugate-gradient steps, removing the cubic term at negligible accuracy cost — an optimisation that becomes decisive only at much larger factor counts than are required here, and which for that reason is not adopted in this implementation (§4.4).

Rendle *et al.* (2009) approached the problem from a different direction. Rather than fitting pointwise scores, **Bayesian Personalised Ranking** (BPR) optimises a pairwise criterion directly: for an observed item $i$ and an unobserved item $j$, it maximises $\ln \sigma(\hat{x}_{ui} - \hat{x}_{uj})$. Because the objective is a ranking objective, BPR is in principle better aligned with the top-*N* task than pointwise regression; in practice it is a stochastic method whose convergence depends heavily on the number of epochs, a dependence that is directly visible in the results of Chapter 6.

### 2.2.3 Linear autoencoders

Steck (2019) observed that a *linear* item–item autoencoder subject to a zero-diagonal constraint,

$$\min_B \|X - XB\|_F^2 + \lambda \|B\|_F^2 \quad \text{s.t.} \quad \mathrm{diag}(B) = 0,$$

admits a **closed-form solution**. Introducing Lagrange multipliers for the constraint and setting the gradient to zero yields $\hat{B}_{ij} = -P_{ij}/P_{jj}$ for $i \neq j$ and zero otherwise, where $P = (X^\top X + \lambda I)^{-1}$. The zero-diagonal constraint is what makes the problem non-trivial; without it the identity matrix is a perfect and useless solution. The model — **EASE^R**, "embarrassingly shallow autoencoder" — has no hyperparameters beyond $\lambda$, no stochastic optimisation, and no convergence criterion, and Steck reported that it matched or exceeded contemporaneous deep architectures on sparse implicit-feedback data.

## 2.3 Content-Based and Rule-Based Methods

Content-based recommenders score items by the similarity of their attributes to a profile constructed from the user's history (Pazzani and Billsus, 2007; Lops, de Gemmis and Semeraro, 2011). Their principal advantage is immunity to item cold-start: a newly listed article can be recommended the moment its description exists. Their principal weakness is over-specialisation — the profile is a convex combination of what the user has already seen, so genuinely novel propositions are structurally difficult to surface.

Association-rule mining (Agrawal, Imieliński and Swami, 1993) approaches the problem from the basket rather than the customer. A rule $A \Rightarrow B$ is characterised by *support* $P(A \cap B)$, *confidence* $P(B \mid A)$ and *lift* $P(B \mid A)/P(B)$. Lift is the quantity of merchandising interest because it isolates genuine association from mere popularity: a lift of 6 means that customers who bought $A$ are six times more likely than the population to buy $B$. Rules are natively interpretable and map directly onto cross-selling, which is why they are retained in this system despite being outperformed on accuracy.

## 2.4 Hybridisation

Burke (2002) provides the canonical taxonomy of hybridisation, identifying seven mechanisms of which four are implemented here: *weighted* combination of normalised scores; *switching* between models according to context; *cascade*, in which a cheap model retrieves candidates that an expensive model re-ranks; and rank-based fusion. Cormack, Clarke and Büttcher (2009) introduced **Reciprocal Rank Fusion**, $\mathrm{RRF}(i) = \sum_m 1/(k + \mathrm{rank}_m(i))$, which uses only ordinal information and is therefore immune to the scale mismatch that plagues naïve score averaging — a serious concern when EASE emits unbounded reals, cosine similarity lives in $[0,1]$ and lift is a ratio on $[1, \infty)$. The cascade architecture is the standard industrial pattern, described for YouTube by Covington, Adams and Sargin (2016).

## 2.5 Evaluation Methodology

Three methodological findings shape the experimental design of this thesis and deserve emphasis, because ignoring any one of them invalidates the resulting numbers.

**Sampled metrics are inconsistent.** A widespread shortcut scores the held-out positive item against 99 randomly drawn negatives. Krichene and Rendle (2020) proved that the resulting metrics are *inconsistent* estimators of their full-catalogue counterparts: the induced ranking of algorithms can differ from, and even invert, the ranking obtained by scoring the entire catalogue. This thesis therefore always ranks all 4,197 items for every evaluated user, at substantial computational cost.

**Random splits leak the future.** Because purchasing behaviour is strongly non-stationary — seasonality, product life-cycles, fashion — partitioning interactions at random trains the model on events that postdate the events it is asked to predict. Ji *et al.* (2020) and Meng *et al.* (2020) document accuracy inflation exceeding a factor of two from this source. Only causally admissible protocols are used here.

**Baselines must be strong and comparisons must be tested.** Cremonesi, Koren and Turrin (2010) established the non-personalised popularity ranker as a mandatory baseline for top-*N* evaluation. Ferrari Dacrema, Cremonesi and Jannach (2019) went further: attempting to reproduce eighteen neural recommenders published at leading venues, they succeeded for seven, and of those seven, six were outperformed by well-tuned traditional baselines. The implication is not that neural methods are without value but that *the baseline is the experiment*. Demšar (2006) supplies the corresponding inferential machinery — the Wilcoxon signed-rank test for paired non-parametric comparison (Wilcoxon, 1945) and the Nemenyi test for multiple comparisons — while Holm (1979) provides the step-down multiplicity correction that controls the family-wise error rate without the conservatism of Bonferroni. Efron and Tibshirani (1994) supply the distribution-free confidence interval.

**Offline relevance is not causal uplift.** Standard hold-out evaluation treats a later purchase as relevant and asks whether the model ranks it highly. It cannot reveal whether displaying the item *caused* the purchase, whether the customer would have found it unaided, or whether recommending an alternative would have generated more profit. Historical logs are selected by prior exposure and by customer self-selection; consequently, a high NDCG is evidence of predictive ranking quality, not an estimate of the average treatment effect of recommendation (Schnabel *et al.*, 2016). Randomised online experiments remain the identification standard for conversion and revenue uplift. This distinction determines the language used in Chapter 7: economic values are projections under stated assumptions, never observed causal effects.

## 2.6 Beyond Accuracy

A recommender optimised exclusively on accuracy converges towards recommending popular items, because popularity is the highest-prior-probability prediction available. The resulting system maximises hit rate while minimising the exposure of the catalogue, which is commercially self-defeating. Kaminskas and Bridge (2017) survey the alternative objectives; Castells, Hurley and Vargas (2015) formalise novelty and diversity; Ziegler *et al.* (2005) introduce intra-list diversity as mean pairwise dissimilarity within a recommendation list; Zhou *et al.* (2010) and Vargas and Castells (2011) define novelty as mean self-information $-\log_2 p_i$; and Ge, Delgado-Battenfeld and Jannach (2010) define serendipity as relevance minus obviousness, on the argument that a hit on an item the popularity baseline would already have surfaced carries no incremental value. All six of these constructs are implemented and reported in Chapter 6.

## 2.7 Customer Value Modelling

E-retail is a **non-contractual** setting: customers do not announce their departure, so churn is latent and must be inferred. Recency–Frequency–Monetary segmentation (Hughes, 1994) remains the canonical non-parametric approach and supplies an interpretable partition that management can act upon. Its probabilistic generalisation is the pairing of the **BG/NBD** model (Fader, Hardie and Lee, 2005a), which models purchase counts through a Gamma-distributed Poisson rate combined with a Beta-distributed per-transaction dropout probability, and the **Gamma–Gamma** monetary model (Fader, Hardie and Lee, 2005b), which supplies a shrinkage estimator of average transaction value. Together they yield a closed-form expectation of future transactions and hence a discounted lifetime-value forecast — the quantity the project brief identifies as the ultimate objective of personalisation.

## 2.8 Research Gap

The literature contains a large body of algorithmic work evaluated on accuracy metrics over a small number of benchmark datasets, and a separate body of marketing work on customer value that rarely engages with ranking algorithms. Studies that (i) implement multiple algorithm families under a common, methodologically defensible protocol, (ii) report beyond-accuracy metrics alongside accuracy, (iii) apply proper statistical inference with multiplicity correction, and (iv) connect the results to an explicit economic model of the deployment, are rare. This thesis occupies that intersection.

---

# 3. Data and Experimental Methodology

## 3.1 The Dataset

The empirical work uses **Online Retail II** (Chen, 2012), a transaction-level ledger from a UK-based, registered non-store online retailer specialising in unique all-occasion giftware, with a substantial wholesale customer base. The dataset is distributed by the UCI Machine Learning Repository under a CC BY 4.0 licence and covers 1 December 2009 to 9 December 2011 — 738 days spanning two complete Christmas trading seasons.

The raw file contains **1,067,371 transaction lines** with eight attributes: `Invoice`, `StockCode`, `Description`, `Quantity`, `InvoiceDate`, `Price`, `Customer ID` and `Country`. The dataset is well suited to this study for four reasons: it is genuinely transactional rather than simulated; it carries the monetary information required for the business layer; it spans a period long enough to support a temporal split with seasonal coverage; and it is public, which makes the entire study reproducible.

Its limitations are equally important. It contains no clickstream, no session data, no demographic attributes and no explicit ratings, and its wholesale component produces a customer population with unusually high basket sizes.

## 3.2 Cleaning Protocol

Operational retail logs are not research datasets. Before estimation, records that are not semantically purchases must be removed. The protocol is implemented as an auditable sequence of eight steps, each reporting the exact number of rows removed; the resulting report is reproduced in §5.3. The steps are: (1) exact duplicate transaction lines; (2) cancellation invoices, identified by an invoice number beginning with `C`; (3) non-positive quantities, which encode returns and corrections; (4) prices outside $[£0.01, £10{,}000]$; (5) extreme values above the 99.9th percentile of price and quantity; (6) administrative stock codes such as `POST`, `DOT`, `M` and `BANK CHARGES`, identified both by an explicit vocabulary and by the heuristic that legitimate product codes contain at least one digit; (7) guest checkouts with a missing customer identifier; and (8) iterative *k*-core filtering.

The last step warrants explanation. A single non-iterative pass is insufficient: removing sparse items reduces user degrees, which may push additional users below the threshold, which in turn reduces item degrees. The implementation therefore alternates item-degree and user-degree filtering at a threshold of five until a fixed point is reached, which occurred after a small number of iterations.

## 3.3 Temporal Splitting

The splitting protocol is **`temporal_global`**: a single global timestamp $\tau$ separates past from future. Interactions before the 70th percentile of the timestamp distribution form the training set; those between the 70th and 80th percentiles form a validation set; those after the 80th percentile form the test set. This is the protocol that most closely mirrors production deployment, in which a model trained on the history of the entire customer base serves the next period.

Two implementation details are consequential. First, the **vocabulary is defined by the training partition alone**: users and items unseen during training cannot be represented by a collaborative model, and silently admitting them would corrupt the index space and inflate coverage metrics. Second, evaluation is restricted to users with at least three training interactions, since a model cannot reasonably be assessed on users for whom it has essentially no evidence. The absence of temporal leakage is asserted programmatically — the maximum training timestamp is verified to precede the minimum test timestamp — and is additionally verified by a unit test.

## 3.4 Evaluation Protocol

For each evaluated user the model ranks the **entire training catalogue** of 3,898 items, excluding items already purchased in the training period, and the top 20 are scored at cut-offs $k \in \{5, 10, 20\}$. The primary metric is **NDCG@10**. All 2,007 customers satisfying the eligibility rules and possessing non-empty, still-rankable test baskets are evaluated (below the configured safety cap of 4,000); the population is fixed across all models, which is a precondition for the paired significance tests. Aggregation is the arithmetic mean over users — the *macro* average — because a micro average would allow a handful of wholesale buyers with hundreds of test purchases to dominate the score.

This protocol defines a precise estimand: expected ranking quality for a uniformly drawn eligible returning customer, conditional on that customer making at least one purchase in the test period and on both customer and article being representable from training data. It does **not** estimate performance for anonymous visitors, genuinely new customers, customers who do not return, or products introduced after the training cut-off. Stating the target population matters because alternative aggregation schemes answer different questions. A transaction-weighted mean would estimate performance for a randomly drawn purchase and therefore privilege high-frequency wholesalers; a revenue-weighted mean would estimate performance per pound of historical demand. Macro averaging is selected because the operational decision is a customer-level carousel, but the other interpretations remain legitimate for different business objectives.

Fifteen metrics are computed on three axes. One protocol detail governs all of them: because the ranker excludes articles the customer already bought during training, those articles are also removed from the held-out target set. Retaining them would leave targets no model can return, capping recall and NDCG below one by a customer-dependent amount. The task evaluated here is therefore *predict the next **new** article*, and the metrics occupy a genuine [0, 1] range.

**Axis 1 — accuracy.** Precision@*k*, Recall@*k*, F1@*k*, Hit Rate@*k*, MAP@*k*, MRR@*k* and NDCG@*k*. NDCG is primary because it is the only accuracy measure that is simultaneously graded, position-discounted and normalised, and is therefore comparable across users with different numbers of test purchases:

$$\mathrm{NDCG@}k = \frac{\sum_{j=1}^{k} \mathbb{1}[i_j \in R_u] / \log_2(j+1)}{\sum_{j=1}^{\min(|R_u|,k)} 1/\log_2(j+1)}.$$

**Axis 2 — beyond accuracy.** Catalogue coverage@*k*, novelty@*k* (mean self-information), intra-list diversity@*k* (mean pairwise cosine dissimilarity in content space), serendipity@*k* (relevant and not already reachable by the popularity baseline), popularity bias@*k*, and the Gini coefficient and Shannon entropy of the exposure distribution. The serendipity "obvious" set is defined as the prefix of the popularity ordering deep enough that *every* customer could be served $k$ unseen articles from it, so an article counts as serendipitous only if the non-personalised baseline could not have surfaced it to anyone. The baseline's own serendipity is then zero by construction, which is what makes the comparison interpretable.

**Axis 3 — business value.** Expected revenue@*k*, defined as the position-discounted monetary value of correctly ranked items, $\sum_j \pi_{i_j} \cdot \mathbb{1}[i_j \in R_u] \cdot \gamma^{j-1}$ with $\gamma = 0.85$. Accuracy metrics treat a £0.42 greeting card and a £45 cake stand as equivalent successes; this metric restores the economic dimension.

## 3.5 Statistical Inference

A ranking of model means carries no measure of uncertainty. Three procedures upgrade descriptive comparison into inference. The **Wilcoxon signed-rank test** is applied to every pair of models over the vector of per-user NDCG@10 scores, chosen over the paired *t*-test because metric differences are markedly non-normal. **Paired bootstrap confidence intervals** at the 95% level are computed by resampling users with replacement over 2,000 iterations. Finally, because eight models generate $\binom{8}{2} = 28$ comparisons — for which a naïve $\alpha = 0.05$ would give a family-wise error rate near $1 - 0.95^{28} \approx 0.76$ — the **Holm–Bonferroni step-down correction** is applied, controlling the family-wise error rate at $\alpha$ while retaining more power than Bonferroni.

## 3.6 Reproducibility

A global random seed of 42 is applied to NumPy and to the Python standard library. The temporal split is deterministic by construction. Every hyperparameter is declared in a single YAML configuration file that is snapshotted into the run's artefact directory alongside an `environment.json` recording interpreter and library versions. The reference run reported here was executed under Python 3.13.7 with NumPy 2.1.3, pandas 2.3.2, SciPy 1.16.2 and scikit-learn 1.7.2 on Windows 11. The complete pipeline is invoked with a single command, and the accompanying test suite of 193 unit tests passes in full.

---

# 4. System Architecture and Algorithmic Design

## 4.1 Architectural Overview

The system is organised into six strictly layered packages, each depending only on those below it: **data** (acquisition, cleaning, splitting) → **features** (interaction matrices, RFM, content) → **models** (eight recommenders) → **evaluation** (metrics, evaluator, statistics) → **business** (CLV, cross-sell, simulation) → **service** (REST API, CLI). The layering is enforced by the import graph and is what allows a new algorithm to be added without touching the orchestration code: models self-register in a `MODEL_REGISTRY` and are instantiated reflectively from configuration.

Three cross-cutting design decisions merit comment. Configuration is expressed as **frozen dataclasses** with validation in `__post_init__`, so an invalid experiment fails at construction rather than after forty minutes of computation. Failure of any single model during fitting is caught and logged rather than propagated, so that a comparison of eight systems is not lost to a defect in one. And every model implements an `explain(user, item)` method returning a human-readable rationale, which is what allows the deployed system to justify its decisions rather than merely issue them.

The architecture is also a response to the engineering risks specific to learned systems. Sculley *et al.* (2015) show that configuration debt, undeclared data dependencies, feedback loops and boundary erosion can dominate the maintenance cost of the model itself. Here, the temporal split, feature vocabulary, trained model and evaluation context are passed as explicit typed objects; configuration is snapshotted beside every result; and service schemas separate external identifiers from internal matrix indices. These boundaries do not eliminate distribution shift or exposure feedback, but they make the assumptions observable and testable. In that sense, reproducibility is not supplementary documentation: it is a property of the system design.

## 4.2 The Abstract Recommender

All models derive from a common abstract base declaring `fit`, `score`, `recommend` and `explain`. Two implementation details in the base class are worth recording. Top-*N* selection uses `np.argpartition`, which is $O(n)$, rather than a full sort at $O(n \log n)$; over 4,197 items and thousands of users this is a material saving. And the exclusion of already-purchased items is performed by assigning $-\infty$ to the corresponding scores before selection, which is both correct and branch-free.

## 4.3 The Interaction Layer

Following Hu, Koren and Volinsky (2008), the transaction log is aggregated to the (user, item) grain and converted into a confidence weight. Four transformations are available: `binary` ($c = 1$); `count` ($c = n_{ui}$, the number of distinct invoices); `log_count` ($c = 1 + \alpha \ln(1 + n_{ui})$); and `monetary` ($c = 1 + \alpha \ln(1 + r_{ui})$ on cumulative revenue). The default is `log_count`, on the reasoning that repeat purchase carries evidential value but with diminishing returns — the linear `count` scheme is dominated by wholesale bulk buyers and produces a matrix in which a handful of rows carry most of the mass.

Crucially, the number of distinct **invoices**, not the number of transaction lines, is the correct notion of repetition, since a single basket may contain the same article on several lines for operational reasons.

An **exponential recency decay** then multiplies each weight by $2^{-\Delta t / h}$, where $\Delta t$ is the age of the most recent interaction in days and $h$ = 180 days is the configured half-life. This is the mechanism through which the system implements the *dynamic* requirement of the brief: a customer's profile is not a static aggregate but a continuously re-weighted quantity in which recent behaviour dominates. It is also the interface through which click and view events would enter the system, were they available: they are simply additional interaction records with a different weight.

## 4.4 The Algorithms

**Popularity with recency decay.** Items are ranked by the number of distinct purchasers, exponentially discounted by a 90-day half-life so that the baseline reflects *current* rather than historical popularity. This is the mandatory baseline of Cremonesi, Koren and Turrin (2010) and represents the honest counterfactual: it is what the retailer would deploy in the absence of a recommender.

**Item-kNN.** The shrunk cosine similarity $s_{ij} = \langle v_i, v_j \rangle / (\|v_i\| \|v_j\| + \lambda)$ is computed with $\lambda = 20$, truncated to the 200 strongest neighbours per item, and applied as the sparse product $\hat{r}_u = c_u^\top S$. BM25 and TF–IDF re-weightings are available as alternatives.

**EASE^R.** The Gram matrix $G = X^\top X$ is formed, ridged by $\lambda = 250$ on the diagonal, and inverted. The implementation uses a **Cholesky factorisation** rather than an explicit inverse: this is roughly twice as fast and markedly better conditioned, and the ridge term guarantees the positive-definiteness the factorisation requires. The model refuses to fit above 16,000 items, at which point the dense $n \times n$ matrix would exceed 2 GB.

**iALS.** Twenty alternating sweeps over 128 factors with $\lambda = 0.05$ and $\alpha = 40$. The objective reported at each iteration is the *true* weighted objective including the $(mn - \mathrm{nnz})$ unobserved cells, computed in $O((m+n)f^2)$ through the Gram identity $\|UV^\top\|_F^2 = \mathrm{tr}((U^\top U)(V^\top V))$, rather than the observed-cells-only proxy that is commonly reported. Each per-row normal-equation system is solved **exactly**, by Cholesky factorisation of the symmetric positive-definite $f \times f$ matrix; the conjugate-gradient approximation of Takács, Pilászy and Tikk (2011) is deliberately not used, because at $f = 128$ the cubic term is dominated by the $O(\mathrm{nnz} \cdot f^2)$ accumulation and the exact solve is both faster to reason about and bit-for-bit reproducible. Iteration stops early when the relative change falls below $10^{-5}$.

**BPR-MF.** Ninety-six factors trained by stochastic gradient ascent on the pairwise log-sigmoid objective with learning rate 0.05, $L_2$ regularisation 0.01 and one uniformly sampled negative per positive. Following Rendle's LearnBPR, each epoch draws one triplet **per observed interaction** — 352,044 on this training partition, not one per customer — sampled uniformly over the observed $(u, i)$ pairs so that active customers are not under-weighted; updates are applied in mini-batches of 4,096 triplets, which is what makes the full schedule tractable in vectorised NumPy. The configured budget is 60 epochs, and convergence is tested only after a ten-epoch warm-up, because an untrained factorisation begins at $-\log \sigma(0) = \log 2$ with a vanishing gradient signal and a tight plateau test applied earlier cannot distinguish convergence from a model that has not yet started to move.

**Content-based.** Product descriptions are vectorised with TF–IDF over unigrams and bigrams, capped at 5,000 features with a minimum document frequency of two, and $L_2$-normalised. A user profile is the confidence-weighted mean of the vectors of purchased items, and scoring is the cosine between profile and item.

**Association rules.** Baskets are enumerated up to a maximum size of 60 items, pairwise co-occurrence counts are accumulated, and rules satisfying minimum support 0.001, minimum confidence 0.05 and minimum lift 1.0 are retained in a sparse lift matrix. Scoring a user is the sparse product of their purchase indicator with that matrix.

**Hybrid.** The default strategy is a weighted convex combination of **rank-normalised** base scores, with weights $\{$EASE 0.35, iALS 0.25, item-kNN 0.20, association rules 0.10, content 0.05, popularity 0.05$\}$. Rank normalisation is not a detail: mixing raw scores would let whichever model happens to have the largest numerical scale dominate the blend irrespective of its accuracy. Reciprocal Rank Fusion, switching on user activity, and cascade retrieval-then-rerank are implemented as alternatives.

## 4.5 The Service Layer

The system is exposed through a FastAPI application with six endpoints: `/health`, `/models`, `/recommend/{customer_id}`, `/cross-sell` (POST, accepting a basket), `/up-sell/{item_id}` and `/customer/{customer_id}`. Request and response schemas are declared as Pydantic models, from which OpenAPI documentation is generated automatically. Models are fitted once at start-up and held in memory; per-request work is confined to scoring and selection. A five-command CLI (`download`, `run`, `evaluate`, `recommend`, `serve`) provides the same functionality for batch use.

---

# 5. Exploratory Analysis and Data Preparation

## 5.1 Structural Characteristics of the Catalogue

Figure 5.1 characterises the cleaned interaction data along four complementary dimensions — the distribution of customer activity, the popularity profile of the catalogue, the concentration of demand, and the distribution of order values — and in doing so establishes the structural conditions that determine whether personalisation can recover value at all.

![](../notebooks/figures/fig_5_1_dataset_structure.png)

***Figure 5.1** — Structural characteristics of the Online Retail II dataset after cleaning. Panel (α) shows the distribution of customer activity measured as the number of distinct articles purchased; panel (β) plots item popularity on a logarithmic scale in descending rank order, revealing the long-tail structure with a Gini coefficient of 0.563; panel (γ) presents the Lorenz curve of demand concentration against the line of perfect equality; panel (δ) shows the distribution of order values with the mean and median indicated. Source: author's canonical final analysis.*

Panel (β) is the empirical foundation of the entire thesis. Item popularity follows the characteristic long-tailed distribution, with a Gini coefficient of **0.563** over 4,197 articles. Panel (γ) quantifies the same phenomenon: the Lorenz curve departs substantially from the diagonal, and the concentration analysis of §7.3 shows that the most popular third of the catalogue accounts for **84.9%** of revenue while the least popular third accounts for **3.0%**.

This is precisely the structure that makes personalisation valuable rather than merely fashionable. If demand were uniform, a global ranking would be nearly optimal and personalisation would recover little. Because demand is heavily concentrated *and* heterogeneous across customers, a single global ranking must be badly wrong for most individuals, and the size of that error is the opportunity available to a recommender.

Panel (α) shows customer activity to be similarly skewed (Gini 0.549), with a mean of 86.6 distinct articles per customer but a median of 49 — the mean exceeds the median by 77%, the signature of the wholesale buyers noted in §3.1. Panel (δ) shows the same asymmetry in monetary terms: mean order value £442.21 against a median substantially below it, over 35,845 invoices and total revenue of £15,851,014.

## 5.2 Temporal Dynamics

Figure 5.2 moves from the cross-sectional structure of the catalogue to its behaviour over time, showing how total demand evolves across the 738-day observation window and how orders are distributed over the trading week.

![](../notebooks/figures/fig_5_2_temporal_dynamics.png)

***Figure 5.2** — Temporal dynamics of demand across the 738-day observation window. Panel (α) shows the monthly evolution of revenue (left axis) and order volume (right axis), exhibiting the pronounced pre-Christmas peaks characteristic of the giftware sector; panel (β) shows the distribution of orders by day of week. Source: author's analysis.*

Figure 5.2 establishes that the process is strongly **non-stationary**. Revenue exhibits a pronounced annual cycle, rising steeply through October and November and collapsing in January, with the November peak reaching several multiples of the February trough. Panel (β) shows a marked weekday concentration with near-absent Saturday trading, consistent with a business-to-business order profile.

The methodological consequence is decisive and is the justification for §3.3: a random train–test split would place November interactions in the training set and February interactions in the test set *and vice versa*, allowing the model to exploit knowledge of a seasonal peak it could not possibly possess at serving time. Every reported figure in this thesis is therefore obtained under a strictly chronological partition.

## 5.3 The Cleaning Protocol

Figure 5.3 shows the cumulative effect of the eight-stage cleaning protocol specified in §3.2, tracing the attrition of transaction lines through each successive filter and identifying the filters that account for the greater part of it.

![](../notebooks/figures/fig_5_3_cleaning_attrition.png)

***Figure 5.3** — Auditable data-cleaning protocol. Panel (α) shows the sequential attrition of transaction lines through the eight filtering stages, from 1,067,371 raw records to 773,564 retained records; panel (β) shows the relative contribution of each filter to total attrition. Source: author's analysis.*

Table 5.1 reproduces the same cleaning report numerically, giving for each stage the number of rows entering the filter, the number surviving it, and the proportion removed.

**Table 5.1 — Sequential attrition through the cleaning protocol**

| # | Filter | Rows before | Rows after | Removed | % removed |
|---|--------|------------:|-----------:|--------:|----------:|
| 1 | Duplicate transaction lines | 1,067,371 | 1,033,034 | 34,337 | 3.22 |
| 2 | Cancellation invoices | 1,033,034 | 1,013,930 | 19,104 | 1.85 |
| 3 | Non-positive quantity | 1,013,930 | 1,010,537 | 3,393 | 0.33 |
| 4 | Price out of range | 1,010,537 | 1,007,885 | 2,652 | 0.26 |
| 5 | Extreme values (q = 0.999) | 1,007,885 | 1,005,925 | 1,960 | 0.19 |
| 6 | Non-product codes | 1,005,925 | 1,002,259 | 3,666 | 0.36 |
| 7 | Missing customer identifier | 1,002,259 | 775,566 | 226,693 | 22.62 |
| 8 | *k*-core (users ≥ 5, items ≥ 5) | 775,566 | 773,564 | 2,002 | 0.26 |
| | **Total** | **1,067,371** | **773,564** | **293,807** | **27.53** |

The dominant filter is by a wide margin the removal of guest checkouts, which alone eliminates 22.6% of records. This is not a data-quality defect but a structural feature of the domain: roughly a quarter of transactions are placed by customers who are never identified, and no collaborative model can represent them. It is worth stating the consequence plainly, since it is frequently glossed over in the applied literature: **a personalisation system is structurally incapable of serving approximately one quarter of this retailer's transactions**, and those transactions must continue to be served by the non-personalised fallback. The measured value of personalisation applies to the identified 77.4%, not to the whole business.

By contrast, the *k*-core filter removes only 0.26% of the remaining rows, converging after a small number of iterations. This indicates that the data were already reasonably dense at the five-interaction threshold and that the densification introduces negligible selection bias.

Table 5.2 summarises the descriptive statistics of the dataset that proceeds to the modelling stage, and so defines the empirical setting to which every subsequent result in this thesis refers.

**Table 5.2 — Descriptive statistics of the cleaned dataset**

| Quantity | Value |
|----------|------:|
| Transaction lines | 773,564 |
| Invoices | 35,845 |
| Unique customers | 5,527 |
| Unique products | 4,197 |
| Unique (user, item) interactions | 478,893 |
| Matrix density | 2.06% |
| Matrix sparsity | 97.94% |
| Mean / median items per customer | 86.6 / 49 |
| Mean / median customers per item | 114.1 / 64 |
| Mean / median basket size | 21.3 / 16 |
| Total revenue | £15,851,014 |
| Mean order value | £442.21 |
| Gini (item popularity) | 0.563 |
| Gini (customer activity) | 0.549 |
| Countries | 41 |
| Observation span | 738 days |

The resulting interaction matrix is **97.94% sparse** across the full observation window. This figure sets the difficulty of the learning problem: roughly one cell in fifty is observed, and every algorithm in Chapter 6 must infer preferences over thousands of articles from an average of 87 observations per customer. The matrix the models actually estimate is the training partition alone — 4,712 customers by 3,898 articles with 352,044 observed cells, or 98.08% sparse — because the vocabulary is derived from the training period only (§3.3).

## 5.4 Verification of Temporal Consistency

Figure 5.4 demonstrates that the splitting protocol of §3.3 behaves exactly as specified, showing the training, validation and test periods as chronologically disjoint intervals together with the number of transaction lines each contains.

![](../notebooks/figures/fig_5_4_temporal_split.png)

***Figure 5.4** — Temporally consistent partitioning of the interaction log. Panel (α) shows weekly order volume coloured by partition, demonstrating that the training, validation and test periods are chronologically disjoint with no overlap; panel (β) shows the resulting partition sizes in transaction lines. Source: author's analysis.*

Figure 5.4 is presented as evidence rather than illustration. Panel (α) shows the three partitions as contiguous, non-overlapping intervals on the time axis: no training interaction postdates any test interaction. The property is additionally asserted in code (`assert train.invoice_date.max() < test.invoice_date.min()`) and covered by the unit test `test_no_temporal_leakage`.

The partition boundaries fall at the 70th and 80th percentiles of the timestamp distribution, yielding a training period of approximately 562 days and validation and test periods of approximately 87 days each. The partitions are therefore markedly unequal in duration relative to the share of interactions they carry: the training window absorbs 70% of interactions across 562 days, whereas the test window absorbs 20% across only 87 days, a transaction density roughly twice that of the training period. Validation and test span the same number of days yet differ twofold in volume — itself a further illustration of the non-stationarity documented in §5.2, and a reminder that quantile-balanced partitions are not calendar-balanced.

---

# 6. Empirical Results: Comparative Algorithm Evaluation

## 6.1 Accuracy

Figure 6.1 summarises the comparative accuracy of the eight systems from four complementary perspectives: their ordering on the primary metric, their behaviour across the full accuracy vector, the stability of that ordering as the evaluation depth varies, and the precision–recall field they jointly occupy.

![](../notebooks/figures/fig_6_1_accuracy_comparison.png)

***Figure 6.1** — Comparative accuracy evaluation of the eight systems over the evaluated users with full-catalogue ranking. Panel (α) ranks the models on the primary metric NDCG@10; panel (β) compares precision, recall, MAP, MRR and hit rate at k = 10; panel (γ) shows the stability of the model ordering across cut-offs k in {5, 10, 20}; panel (δ) plots the precision–recall field at k = 10. Source: author's analysis.*

Table 6.1 reports the primary result of the thesis, giving the complete accuracy vector at *k* = 10 for all eight systems together with the improvement of each over the non-personalised baseline.

**Table 6.1 — Accuracy at k = 10 (2,007 users, full-catalogue ranking)**

| Rank | Model | NDCG@10 | Precision@10 | Recall@10 | Hit rate@10 | MAP@10 | MRR@10 | Lift vs baseline |
|:----:|-------|--------:|-------------:|----------:|------------:|-------:|-------:|-----------------:|
| 1 | **EASE** | **0.0922** | 0.0772 | 0.0510 | 0.4654 | 0.0416 | 0.2056 | **+107.8%** |
| 2 | Hybrid (weighted) | 0.0895 | 0.0768 | 0.0499 | 0.4584 | 0.0398 | 0.1967 | +101.8% |
| 3 | Content-based | 0.0749 | 0.0593 | 0.0411 | 0.3413 | 0.0360 | 0.1684 | +68.8% |
| 4 | BPR-MF | 0.0676 | 0.0592 | 0.0361 | 0.3772 | 0.0284 | 0.1524 | +52.4% |
| 5 | Item-kNN | 0.0622 | 0.0540 | 0.0307 | 0.3303 | 0.0274 | 0.1399 | +40.3% |
| 6 | iALS | 0.0615 | 0.0543 | 0.0373 | 0.3692 | 0.0247 | 0.1401 | +38.7% |
| 7 | Association rules | 0.0516 | 0.0487 | 0.0315 | 0.3084 | 0.0209 | 0.1053 | +16.3% |
| 8 | *Popularity (baseline)* | 0.0444 | 0.0418 | 0.0216 | 0.2895 | 0.0168 | 0.1018 | — |

**RQ1 is answered affirmatively and with a large effect size.** The best personalised system attains an NDCG@10 of 0.0922 against the non-personalised baseline's 0.0444, an improvement of **107.8%**. In operational terms, the hit rate at ten recommendations rises from 28.9% to 46.5%: whereas the popularity carousel contains at least one subsequently purchased item for roughly two customers in seven, the personalised carousel does so for nearly one in two. Since a recommendation module has a fixed number of slots, this is precisely the quantity that determines whether the module earns its screen real estate. All seven personalised systems beat the baseline, so the *existence* of a personalisation dividend is not in doubt; its size varies by nearly a factor of seven.

**RQ2 receives a more interesting answer.** The winner is **EASE** — a linear autoencoder with a closed-form solution and a single hyperparameter, fitted in 0.74 seconds. It outperforms iALS (128 latent factors, 50.5 seconds) by 49.8% and BPR-MF (96 factors, 98.2 seconds) by 36.3%. Between them the two latent-factor methods consumed 201 times EASE's training budget to finish fifth and fourth. Algorithmic sophistication, on this evidence, is not merely a weak predictor of empirical performance; over this range it is close to being an inverted one. This independently reproduces the central claim of Ferrari Dacrema, Cremonesi and Jannach (2019) on a dataset and an implementation entirely distinct from theirs, and it is the most important scientific finding of the thesis.

Two results require honest interpretation rather than presentation.

**The content-based model placed third.** This is unusual — content methods typically trail collaborative ones — and the explanation lies in the structure of this specific catalogue. Product descriptions in *Online Retail II* are short, highly formulaic and encode product family, colour and material in a stereotyped vocabulary (`JUMBO BAG RED RETROSPOT`, `JUMBO BAG STRAWBERRY`, `LUNCH BAG RED SPOTTY`). TF–IDF over such text is an unusually effective proxy for substitutability, and because customers in this dataset buy heavily within product families, content similarity captures a large fraction of the true preference signal. The result should not be generalised: on a catalogue with free-form marketing copy it would very probably not hold.

**The mid-table is a cluster, not a ranking.** Content-based, BPR-MF, Item-kNN and iALS occupy positions three to six separated by only 0.0134 NDCG points, and §6.3 shows that none of the six comparisons among them survives multiplicity correction. The honest reading of Table 6.1 is two well-separated leaders, a four-way tie, association rules, and the baseline.

Panel (γ) of Figure 6.1 shows that the ordering is nearly invariant to the cut-off. The two leaders and the bottom two hold their positions at *k* = 5, 10 and 20, and the only movement is a single adjacent exchange inside the tied cluster: iALS overtakes Item-kNN at *k* = 20 (0.0658 against 0.0639), consistent with its stronger recall and weaker precision. The conclusion is therefore not an artefact of the chosen evaluation depth.

## 6.2 Beyond Accuracy

Figure 6.2 turns from accuracy to the properties that determine how much of the catalogue a recommender actually exposes, locating each system in the accuracy–coverage field and comparing the novelty, popularity bias and multi-criteria profile of the leading candidates.

![](../notebooks/figures/fig_6_2_beyond_accuracy.png)

***Figure 6.2** — Beyond-accuracy evaluation. Panel (α) plots NDCG@10 against catalogue coverage@10, revealing the accuracy–exposure field; panel (β) compares novelty measured in bits of self-information; panel (γ) shows popularity bias, where lower values indicate less dependence on the head of the distribution; panel (δ) presents a normalised multi-criteria profile of the four leading systems. Source: author's analysis.*

Table 6.2 reports these beyond-accuracy metrics numerically for all eight systems, ordered by coverage so that the exposure behaviour of the accuracy leaders can be read against that of the baseline.

**Table 6.2 — Beyond-accuracy metrics at k = 10**

| Model | Coverage@10 | Items exposed | Novelty@10 (bits) | Diversity@10 | Serendipity@10 | Popularity bias@10 | Exposure Gini |
|-------|------------:|--------------:|------------------:|-------------:|---------------:|-------------------:|--------------:|
| Popularity | 1.82% | 71 | 2.76 | 0.943 | 0.0041 | 0.557 | 0.996 |
| Item-kNN | 12.03% | 469 | 2.97 | 0.904 | 0.0025 | 0.488 | 0.987 |
| Hybrid | 21.45% | 836 | 3.62 | 0.911 | 0.0133 | 0.321 | 0.933 |
| **EASE** | **27.81%** | **1,084** | 3.73 | 0.945 | 0.0195 | 0.313 | 0.909 |
| Association rules | 34.97% | 1,363 | 5.02 | 0.894 | 0.0307 | 0.144 | 0.836 |
| iALS | 42.23% | 1,646 | 4.08 | 0.949 | 0.0149 | 0.245 | 0.826 |
| BPR-MF | 42.74% | 1,666 | 3.79 | 0.943 | 0.0122 | 0.313 | 0.872 |
| Content-based | 52.54% | 2,048 | 5.56 | 0.696 | 0.0407 | 0.132 | 0.853 |

This table contains the most commercially consequential number in the thesis. The popularity baseline exposes **71 distinct articles** across 2,007 customers — 1.82% of the training catalogue — with an exposure Gini of 0.996, very nearly the theoretical maximum for a sample of this size. The non-personalised storefront therefore renders **98.2% of the assortment commercially invisible**.

EASE raises coverage to 27.81%, a 15.3-fold increase, exposing 1,084 articles. It simultaneously reduces popularity bias from 0.557 to 0.313 — a 43.9% reduction — and raises novelty from 2.76 to 3.73 bits, so that the recommended items are on average roughly twice as improbable *a priori*. Serendipity rises by a factor of 4.8, from 0.0041 to 0.0195: EASE finds relevant items that the popularity ranker could not have surfaced to anyone. The absolute serendipity levels are small by construction, since the metric counts only recommendations that are simultaneously correct and outside the baseline's reachable set; the ratio between systems is the interpretable quantity.

**RQ3 therefore admits a nuanced answer.** The classical accuracy–diversity dilemma (Zhou *et al.*, 2010) predicts that these objectives trade off. Over the range that matters commercially, they do not: EASE dominates the baseline on *every* axis simultaneously — more accurate, broader coverage, more novel, more serendipitous, less popularity-biased. The frontier becomes visible further out, where content-based and association-rule mining reach 52.5% and 35.0% coverage at a 19% and 44% accuracy discount respectively. The correct statement is that the trade-off is real but that the popularity baseline sits far inside the efficient frontier, so a large region of joint improvement is available before any sacrifice becomes necessary.

Two results run against the general pattern. The content-based model has the *lowest* intra-list diversity (0.696 against 0.945 for EASE), the expected over-specialisation pathology: scoring by textual similarity to the profile makes its ten recommendations ten variations of one proposition. High coverage across the population is thus compatible with low diversity within each list, and the two metrics must be read together. Item-kNN, meanwhile, records the lowest serendipity of any system, below even the baseline: its shrunk cosine concentrates on co-purchase among frequently bought articles, so the relevant items it recovers are largely those the baseline would have found anyway.

## 6.3 Statistical Validation

Figure 6.3 subjects the differences observed in §6.1 to formal inference, presenting the matrix of pairwise significance, the mean per-user ranks of the competing systems, and the estimated effect sizes with their confidence intervals.

![](../notebooks/figures/fig_6_3_statistical_validation.png)

***Figure 6.3** — Statistical validation of the pairwise comparisons. Panel (α) shows the matrix of uncorrected Wilcoxon signed-rank p-values for NDCG@10; panel (β) shows mean per-user ranks in the manner of Demšar (2006); panel (γ) is a forest plot of effect sizes with 95% paired bootstrap confidence intervals, with comparisons remaining significant after Holm–Bonferroni correction highlighted. Source: author's analysis.*

Table 6.3 reports a representative subset of the twenty-eight pairwise comparisons, each with its effect size, its bootstrap interval and its Holm-corrected significance.

**Table 6.3 — Selected pairwise comparisons on NDCG@10 (Wilcoxon, Holm-corrected)**

| Comparison (A vs B) | Δ (B − A) | 95% bootstrap CI | *p* (Holm) | Significant |
|---------------------|----------:|------------------|-----------:|:-----------:|
| Popularity vs EASE | +0.0431 | [+0.0378, +0.0485] | < 0.0001 | Yes |
| Popularity vs Hybrid | +0.0412 | [+0.0359, +0.0467] | < 0.0001 | Yes |
| Popularity vs Content-based | +0.0268 | [+0.0208, +0.0328] | < 0.0001 | Yes |
| Popularity vs iALS | +0.0157 | [+0.0107, +0.0204] | < 0.0001 | Yes |
| Popularity vs Item-kNN | +0.0170 | [+0.0133, +0.0211] | < 0.0001 | Yes |
| Popularity vs Association rules | +0.0066 | [+0.0018, +0.0115] | 0.1244 | No |
| Item-kNN vs EASE | +0.0299 | [+0.0248, +0.0356] | < 0.0001 | Yes |
| iALS vs EASE | +0.0307 | [+0.0258, +0.0361] | < 0.0001 | Yes |
| BPR-MF vs EASE | +0.0246 | [+0.0194, +0.0301] | < 0.0001 | Yes |
| Content-based vs EASE | +0.0173 | [+0.0108, +0.0239] | < 0.0001 | Yes |
| **EASE vs Hybrid** | **−0.0026** | **[−0.0065, +0.0011]** | **1.0000** | **No** |
| iALS vs BPR-MF | +0.0061 | [+0.0015, +0.0110] | 0.8276 | No |
| iALS vs Item-kNN | +0.0007 | [−0.0048, +0.0060] | 0.8276 | No |
| iALS vs Content-based | +0.0134 | [+0.0065, +0.0202] | 1.0000 | No |
| BPR-MF vs Content-based | +0.0073 | [+0.0006, +0.0142] | 1.0000 | No |
| BPR-MF vs Item-kNN | −0.0054 | [−0.0104, −0.0001] | 0.0953 | No |
| Content-based vs Item-kNN | −0.0127 | [−0.0196, −0.0060] | 0.2523 | No |
| Association rules vs Popularity | −0.0072 | [−0.0124, −0.0020] | 0.8276 | No |

*Note: each row is labelled in the direction stated in its first column, so Δ is the mean advantage of the second-named system over the first. The machine-readable `significance_tests.csv` stores every pair with the models ordered alphabetically and Δ = mean(B) − mean(A); rows whose label order differs from alphabetical order therefore appear there with the opposite sign on Δ and on both confidence limits. All 28 pairwise comparisons were computed; the table reports a representative subset.*

Of the 28 comparisons, **20 remain significant** at $\alpha = 0.05$ after Holm–Bonferroni correction. Four findings deserve emphasis.

**EASE's superiority is statistically robust.** Its advantage over every other system except the hybrid is significant after correction, with confidence intervals that exclude zero by a comfortable margin. The comparison against the popularity baseline yields Δ = 0.0478 with a 95% interval of [0.0418, 0.0545] — the entire interval lies well above zero, so the conclusion does not depend on the choice of significance threshold.

**EASE and the hybrid are statistically indistinguishable** (Δ = −0.0026, CI [−0.0065, +0.0011], *p* = 1.0000). The interval straddles zero and is narrow, which is stronger than a mere failure to reject: the two systems are equivalent to within roughly ±0.006 NDCG. The hybrid must fit and query six base models to achieve what EASE achieves alone, and it costs 54 times the serving latency (§6.4). Its justification must therefore rest on robustness to component failure and cold-start handling, not on accuracy.

**The four mid-table systems are mutually indistinguishable.** None of the six comparisons among content-based, BPR-MF, Item-kNN and iALS survives correction, with corrected *p*-values from 0.0953 to 1.0000. Several of these pairs have bootstrap intervals that exclude zero — iALS versus content-based gives Δ = +0.0134 with CI [+0.0065, +0.0202] — while the paired signed-rank test does not reject. The two procedures answer different questions: the interval concerns the *mean* difference, the Wilcoxon test the *per-customer* balance of wins and losses. When one system wins on breadth (iALS has the higher hit rate) while its rival wins on placement (content-based has the higher MRR), per-customer outcomes can be near-balanced even though the means differ. Where they disagree, this thesis defers to the corrected paired test, which respects the family-wise error rate.

**Association rules are not significantly better than popularity** after correction (*p* = 0.8276). Their apparent 16.3% advantage does not survive multiplicity control. This is exactly the kind of claim that an uncorrected analysis would have reported as a finding, and it illustrates why the correction is not optional.

Panel (β) of Figure 6.3 reports mean per-user ranks: EASE 3.966, hybrid 3.986, BPR-MF 4.490, content-based 4.561, iALS 4.574, item-kNN 4.654, association rules 4.867, popularity 4.902. The rank-based ordering agrees with the mean-based ordering on the two leaders and the two laggards, and compresses the middle four into a span of 0.164 rank units — corroborating the tie identified above. The near-identity of the EASE and hybrid mean ranks likewise corroborates the equivalence finding.

## 6.4 Computational Cost

Figure 6.4 considers the cost at which the preceding accuracy is obtained, reporting the training time and serving latency of each system alongside the accuracy it returns per unit of training expenditure.

![](../notebooks/figures/fig_6_4_computational_cost.png)

***Figure 6.4** — Computational footprint of the algorithms. Panel (α) shows training time on a logarithmic scale; panel (β) shows per-user ranking latency at serving time; panel (γ) plots accuracy per unit of training cost. Source: author's analysis.*

Table 6.4 reports these measurements numerically, together with the accuracy each system yields per second of training time.

**Table 6.4 — Computational cost**

| Model | Training time (s) | Ranking latency per user (ms) | NDCG@10 per second of training |
|-------|------------------:|------------------------------:|-------------------------------:|
| Content-based | 0.02 | 1.33 | 3.746 |
| Popularity | 0.05 | 1.30 | 0.887 |
| Association rules | 0.22 | 1.31 | 0.235 |
| Item-kNN | 0.72 | 1.35 | 0.086 |
| **EASE** | **0.74** | **1.59** | **0.125** |
| iALS | 50.50 | 1.29 | 0.0012 |
| BPR-MF | 98.24 | 1.29 | 0.0007 |
| Hybrid | 0.00* | 85.6 | — |

*\*The hybrid does not fit parameters of its own; it composes pre-fitted base models. Its effective training cost is the sum of its components.*

Three observations follow. First, EASE achieves the best accuracy at approximately **1/68th** of the training cost of iALS and **1/133rd** of that of BPR-MF. The closed-form solution requires a single Cholesky factorisation of a 3,898 × 3,898 matrix; there is no optimisation loop, no learning rate and no convergence criterion. For a catalogue of this size the model can be refitted from scratch in under a second, which makes near-real-time adaptation to inventory changes trivially achievable.

Second, **every model comfortably meets a 100 ms online budget**, with per-user ranking latencies between 1.29 and 1.59 ms. This follows from scoring users in blocks through the `score_batch()` interface, which performs one dense matrix product per block of 512 customers instead of one sparse-by-dense product per customer; the same change reduced the evaluation stage from roughly 1,040 seconds to 194. EASE's 1.59 ms is the highest of the single models, as expected given that its scoring step multiplies the user's history vector by a dense 3,898 × 3,898 weight matrix, but the margin is immaterial at this scale.

Third, the hybrid is the one genuine latency outlier at 85.6 ms per user — still inside the budget, but 54 times the cost of EASE, because it must score six component models and fuse their rank vectors for every request. Combined with the statistical equivalence of §6.3, this is a decisive argument for deploying EASE alone.

---

# 7. From Rankings to Revenue: The Business Layer

Chapter 6 established that personalisation improves ranking quality. Management, however, does not fund NDCG. This chapter constructs the bridge, making every assumption explicit and auditable in preference to quoting an accuracy improvement and leaving the reader to imagine its commercial consequence.

## 7.1 Customer Segmentation and Lifetime Value

Figure 7.1 shifts the unit of analysis from the catalogue to the customer base, showing how revenue is distributed across behavioural segments and how sharply predicted lifetime value is concentrated within the population.

![](../notebooks/figures/fig_7_1_rfm_clv.png)

***Figure 7.1** — Customer segmentation and predicted lifetime value. Panel (α) shows revenue contribution by RFM segment; panel (β) contrasts the share of customers with the share of revenue for each segment; panel (γ) shows the distribution of predicted CLV; panel (δ) shows the concentration of predicted value across customer deciles. Source: author's analysis.*

Table 7.1 reports the resulting segmentation numerically, ordered by revenue contribution.

**Table 7.1 — RFM segmentation (5,527 customers)**

| Segment | Customers | % of customers | Revenue (£) | % of revenue | Mean recency (days) | Mean frequency |
|---------|----------:|---------------:|------------:|-------------:|--------------------:|---------------:|
| Champions | 1,381 | 24.99 | 11,001,966 | **69.41** | 18.8 | 16.0 |
| Loyal Customers | 483 | 8.74 | 1,660,713 | 10.48 | 95.1 | 8.9 |
| At Risk | 792 | 14.33 | 1,396,544 | 8.81 | 350.4 | 5.3 |
| Potential Loyalist | 675 | 12.21 | 600,562 | 3.79 | 24.4 | 2.7 |
| Need Attention | 267 | 4.83 | 328,210 | 2.07 | 101.4 | 3.3 |
| About to Sleep | 563 | 10.19 | 250,426 | 1.58 | 300.9 | 1.4 |
| Promising | 355 | 6.42 | 210,179 | 1.33 | 97.8 | 1.4 |
| Hibernating | 355 | 6.42 | 186,666 | 1.18 | 531.0 | 1.6 |
| Lost | 501 | 9.06 | 165,620 | 1.04 | 555.4 | 1.0 |
| Recent Customers | 155 | 2.80 | 50,128 | 0.32 | 29.2 | 1.0 |

The segmentation is severely concentrated: **Champions constitute 25% of the customer base and generate 69% of revenue**, approximating the Pareto structure. Two segments carry immediate operational significance. *At Risk* customers — 792 accounts, 8.8% of revenue, mean recency 350 days but mean frequency 5.3 — have demonstrated substantial historical value and have lapsed; they are the highest-return target for reactivation. *Potential Loyalists* — 675 accounts, recent but infrequent — are the natural target for cross-sell, since the objective is to increase basket breadth rather than to recover a lapsed relationship.

The probabilistic model refines this picture. The BG/NBD model was estimated by maximum likelihood using multi-start Nelder–Mead optimisation over the unconstrained region $r, \alpha, a, b > 0$, yielding $r = 0.665$, $\alpha = 51.44$, $a = 0.130$, $b = 2.334$ with a log-likelihood of −147,812; the Gamma–Gamma monetary model yielded $p = 1.843$, $q = 4.172$, $v = 609.24$.

Two remarks are required for interpretation. First, the dropout shape $a = 0.130$ lies below unity. This is admissible and indeed expected — Fader, Hardie and Lee's own CDNOW estimate is $a = 0.793$ — but it matters substantively: a Beta$(0.130, 2.334)$ mixing distribution is J-shaped rather than unimodal, implying that customers are *polarised* between those with a very low per-transaction dropout probability and those who churn almost immediately. The implied population mean dropout probability is $a/(a+b) = 5.3\%$ per transaction. Second, the Gamma–Gamma model assumes independence between purchase frequency and monetary value; the decile table shows mean monetary value rising broadly with frequency (£95 in the bottom decile to £628 in the top), which is prima facie evidence that this assumption is violated. The CLV figures are therefore best read as a *value ordering* rather than as calibrated monetary forecasts.

Table 7.2 reports how that value ordering distributes predicted forward value across customer deciles.

**Table 7.2 — Concentration of predicted 365-day CLV by decile**

| Decile | Customers | Total CLV (£) | Mean CLV (£) | Mean frequency | Mean monetary (£) | % of total CLV |
|:------:|----------:|--------------:|-------------:|---------------:|------------------:|---------------:|
| 1 (top) | 553 | 1,554,892 | 2,811.74 | 24.92 | 627.83 | **55.87** |
| 2 | 553 | 401,546 | 726.12 | 8.80 | 406.54 | 14.43 |
| 3 | 552 | 258,906 | 469.03 | 6.01 | 314.51 | 9.30 |
| 4 | 553 | 182,476 | 329.98 | 4.09 | 245.38 | 6.56 |
| 5 | 552 | 132,569 | 240.16 | 2.75 | 220.12 | 4.76 |
| 6 | 553 | 95,196 | 172.15 | 2.46 | 230.24 | 3.42 |
| 7 | 553 | 65,560 | 118.55 | 1.89 | 220.67 | 2.36 |
| 8 | 552 | 43,432 | 78.68 | 1.13 | 151.69 | 1.56 |
| 9 | 553 | 30,649 | 55.42 | 0.64 | 57.18 | 1.10 |
| 10 (bottom) | 553 | 17,718 | 32.04 | 2.16 | 94.64 | 0.64 |

The top decile — 10% of customers — accounts for **55.9%** of total predicted forward value, and the top two deciles for 70.3%. Total predicted 365-day value across the base is £2.78 million. The managerial implication is direct: personalisation effort, and any marginal serving cost it entails, should be allocated in proportion to predicted value rather than uniformly. The system operationalises this by exposing the CLV table through the `/customer/{id}` endpoint, allowing the interface to condition recommendation depth and merchandising aggression on predicted value.

## 7.2 Cross-Selling, Up-Selling and the Long Tail

Figure 7.2 examines the two merchandising mechanisms the brief names explicitly, characterising the mined association-rule space and the strength of the relationships it contains, and then contrasting the revenue each popularity tercile generates with the exposure it actually receives.

![](../notebooks/figures/fig_7_2_crosssell_longtail.png)

***Figure 7.2** — Cross-selling mechanics and long-tail exposure. Panel (α) shows the mined rule space in support–confidence coordinates; panel (β) shows the distribution of lift; panel (γ) contrasts revenue share with exposure share by popularity tercile; panel (δ) shows the proportion of articles receiving at least one impression within each tercile. Source: author's analysis.*

The cross-sell engine ranks complements for a basket by a convex blend of association-rule lift and expected margin, $\mathrm{score} = (1-w)\,\widetilde{\mathrm{lift}} + w\,\widetilde{\mathrm{margin}}$ with $w = 0.3$, restricted to items not already in the basket. At $w = 0$ the engine maximises attach probability; at $w = 1$ it maximises immediate profit and will cheerfully suggest irrelevant expensive items; the default reflects the standard merchandising compromise. Table 7.3 reproduces representative output of the engine, giving for each anchor article the complement it selects together with the lift and margin that justify the pairing.

**Table 7.3 — Representative cross-sell suggestions**

| Anchor article | Suggested complement | Lift | Price (£) | Margin (£) |
|----------------|----------------------|-----:|----------:|-----------:|
| REGENCY CAKESTAND 3 TIER | PINK REGENCY TEACUP AND SAUCER | 6.25 | 2.92 | 1.02 |
| REGENCY CAKESTAND 3 TIER | GREEN REGENCY TEACUP AND SAUCER | 6.18 | 2.91 | 1.02 |
| BAKING SET 9 PIECE RETROSPOT | BAKING SET SPACEBOY DESIGN | 13.35 | 4.93 | 1.73 |
| JUMBO BAG RED RETROSPOT | JUMBO BAG STRAWBERRY | 7.38 | 1.94 | 0.68 |
| PARTY BUNTING | TEA TIME PARTY BUNTING | 9.23 | 4.71 | 1.65 |
| WHITE HANGING HEART T-LIGHT HOLDER | CANDLEHOLDER PINK HANGING HEART | 5.09 | 2.92 | 1.02 |
| PACK OF 72 RETRO SPOT CAKE CASES | PACK OF 60 DINOSAUR CAKE CASES | 7.89 | 0.55 | 0.19 |

The suggestions are commercially sensible without any hand-authored merchandising rule: a cake stand attracts matching teacups, a bunting attracts complementary buntings. A lift of 13.35 for the baking-set pairing means customers who bought the first are thirteen times more likely than the population to buy the second — a relationship no editor would have to be told, but also one that scales to 4,197 articles without editorial labour, which is precisely the automation objective of the brief.

The up-sell engine operates on a different principle. Substitutability is approximated by content similarity, restricted to a **price corridor** of $[1.15\times, 3.0\times]$ the anchor price; an article twenty times more expensive is not an up-sell. Representative output includes `WHITE HANGING HEART T-LIGHT HOLDER` (£2.90) → `WHITE HANGING BEADS CANDLE HOLDER` (£5.43, 1.9×, similarity 0.49) and `BAKING SET 9 PIECE RETROSPOT` (£4.92) → `COOKING SET RETROSPOT` (£9.87, 2.0×, similarity 0.48). The distinction between the two engines is commercially material: cross-selling grows basket size, up-selling grows average unit value, and a system that conflates the objectives under-performs on both.

Table 7.4 sets the exposure that the best-performing model actually delivers against the revenue each popularity tercile generates, and so tests directly whether the long tail is being commercially activated.

**Table 7.4 — Revenue and exposure by popularity tercile (EASE, k = 10)**

| Tercile | Articles | Revenue share | Exposure share | Articles exposed | Penetration |
|---------|---------:|--------------:|---------------:|-----------------:|------------:|
| Head (top 33%) | 1,300 | 84.88% | 98.06% | 819 | 63.00% |
| Torso (middle 33%) | 1,299 | 12.12% | 1.91% | 106 | 8.16% |
| Tail (bottom 33%) | 1,299 | 3.00% | 0.03% | 1 | 0.08% |

Table 7.4 is the most sobering result in the chapter, and it qualifies the coverage improvement of §6.2 substantially. Although EASE exposes 1,084 distinct articles against the baseline's 71, that exposure remains overwhelmingly concentrated: 98.1% of impressions fall on the head tercile, and the tail tercile receives 0.03% of impressions across a single article. The long tail is *not* being commercially activated. A recommender trained on purchase co-occurrence necessarily inherits the exposure bias of the data that generated it — items that were never shown were never bought, and so appear uninformative. Breaking this feedback loop requires deliberate exploration mechanisms (bandit-style $\varepsilon$-greedy insertion, or explicit exposure-fairness constraints in the objective) that lie outside the scope of this implementation and are identified as a priority extension in §9.3.

## 7.3 Revenue Simulation

Figure 7.3 completes the chain from ranking quality to commercial outcome, presenting the projected incremental revenue of each system, the modelled conversion funnel, and the sensitivity of the projection to the one parameter that cannot be estimated from the data.

![](../notebooks/figures/fig_7_3_revenue_simulation.png)

***Figure 7.3** — Economic valuation of personalisation. Panel (α) shows projected incremental revenue by model; panel (β) contrasts the conversion funnel of the baseline with that of the best model on a logarithmic scale; panel (γ) shows the sensitivity of the projected uplift to the elasticity parameter ε; panel (δ) shows the translation of NDCG into projected revenue. Source: author's analysis.*

The simulation is a four-stage funnel — impressions → clicks → purchases → revenue → margin — driven by

$$\mathrm{CTR}_{\text{model}} = \mathrm{CTR}_{\text{base}} \cdot \left(1 + \varepsilon \cdot \frac{\mathrm{NDCG}_{\text{model}} - \mathrm{NDCG}_{\text{base}}}{\mathrm{NDCG}_{\text{base}}}\right),$$

where $\varepsilon$ is the sensitivity of click-through to relative ranking improvement. The parameters are: 1,000,000 impressions, baseline CTR 2.0%, attach rate (probability of purchase given click) 12%, average order value £442.21 taken from the data, gross margin 35%, and $\varepsilon = 1.8$.

One structural property of this construction governs how the output may be read. Revenue is *linear* in CTR and the baseline passes through the identical funnel, so the impressions count, attach rate, average order value and gross margin all cancel from the percentage uplift, leaving the identity $\text{uplift\%} = 100\,\varepsilon\,\Delta\mathrm{NDCG}_{\text{rel}}$. The percentage column of Table 7.5 is therefore a restatement of the NDCG lift scaled by $\varepsilon$, not independent corroboration of it. The funnel's contribution is to convert that relative statement into *absolute* pounds and to make every assumption explicit.

Table 7.5 reports the funnel outcomes these assumptions imply for each system.

**Table 7.5 — Projected funnel outcomes at ε = 1.8 over 1,000,000 impressions**

| Model | NDCG lift | CTR | Clicks | Purchases | Revenue (£) | Margin (£) | Revenue uplift |
|-------|----------:|----:|-------:|----------:|------------:|-----------:|---------------:|
| **EASE** | +107.8% | 5.88% | 58,794 | 7,055 | 3,119,904 | 1,091,966 | **+194.0%** |
| Hybrid | +101.8% | 5.67% | 56,653 | 6,798 | 3,006,281 | 1,052,198 | +183.3% |
| Content-based | +68.8% | 4.48% | 44,783 | 5,374 | 2,376,433 | 831,752 | +123.9% |
| BPR-MF | +52.4% | 3.89% | 38,870 | 4,664 | 2,062,664 | 721,933 | +94.4% |
| Item-kNN | +40.3% | 3.45% | 34,502 | 4,140 | 1,830,862 | 640,802 | +72.5% |
| iALS | +38.7% | 3.39% | 33,916 | 4,070 | 1,799,741 | 629,909 | +69.6% |
| Association rules | +16.3% | 2.59% | 25,876 | 3,105 | 1,373,116 | 480,591 | +29.4% |
| *Popularity (baseline)* | — | 2.00% | 20,000 | 2,400 | 1,061,304 | 371,456 | — |

The headline projection is an incremental **£2.06 million** of revenue and **£721,000** of gross margin per million impressions, relative to the non-personalised baseline.

This number should be treated with the scepticism it deserves, and the analysis is constructed to make that scepticism actionable. Beyond the linearity property noted above, the average order value of £442.21 is the mean value of a whole *invoice*, whereas the modelled conversion is the purchase of a single recommended article; since the mean basket contains 21.3 lines, the absolute pound figures are better read as an order of magnitude than a point forecast. The elasticity $\varepsilon$ is the single judgemental input and cannot be verified offline. Table 7.6 therefore reports the projection across a range spanning conservative to optimistic values.

**Table 7.6 — Sensitivity of projected revenue uplift (%) to the elasticity ε**

| ε | Popularity | Association rules | iALS | Item-kNN | BPR-MF | Content-based | Hybrid | EASE |
|:-:|-----------:|------------------:|-----:|---------:|-------:|--------------:|-------:|-----:|
| 0.5 | 0.0 | +8.2 | +19.3 | +20.1 | +26.2 | +34.4 | +50.9 | +53.9 |
| 1.0 | 0.0 | +16.3 | +38.7 | +40.3 | +52.4 | +68.8 | +101.8 | +107.8 |
| 1.5 | 0.0 | +24.5 | +58.0 | +60.4 | +78.6 | +103.3 | +152.7 | +161.6 |
| 1.8 | 0.0 | +29.4 | +69.6 | +72.5 | +94.4 | +123.9 | +183.3 | +194.0 |
| 2.5 | 0.0 | +40.8 | +96.6 | +100.7 | +131.0 | +172.1 | +254.5 | +269.4 |
| 3.0 | 0.0 | +49.0 | +116.0 | +120.9 | +157.3 | +206.5 | +305.4 | +323.3 |

**RQ4 is answered as follows.** The point projection is highly sensitive to $\varepsilon$, ranging from +54% to +323%. The *qualitative* conclusion, however, is entirely insensitive: at every value of the elasticity, including the most conservative, personalisation produces a large positive uplift and the model ordering is preserved. Because the uplift is exactly proportional to $\varepsilon$, this sweep quantifies how much the conclusion depends on an unverifiable parameter rather than serving as an independent robustness check. The claim that survives is therefore not "personalisation is worth £2.06 million" but "personalisation is worth between roughly £570,000 and £3.43 million per million impressions, with the ordering of alternatives unaffected by the uncertainty". This is a weaker but defensible claim, and it is the correct one to make from offline evidence.

Three residual limitations must be stated. The model assumes the relationship between NDCG and CTR is linear in relative improvement, whereas the true relationship is almost certainly concave and saturating; a constant-elasticity specification would be better behaved and is noted as future work. It assumes attach rate and average order value are invariant to the recommender, whereas personalisation plausibly alters both. And it takes no account of cannibalisation: some of the projected incremental revenue would have accrued anyway through organic search or navigation. Only a randomised controlled trial can resolve these, and the design of that trial is specified in §9.3.

---

# 8. Discussion

## 8.1 Algorithm Behaviour at the Individual Level

Figure 8.1 descends from population averages to a single representative customer, comparing how many correct predictions each system returns, how far their recommendation lists overlap, and what character of article each tends to surface.

![](../notebooks/figures/fig_8_1_per_user_comparison.png)

***Figure 8.1** — Behaviour of the competing algorithms for a single representative customer. Panel (α) shows the number of correct predictions in the top-10 by model; panel (β) shows the pairwise Jaccard overlap between the recommendation lists produced by each model; panel (γ) characterises the qualitative "character" of each list by mean item price. Source: author's analysis.*

Aggregate metrics conceal behavioural differences that matter for system design. Panel (β) of Figure 8.1 shows that the recommendation lists produced by different models overlap only weakly — the Jaccard similarity between EASE and content-based lists is low, and between EASE and the latent-factor models lower still. The models are not noisy estimates of a single underlying ranking; they are *qualitatively different systems* that surface different regions of the catalogue. The beyond-accuracy profile in Table 6.2 corroborates this: content-based reaches 52.5% of the catalogue and BPR-MF 42.7%, while EASE reaches 27.8%, yet the three attain broadly comparable accuracy within the mid-table cluster.

This has a direct architectural consequence. Weak overlap is the precondition under which hybridisation adds value, since fusing highly correlated rankings cannot outperform the best of them. That the weighted hybrid nevertheless failed to beat EASE (§6.3) therefore indicates not that the components are redundant but that the fixed weights are poorly chosen — they were set by prior judgement, not learned. A learned fusion, trained on the validation partition to predict which model should be trusted for which user, is the obvious next step and is proposed in §9.3.

Panel (γ) shows a further difference: the mean price of recommended items varies systematically by model. Item-kNN and association rules gravitate towards inexpensive, high-frequency articles; content-based and EASE surface a broader price range. Since the retailer's margin is proportional to price, this is not a neutral difference, and it is the reason the evaluation framework includes an explicit expected-revenue metric alongside accuracy. On that metric EASE also leads (£1.221 against the baseline's £0.851 per ranked list), indicating that its accuracy advantage is not achieved by concentrating on cheap items.

## 8.2 Why the Linear Model Won

The central empirical finding — that a closed-form linear autoencoder outperforms 128-factor matrix factorisation by 49.8% and 96-factor pairwise ranking by 36.3%, in roughly 1/68th and 1/133rd of the training time respectively — merits explanation rather than mere reporting. Three mechanisms are plausible and mutually compatible.

First, **the item space is small relative to the user space**. With 3,898 items in the training vocabulary and 4,712 users, the full item–item Gram matrix is a 15.2-million-entry object that can be estimated directly and inverted exactly. EASE does not approximate; it solves. Latent-factor models compress that same information into a 128- or 96-dimensional bottleneck, and when the exact solution is computationally available, compression is a loss rather than a regularisation.

Second, **the ridge penalty is a well-matched regulariser for this data regime**. With $\lambda = 250$ against a Gram matrix built from 352,044 training interactions, the penalty is substantial and shrinks poorly-supported item pairs aggressively — exactly the shrinkage logic that Bell and Koren (2007) showed to be the single most effective regularisation for neighbourhood models, but applied globally and in closed form rather than pairwise and heuristically.

Third, **the data are strongly co-occurrence structured**. Giftware purchasing is dominated by product-family effects: a customer buying `JUMBO BAG RED RETROSPOT` is very likely to buy `JUMBO BAG STRAWBERRY`. These are first-order, essentially linear relationships in item space. A model class with the capacity to represent complex non-linear interactions has no such interactions to represent here, and its additional capacity manifests as variance rather than as fit.

It is worth being precise about what this finding does and does not license. It is not that the latent-factor methods failed: both beat the baseline decisively, by 38.7% and 52.4%, and both are statistically indistinguishable from the neighbourhood and content methods. The claim is narrower — that on this data regime the exact linear solution attains better accuracy at two orders of magnitude less training cost. The generalisable lesson is that model selection should follow from the structure of the data, not from the recency of the method.

## 8.3 Answers to the Research Questions

**RQ1.** Personalised ranking improves NDCG@10 by 107.8% over a non-personalised popularity baseline (0.0444 → 0.0922), with a Holm-corrected *p* < 0.0001 and a 95% bootstrap confidence interval of [+0.0418, +0.0545] that excludes zero comfortably. Hit rate at ten recommendations rises from 28.9% to 46.5%, and all seven personalised systems beat the baseline.

**RQ2.** The EASE linear autoencoder is the best-performing family. Algorithmic sophistication does not predict performance: the closed-form linear model outperforms both matrix-factorisation approaches at a fraction of their training cost. The four mid-table systems — content-based, BPR-MF, Item-kNN and iALS — are mutually indistinguishable after multiplicity correction, so the defensible ranking is two leaders, a four-way tie, association rules and the baseline.

**RQ3.** The accuracy–diversity trade-off is real but does not bind over the commercially relevant range. EASE dominates the baseline simultaneously on accuracy, coverage (1.82% → 27.81%), novelty (2.76 → 3.73 bits), serendipity (×4.8) and popularity bias (0.557 → 0.313). The frontier becomes visible further out, where content-based buys 52.5% coverage at a 19% accuracy discount.

**RQ4.** Under an explicit funnel model, the accuracy improvement projects to a revenue uplift of +194.0% at the default elasticity, with a range of +54% to +323% across a sensitivity sweep. The point estimate is fragile and, because revenue is linear in click-through, is proportional to the assumed elasticity by construction; the qualitative conclusion and the model ordering are robust.

## 8.4 Fulfilment of the Project Brief

The brief specified an automated decision mechanism for product exposure, replacing *one-size-fits-all* with hyper-personalisation, addressing the paradox of choice, implementing cross-selling and up-selling algorithmically, and raising conversion rate and lifetime value. Each requirement maps to a verifiable artefact.

*Automated decision-making* is realised by the hybrid combiner and the serving layer, which issue decisions without human intervention; the entire experimental pipeline runs from a single command with no manual configuration. *Hyper-personalisation* is quantified by the 107.8% NDCG improvement of the personalised ranking over the global one. *Dynamic rather than static experience* is realised by the exponential recency decay, through which a customer's profile evolves continuously with behaviour. *Elimination of the paradox of choice* is realised by the reduction of 4,197 articles to ten relevant propositions, with the quality of that filtering measured by diversity and coverage rather than asserted. *Cross-selling and up-selling* are implemented as distinct engines with distinct objectives (§7.2). *Conversion rate* and *lifetime value* are modelled explicitly in §7.3 and §7.1 respectively.

One requirement is met only partially, and the limitation is restated here rather than buried. The brief asks for analysis of the digital footprint including *clicks, views and dwell time*; the dataset contains none of these. The system models the purchase footprint, and the weighting interface accepts click and view events without code change, but the empirical results concern purchases alone.

## 8.5 Threats to Validity

**Internal validity.** The principal threat, temporal leakage in the *training signal*, is controlled by construction and verified programmatically: the vocabulary, the interaction weights, the recency reference date, the TF–IDF statistics, the popularity counts and the novelty reference distribution are all derived from the training partition alone, and no model reads the validation or test partitions.

One qualification must be stated precisely rather than left implicit. The iterative *k*-core densification of §3.2 step (8) is applied to the **whole** cleaned log, before the temporal partition is formed, so the filter decides which customers and articles enter the study using interactions that fall in the validation and test periods. This is a selection-channel dependence on the future, even though no future *interaction value* reaches any model. Re-deriving the core from the training window alone quantifies it: 41 of 4,712 training users (0.9%), 108 of 3,898 articles (2.8%), 483 of 541,495 training rows (0.09%) and 92 of 2,555 held-out target articles (3.6%) would not survive a strictly causal core. The bias runs upward, because the filter guarantees every retained article at least five buyers *somewhere in time*. Since it is applied once, before any model exists, it affects all eight systems identically and cannot account for the differences in Chapter 6; but the absolute levels are very slightly optimistic. The honest statement is that this study is causally clean in its training signal and *approximately* so in its population selection. Relocating the core inside the training partition is the first item of future work in §9.3.

A secondary threat is hyperparameter sensitivity: no validation-partition search was performed, and every hyperparameter is a declared prior choice (Appendix B) rather than a tuned optimum. The results should therefore be read as a comparison of reasonable default configurations, not of optimally tuned systems.

**External validity.** This is a single-dataset study on a giftware retailer with a substantial wholesale component. The strong performance of the content-based model in particular is attributable to the stereotyped product vocabulary of this catalogue and should not be expected to transfer. Replication across datasets is the primary route to strengthening the conclusions.

**Construct validity.** NDCG is a proxy for user satisfaction, not a measurement of it; offline metrics and online outcomes are known to correlate imperfectly. The revenue simulation compounds this by adding an unverified behavioural elasticity, which is why the sensitivity analysis is reported alongside the point estimate.

**Statistical conclusion validity.** The evaluation uses all 2,007 eligible users and holds that population constant across models, supporting paired testing with strong power for the observed effects. Eight of the twenty-eight comparisons remain unresolved after correction, including the whole mid-table cluster, and these are reported as ties rather than presented as an ordering. Where the paired signed-rank test and the bootstrap interval on the mean disagree — as they do for four mid-table pairs — the corrected paired test is treated as decisive because it controls the family-wise error rate. The Wilcoxon test uses the `zsplit` treatment of zero differences, which retains the roughly half of customers scoring zero under both systems and is therefore conservative.

**Selection bias.** The 22.6% of transactions without a customer identifier are excluded, and they may differ systematically from identified transactions. The measured benefit therefore applies to the identified customer population, not to the retailer's traffic as a whole.

**Ethical considerations.** Three warrant note. Personalisation amplifies the exposure gradient documented in Table 7.4, which raises a fairness question for suppliers whose articles fall in the tail. Recommendation from behavioural data is a processing activity under data-protection law, requiring lawful basis, transparency and a right to explanation — the `explain()` interface implemented on every model is a technical precondition for the last of these. And the boundary between assistance and manipulation is not defined by the algorithm; a system that maximises short-term margin by exploiting behavioural biases would be technically successful and ethically indefensible, which is one reason the cross-sell engine's margin weight is a declared, auditable parameter rather than an implicit optimisation target.

---

# 9. Conclusions and Future Work

Figure 9.1 consolidates the empirical findings of Chapters 6 and 7 into a single view, bringing together the final accuracy ranking, the accuracy–exposure trade-off, the projected economic impact and the matrix of statistically significant differences.

![](../notebooks/figures/fig_9_1_summary_dashboard.png)

***Figure 9.1** — Consolidated summary of the empirical findings. Panel (α) shows the final accuracy ranking; panel (β) the accuracy–exposure trade-off; panel (γ) the projected economic impact; panel (δ) the matrix of statistically significant differences after Wilcoxon testing with Holm correction at α = 0.05; panel (ε) a consolidated tabulation of the principal findings. Source: author's analysis.*

## 9.1 Summary of Findings

This thesis designed, implemented and evaluated a hyper-personalisation recommendation engine for e-retail on 773,564 real transactions from 5,527 customers over 4,197 products. Seven algorithm families and a hybrid combiner were implemented from first principles and compared under a temporally causal, full-catalogue, statistically validated protocol across fifteen metrics.

The principal findings are five. **First**, personalisation produces a large and statistically robust improvement in ranking quality: NDCG@10 rises by 107.8% over the non-personalised baseline, and hit rate at ten from 28.9% to 46.5%, with all seven personalised systems beating the baseline. **Second**, the best-performing algorithm is a closed-form *linear* autoencoder that trains in 0.74 seconds and outperforms 128-factor matrix factorisation by 49.8% and 96-factor pairwise ranking by 36.3%, at roughly 1/68th and 1/133rd of their training cost — independently reproducing the finding of Ferrari Dacrema, Cremonesi and Jannach (2019) that algorithmic complexity is a poor predictor of empirical performance. **Third**, the accuracy improvement is accompanied by, rather than purchased at the expense of, large improvements in catalogue exposure: coverage rises 15.3-fold from 1.82% to 27.81%, novelty from 2.76 to 3.73 bits, and serendipity by a factor of 4.8. **Fourth**, the improvement translates, under an explicit and sensitivity-tested funnel model, into a projected revenue uplift of between 54% and 323%. **Fifth**, and negatively, the long tail is *not* activated: 98.1% of impressions remain concentrated on the head tercile of the catalogue, indicating that a recommender trained on historical purchases inherits and perpetuates the exposure bias of the data that produced it.

A sixth finding concerns the limits of what the evidence can settle. Only twenty of the twenty-eight pairwise comparisons survive multiplicity correction, and the four systems in positions three to six form a single statistically indistinguishable cluster. The evaluation separates two clear leaders and two clear laggards but cannot order the middle; reporting that is more useful than manufacturing a ranking the data does not support.

## 9.2 Contributions Restated

The contributions are methodological as much as they are technical. The from-scratch implementation of seven algorithm families under a common interface makes the comparison genuinely controlled, since no result can be attributed to differences between library implementations. The three-axis, fifteen-metric framework combined with Wilcoxon testing, bootstrap intervals and Holm correction over 28 comparisons represents a standard of inference rarely applied in applied recommender work — and demonstrably necessary, since the apparent advantage of association rules over the baseline did not survive correction, and neither did any of the six comparisons within the mid-table cluster. The explicit economic bridge, with its assumptions declared, its critical parameter swept and its structural linearity acknowledged, converts an accuracy result into a decision-relevant one without overclaiming. And the reproducibility apparatus — seeded randomness, snapshotted configuration, recorded environment, 193 unit tests, single-command execution — makes every number in this document independently verifiable.

## 9.3 Future Work

Five extensions follow directly from the limitations identified.

**A strictly causal densification step.** The *k*-core filter is currently applied to the whole log before partitioning (§8.5). Moving it inside the training partition would remove the last selection-channel dependence on the future. The measured effect is small — under 1% of training rows and under 3% of articles — but the correction is cheap and would make the causal claim unqualified.

**Online validation.** The decisive next step is a randomised controlled trial: a two-arm A/B test with users randomised to the popularity carousel or to EASE, powered to detect a 10% relative CTR difference, running for at least four weeks to absorb weekly seasonality, with revenue per session as the primary endpoint and catalogue coverage as a guardrail metric. This would replace the elasticity assumption of §7.3 with a measurement.

**Exploration and exposure fairness.** The long-tail failure of §7.2 requires an explicit remedy. A bandit formulation — Thompson sampling or $\varepsilon$-greedy insertion of tail items into a fixed slot of the carousel — would trade a small, bounded quantity of immediate accuracy for the exploration data needed to break the feedback loop. Exposure-fairness constraints in the ranking objective are the more principled alternative.

**Learned hybridisation.** The finding that the hybrid does not beat its strongest component (§6.3), combined with the finding that base models produce weakly overlapping lists (§8.1), points to a learned rather than fixed fusion: a lightweight model trained on the validation partition to predict per-user model reliability from features such as history length, recency and segment.

**Sequential modelling.** The present system treats a customer's history as an unordered weighted set. Session-based and sequential architectures — GRU4Rec, self-attentive models — exploit purchase *order*, which is available in the data and currently discarded. Given the finding of this thesis, however, such an extension should be introduced only against the EASE baseline established here, with the same statistical protocol.

**Multi-objective optimisation.** The evaluation reports fifteen metrics but optimises one. A principled treatment would optimise a declared scalarisation of accuracy, margin and exposure, allowing the business to set the trade-off explicitly rather than inheriting whichever trade-off accuracy maximisation happens to imply.

## 9.4 Closing Remarks

The commercial case for hyper-personalisation is sometimes advanced as though the difficulty were one of ambition. This thesis suggests the difficulty is one of discipline. The largest measured effect in the study — the eighteen-fold increase in catalogue exposure — came not from a sophisticated model but from a linear one with a single hyperparameter and a closed-form solution. The most important negative result — that the long tail remains unexposed — was visible only because the evaluation framework was built to look for it. And the most defensible economic claim was the weakest one, obtained by sweeping the assumption that could not be verified rather than by asserting it. If the thesis has a general lesson, it is that in applied recommendation the returns to methodological rigour presently exceed the returns to algorithmic novelty.

---

# References

Agrawal, R., Imieliński, T. and Swami, A. (1993) 'Mining association rules between sets of items in large databases', *Proceedings of the 1993 ACM SIGMOD International Conference on Management of Data*. Washington, DC, 26–28 May. New York: ACM, pp. 207–216.

Anderson, C. (2006) *The long tail: why the future of business is selling less of more*. New York: Hyperion.

Bell, R.M. and Koren, Y. (2007) 'Improved neighborhood-based collaborative filtering', *Proceedings of the KDD Cup and Workshop 2007*. San Jose, CA, 12 August. New York: ACM, pp. 7–14.

Burke, R. (2002) 'Hybrid recommender systems: survey and experiments', *User Modeling and User-Adapted Interaction*, 12(4), pp. 331–370.

Castells, P., Hurley, N.J. and Vargas, S. (2015) 'Novelty and diversity in recommender systems', in Ricci, F., Rokach, L. and Shapira, B. (eds.) *Recommender systems handbook*. 2nd edn. Boston, MA: Springer, pp. 881–918.

Chaffey, D. and Ellis-Chadwick, F. (2019) *Digital marketing*. 7th edn. Harlow: Pearson Education.

Chen, D. (2012) *Online Retail II* [Dataset]. UCI Machine Learning Repository. Available at: https://doi.org/10.24432/C5CG6D (Accessed: 13 August 2026).

Cormack, G.V., Clarke, C.L.A. and Büttcher, S. (2009) 'Reciprocal rank fusion outperforms Condorcet and individual rank learning methods', *Proceedings of the 32nd International ACM SIGIR Conference on Research and Development in Information Retrieval*. Boston, MA, 19–23 July. New York: ACM, pp. 758–759.

Covington, P., Adams, J. and Sargin, E. (2016) 'Deep neural networks for YouTube recommendations', *Proceedings of the 10th ACM Conference on Recommender Systems*. Boston, MA, 15–19 September. New York: ACM, pp. 191–198.

Cremonesi, P., Koren, Y. and Turrin, R. (2010) 'Performance of recommender algorithms on top-N recommendation tasks', *Proceedings of the 4th ACM Conference on Recommender Systems*. Barcelona, 26–30 September. New York: ACM, pp. 39–46.

Demšar, J. (2006) 'Statistical comparisons of classifiers over multiple data sets', *Journal of Machine Learning Research*, 7, pp. 1–30.

Deshpande, M. and Karypis, G. (2004) 'Item-based top-N recommendation algorithms', *ACM Transactions on Information Systems*, 22(1), pp. 143–177.

Efron, B. and Tibshirani, R.J. (1994) *An introduction to the bootstrap*. New York: Chapman & Hall/CRC.

Fader, P.S., Hardie, B.G.S. and Lee, K.L. (2005a) '"Counting your customers" the easy way: an alternative to the Pareto/NBD model', *Marketing Science*, 24(2), pp. 275–284.

Fader, P.S., Hardie, B.G.S. and Lee, K.L. (2005b) 'RFM and CLV: using iso-value curves for customer base analysis', *Journal of Marketing Research*, 42(4), pp. 415–430.

Ferrari Dacrema, M., Cremonesi, P. and Jannach, D. (2019) 'Are we really making much progress? A worrying analysis of recent neural recommendation approaches', *Proceedings of the 13th ACM Conference on Recommender Systems*. Copenhagen, 16–20 September. New York: ACM, pp. 101–109.

Ge, M., Delgado-Battenfeld, C. and Jannach, D. (2010) 'Beyond accuracy: evaluating recommender systems by coverage and serendipity', *Proceedings of the 4th ACM Conference on Recommender Systems*. Barcelona, 26–30 September. New York: ACM, pp. 257–260.

Gomez-Uribe, C.A. and Hunt, N. (2016) 'The Netflix recommender system: algorithms, business value, and innovation', *ACM Transactions on Management Information Systems*, 6(4), pp. 1–19.

Holm, S. (1979) 'A simple sequentially rejective multiple test procedure', *Scandinavian Journal of Statistics*, 6(2), pp. 65–70.

Hu, Y., Koren, Y. and Volinsky, C. (2008) 'Collaborative filtering for implicit feedback datasets', *Proceedings of the 8th IEEE International Conference on Data Mining*. Pisa, 15–19 December. Los Alamitos, CA: IEEE, pp. 263–272.

Hughes, A.M. (1994) *Strategic database marketing: the masterplan for starting and managing a profitable customer-based marketing program*. Chicago, IL: Probus Publishing.

Ji, Y., Sun, A., Zhang, J. and Li, C. (2020) 'A re-visit of the popularity baseline in recommender systems', *Proceedings of the 43rd International ACM SIGIR Conference on Research and Development in Information Retrieval*. Virtual event, 25–30 July. New York: ACM, pp. 1749–1752.

Kaminskas, M. and Bridge, D. (2017) 'Diversity, serendipity, novelty, and coverage: a survey and empirical analysis of beyond-accuracy objectives in recommender systems', *ACM Transactions on Interactive Intelligent Systems*, 7(1), pp. 1–42.

Koren, Y., Bell, R. and Volinsky, C. (2009) 'Matrix factorization techniques for recommender systems', *Computer*, 42(8), pp. 30–37.

Krichene, W. and Rendle, S. (2020) 'On sampled metrics for item recommendation', *Proceedings of the 26th ACM SIGKDD International Conference on Knowledge Discovery and Data Mining*. Virtual event, 6–10 July. New York: ACM, pp. 1748–1757.

Lops, P., de Gemmis, M. and Semeraro, G. (2011) 'Content-based recommender systems: state of the art and trends', in Ricci, F., Rokach, L., Shapira, B. and Kantor, P.B. (eds.) *Recommender systems handbook*. Boston, MA: Springer, pp. 73–105.

Meng, Z., McCreadie, R., Macdonald, C. and Ounis, I. (2020) 'Exploring data splitting strategies for the evaluation of recommendation models', *Proceedings of the 14th ACM Conference on Recommender Systems*. Virtual event, 22–26 September. New York: ACM, pp. 681–686.

Pazzani, M.J. and Billsus, D. (2007) 'Content-based recommendation systems', in Brusilovsky, P., Kobsa, A. and Nejdl, W. (eds.) *The adaptive web: methods and strategies of web personalization*. Berlin: Springer, pp. 325–341.

Rendle, S., Freudenthaler, C., Gantner, Z. and Schmidt-Thieme, L. (2009) 'BPR: Bayesian personalized ranking from implicit feedback', *Proceedings of the 25th Conference on Uncertainty in Artificial Intelligence*. Montreal, 18–21 June. Arlington, VA: AUAI Press, pp. 452–461.

Resnick, P., Iacovou, N., Suchak, M., Bergstrom, P. and Riedl, J. (1994) 'GroupLens: an open architecture for collaborative filtering of netnews', *Proceedings of the 1994 ACM Conference on Computer Supported Cooperative Work*. Chapel Hill, NC, 22–26 October. New York: ACM, pp. 175–186.

Robertson, S. and Zaragoza, H. (2009) 'The probabilistic relevance framework: BM25 and beyond', *Foundations and Trends in Information Retrieval*, 3(4), pp. 333–389.

Salton, G. and Buckley, C. (1988) 'Term-weighting approaches in automatic text retrieval', *Information Processing & Management*, 24(5), pp. 513–523.

Schnabel, T., Swaminathan, A., Singh, A., Chandak, N. and Joachims, T. (2016) 'Recommendations as treatments: debiasing learning and evaluation', *Proceedings of the 33rd International Conference on Machine Learning*. New York, NY, 20–22 June. Proceedings of Machine Learning Research, 48, pp. 1670–1679. Available at: https://proceedings.mlr.press/v48/schnabel16.html (Accessed: 13 August 2026).

Sculley, D., Holt, G., Golovin, D., Davydov, E., Phillips, T., Ebner, D., Chaudhary, V., Young, M., Crespo, J.-F. and Dennison, D. (2015) 'Hidden technical debt in machine learning systems', *Advances in Neural Information Processing Systems 28*, pp. 2503–2511.

Sarwar, B., Karypis, G., Konstan, J. and Riedl, J. (2001) 'Item-based collaborative filtering recommendation algorithms', *Proceedings of the 10th International Conference on World Wide Web*. Hong Kong, 1–5 May. New York: ACM, pp. 285–295.

Schwartz, B. (2004) *The paradox of choice: why more is less*. New York: HarperCollins.

Steck, H. (2019) 'Embarrassingly shallow autoencoders for sparse data', *Proceedings of the World Wide Web Conference 2019*. San Francisco, CA, 13–17 May. New York: ACM, pp. 3251–3257.

Takács, G., Pilászy, I. and Tikk, D. (2011) 'Applications of the conjugate gradient method for implicit feedback collaborative filtering', *Proceedings of the 5th ACM Conference on Recommender Systems*. Chicago, IL, 23–27 October. New York: ACM, pp. 297–300.

Vargas, S. and Castells, P. (2011) 'Rank and relevance in novelty and diversity metrics for recommender systems', *Proceedings of the 5th ACM Conference on Recommender Systems*. Chicago, IL, 23–27 October. New York: ACM, pp. 109–116.

Wilcoxon, F. (1945) 'Individual comparisons by ranking methods', *Biometrics Bulletin*, 1(6), pp. 80–83.

Zhou, T., Kuscsik, Z., Liu, J.-G., Medo, M., Wakeling, J.R. and Zhang, Y.-C. (2010) 'Solving the apparent diversity–accuracy dilemma of recommender systems', *Proceedings of the National Academy of Sciences*, 107(10), pp. 4511–4515.

Ziegler, C.-N., McNee, S.M., Konstan, J.A. and Lausen, G. (2005) 'Improving recommendation lists through topic diversification', *Proceedings of the 14th International Conference on World Wide Web*. Chiba, 10–14 May. New York: ACM, pp. 22–32.

---

# Appendix A — Reproduction Instructions

```bash
cd p281549-202607312032

# 1. Environment
python -m venv .venv && .venv\Scripts\activate
pip install -r requirements.txt && pip install -e .

# 2. Unit tests (193 expected to pass)
python -m pytest tests -q

# 3. Data acquisition
python -m recsys.cli download

# 4. Full experimental pipeline
python -m recsys.cli run --config config/config.yaml

# 5. Regenerate every figure in this document
jupyter notebook notebooks/01_analysis_and_results.ipynb

# 6. Serve the recommendation API
python -m recsys.cli serve --port 8000   # → http://localhost:8000/docs
```

The canonical final notebook executes `config/config.yaml` without notebook-only reductions and writes a timestamped configuration snapshot, environment manifest, result tables and figures under `artifacts/hyperpersonalization_main_<timestamp>/`. The final reference run is `artifacts/hyperpersonalization_main_20260817_134937/`. Environment: Python 3.13.7, NumPy 2.1.3, pandas 2.3.2, SciPy 1.16.2, scikit-learn 1.7.2, random seed 42.

# Appendix B — Complete Experimental Parameters

Every value below is read by the final notebook from the effective typed `Config`; no parameter is re-declared inside the training or evaluation cells. The run directory contains the corresponding machine-readable `config.snapshot.yaml` so that the tables can be audited against the executed experiment.

Table B.1 records the parameters governing data acquisition, the cleaning protocol, the temporal split and the construction of the interaction and content features.

**Table B.1 — Data, preprocessing and feature-construction parameters**

| Component | Parameter | Value |
|-----------|-----------|-------|
| Data | Source file | `online_retail_II.xlsx` |
| Data | Synthetic fallback | enabled; 120,000 rows if acquisition fails |
| Data | Cache | enabled |
| Cleaning | Missing customer identifiers | drop |
| Cleaning | Cancellations | drop invoice codes beginning with `C` |
| Cleaning | Administrative/non-product codes | drop |
| Cleaning | Quantity range | quantity ≥ 1 |
| Cleaning | Unit-price range | £0.01–£10,000 |
| Cleaning | Price outlier rule | remove values above quantile 0.999 |
| Cleaning | Iterative *k*-core | users ≥ 5; items ≥ 5; at most 20 iterations |
| Splitting | Strategy | `temporal_global` |
| Splitting | Train / validation / test | 70% / 10% / 20% |
| Splitting | Minimum training interactions for evaluation | 3 |
| Features | Implicit-confidence weighting | `log_count`, α = 1.0 |
| Features | Recency weighting | enabled; 180-day half-life |
| Features | TF–IDF vocabulary | at most 5,000 features |
| Features | TF–IDF n-grams | unigrams and bigrams |
| Features | TF–IDF minimum document frequency | 2 |

Table B.2 records the complete hyperparameter set of each of the eight evaluated systems, including the component weights of the hybrid combiner.

**Table B.2 — Complete model hyperparameters**

| Model | Parameter | Value |
|-------|-----------|-------|
| Popularity | recency decay | enabled |
| Popularity | recency half-life | 90 days |
| Item-kNN | neighbourhood size (`top_k`) | 200 |
| Item-kNN | similarity | cosine |
| Item-kNN | shrinkage | 20.0 |
| Item-kNN | BM25 *k*1 / *b* | 1.2 / 0.75 |
| Item-kNN | score normalisation | enabled |
| EASE^R | L2 regularisation λ | 250.0 |
| iALS | latent factors | 128 |
| iALS | regularisation λ | 0.05 |
| iALS | confidence scaling α | 40.0 |
| iALS | alternating iterations | 20 |
| iALS | linear solver | exact Cholesky (`assume_a="pos"`) |
| BPR-MF | latent factors | 96 |
| BPR-MF | learning rate | 0.05 |
| BPR-MF | regularisation λ | 0.01 |
| BPR-MF | epochs | 60 (all completed) |
| BPR-MF | negative samples per positive | 1 |
| BPR-MF | triplets per epoch | one per observed interaction (352,044) |
| BPR-MF | mini-batch size | 4,096 triplets |
| BPR-MF | warm-up before plateau test | 10 epochs |
| BPR-MF | plateau tolerance (relative) | 1e-3 |
| Content-based | profile aggregation | weighted mean |
| Association rules | minimum support | 0.001 |
| Association rules | minimum confidence | 0.05 |
| Association rules | minimum lift | 1.0 |
| Association rules | maximum basket size | 60 |
| Association rules | maximum retained rules | 200,000 |
| Hybrid | active strategy | weighted rank-normalised fusion |
| Hybrid | component weights | EASE 0.35; iALS 0.25; Item-kNN 0.20; association rules 0.10; content 0.05; popularity 0.05 |
| Hybrid | reciprocal-rank-fusion constant | 60 |
| Hybrid | cold-start threshold | 3 training interactions |
| Hybrid | cold-start / warm model | content-based / EASE |

Table B.3 records the evaluation cut-offs and the parameters of the inferential procedure described in §3.5.

**Table B.3 — Evaluation and inferential parameters**

| Component | Parameter | Value |
|-----------|-----------|-------|
| Ranking evaluation | cut-offs | *k* in {5, 10, 20} |
| Ranking evaluation | primary criterion | NDCG@10 |
| Ranking evaluation | exclude training items | enabled |
| Ranking evaluation | user cap | 4,000 eligible customers (2,007 qualified) |
| Ranking evaluation | held-out targets | restricted to articles not purchased in training |
| Novelty | reference distribution | training interactions (fixed) |
| Serendipity | "obvious" set | popularity prefix reachable by the baseline |
| Inference | paired test | two-sided Wilcoxon signed-rank |
| Inference | family-wise α | 0.05 |
| Inference | paired bootstrap iterations | 2,000 |
| Inference | multiplicity correction | Holm–Bonferroni |

Table B.4 records the parameters of the business layer of Chapter 7 and of the serving configuration described in §4.5.

**Table B.4 — Business and serving parameters**

| Component | Parameter | Value |
|-----------|-----------|-------|
| RFM | quantile groups per dimension | 5 |
| CLV | prediction horizon | 365 days |
| CLV | discount rate | 10% |
| Economics | gross margin | 35% |
| Simulation | impressions | 1,000,000 |
| Simulation | baseline CTR | 2.0% |
| Simulation | purchase attach rate | 12% |
| Simulation | CTR elasticity per NDCG point | 1.8 |
| Service | host / port | 127.0.0.1 / 8000 |
| Service | default / maximum recommendation count | 10 / 100 |
| Service | production model key | `hybrid` |
